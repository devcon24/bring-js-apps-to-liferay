var Se = Object.defineProperty;
var je = (t, e, n) => e in t ? Se(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var S = (t, e, n) => je(t, typeof e != "symbol" ? e + "" : e, n);
function j() {
}
function ge(t) {
  return t();
}
function de() {
  return /* @__PURE__ */ Object.create(null);
}
function T(t) {
  t.forEach(ge);
}
function ce(t) {
  return typeof t == "function";
}
function X(t, e) {
  return t != t ? e == e : t !== e || t && typeof t == "object" || typeof t == "function";
}
function Oe(t) {
  return Object.keys(t).length === 0;
}
function Fe(t) {
  return t && ce(t.destroy) ? t.destroy : j;
}
function h(t, e) {
  t.appendChild(e);
}
function P(t, e, n) {
  t.insertBefore(e, n || null);
}
function M(t) {
  t.parentNode && t.parentNode.removeChild(t);
}
function g(t) {
  return document.createElement(t);
}
function J(t) {
  return document.createTextNode(t);
}
function A() {
  return J(" ");
}
function Le() {
  return J("");
}
function B(t, e, n, s) {
  return t.addEventListener(e, n, s), () => t.removeEventListener(e, n, s);
}
function b(t, e, n) {
  n == null ? t.removeAttribute(e) : t.getAttribute(e) !== n && t.setAttribute(e, n);
}
function Me(t) {
  return Array.from(t.childNodes);
}
function se(t, e) {
  e = "" + e, t.data !== e && (t.data = /** @type {string} */
  e);
}
function L(t, e, n) {
  t.classList.toggle(e, !!n);
}
function Ne(t, e, { bubbles: n = !1, cancelable: s = !1 } = {}) {
  return new CustomEvent(t, { detail: e, bubbles: n, cancelable: s });
}
function Pe(t) {
  const e = {};
  return t.childNodes.forEach(
    /** @param {Element} node */
    (n) => {
      e[n.slot || "default"] = !0;
    }
  ), e;
}
let W;
function z(t) {
  W = t;
}
function be() {
  if (!W) throw new Error("Function called outside component initialization");
  return W;
}
function Be(t) {
  be().$$.on_mount.push(t);
}
function ue() {
  const t = be();
  return (e, n, { cancelable: s = !1 } = {}) => {
    const l = t.$$.callbacks[e];
    if (l) {
      const i = Ne(
        /** @type {string} */
        e,
        n,
        { cancelable: s }
      );
      return l.slice().forEach((o) => {
        o.call(t, i);
      }), !i.defaultPrevented;
    }
    return !0;
  };
}
const D = [], ie = [];
let V = [];
const le = [], we = /* @__PURE__ */ Promise.resolve();
let oe = !1;
function ye() {
  oe || (oe = !0, we.then(q));
}
function Te() {
  return ye(), we;
}
function re(t) {
  V.push(t);
}
function Re(t) {
  le.push(t);
}
const ne = /* @__PURE__ */ new Set();
let U = 0;
function q() {
  if (U !== 0)
    return;
  const t = W;
  do {
    try {
      for (; U < D.length; ) {
        const e = D[U];
        U++, z(e), He(e.$$);
      }
    } catch (e) {
      throw D.length = 0, U = 0, e;
    }
    for (z(null), D.length = 0, U = 0; ie.length; ) ie.pop()();
    for (let e = 0; e < V.length; e += 1) {
      const n = V[e];
      ne.has(n) || (ne.add(n), n());
    }
    V.length = 0;
  } while (D.length);
  for (; le.length; )
    le.pop()();
  oe = !1, ne.clear(), z(t);
}
function He(t) {
  if (t.fragment !== null) {
    t.update(), T(t.before_update);
    const e = t.dirty;
    t.dirty = [-1], t.fragment && t.fragment.p(t.ctx, e), t.after_update.forEach(re);
  }
}
function Ue(t) {
  const e = [], n = [];
  V.forEach((s) => t.indexOf(s) === -1 ? e.push(s) : n.push(s)), n.forEach((s) => s()), V = e;
}
const K = /* @__PURE__ */ new Set();
let R;
function ve() {
  R = {
    r: 0,
    c: [],
    p: R
    // parent group
  };
}
function ke() {
  R.r || T(R.c), R = R.p;
}
function N(t, e) {
  t && t.i && (K.delete(t), t.i(e));
}
function H(t, e, n, s) {
  if (t && t.o) {
    if (K.has(t)) return;
    K.add(t), R.c.push(() => {
      K.delete(t), s && (n && t.d(1), s());
    }), t.o(e);
  } else s && s();
}
function ae(t) {
  return (t == null ? void 0 : t.length) !== void 0 ? t : Array.from(t);
}
function De(t, e) {
  H(t, 1, 1, () => {
    e.delete(t.key);
  });
}
function Je(t, e, n, s, l, i, o, c, u, r, m, w) {
  let f = t.length, y = i.length, $ = f;
  const d = {};
  for (; $--; ) d[t[$].key] = $;
  const v = [], C = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), _ = [];
  for ($ = y; $--; ) {
    const k = w(l, i, $), O = n(k);
    let F = o.get(O);
    F ? _.push(() => F.p(k, e)) : (F = r(O, k), F.c()), C.set(O, v[$] = F), O in d && a.set(O, Math.abs($ - d[O]));
  }
  const p = /* @__PURE__ */ new Set(), E = /* @__PURE__ */ new Set();
  function I(k) {
    N(k, 1), k.m(c, m), o.set(k.key, k), m = k.first, y--;
  }
  for (; f && y; ) {
    const k = v[y - 1], O = t[f - 1], F = k.key, G = O.key;
    k === O ? (m = k.first, f--, y--) : C.has(G) ? !o.has(F) || p.has(F) ? I(k) : E.has(G) ? f-- : a.get(F) > a.get(G) ? (E.add(F), I(k)) : (p.add(G), f--) : (u(O, o), f--);
  }
  for (; f--; ) {
    const k = t[f];
    C.has(k.key) || u(k, o);
  }
  for (; y; ) I(v[y - 1]);
  return T(_), v;
}
function Ve(t, e, n) {
  const s = t.$$.props[e];
  s !== void 0 && (t.$$.bound[s] = n, n(t.$$.ctx[s]));
}
function fe(t) {
  t && t.c();
}
function Y(t, e, n) {
  const { fragment: s, after_update: l } = t.$$;
  s && s.m(e, n), re(() => {
    const i = t.$$.on_mount.map(ge).filter(ce);
    t.$$.on_destroy ? t.$$.on_destroy.push(...i) : T(i), t.$$.on_mount = [];
  }), l.forEach(re);
}
function Z(t, e) {
  const n = t.$$;
  n.fragment !== null && (Ue(n.after_update), T(n.on_destroy), n.fragment && n.fragment.d(e), n.on_destroy = n.fragment = null, n.ctx = []);
}
function qe(t, e) {
  t.$$.dirty[0] === -1 && (D.push(t), ye(), t.$$.dirty.fill(0)), t.$$.dirty[e / 31 | 0] |= 1 << e % 31;
}
function x(t, e, n, s, l, i, o = null, c = [-1]) {
  const u = W;
  z(t);
  const r = t.$$ = {
    fragment: null,
    ctx: [],
    // state
    props: i,
    update: j,
    not_equal: l,
    bound: de(),
    // lifecycle
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(e.context || (u ? u.$$.context : [])),
    // everything else
    callbacks: de(),
    dirty: c,
    skip_bound: !1,
    root: e.target || u.$$.root
  };
  o && o(r.root);
  let m = !1;
  if (r.ctx = n ? n(t, e.props || {}, (w, f, ...y) => {
    const $ = y.length ? y[0] : f;
    return r.ctx && l(r.ctx[w], r.ctx[w] = $) && (!r.skip_bound && r.bound[w] && r.bound[w]($), m && qe(t, w)), f;
  }) : [], r.update(), m = !0, T(r.before_update), r.fragment = s ? s(r.ctx) : !1, e.target) {
    if (e.hydrate) {
      const w = Me(e.target);
      r.fragment && r.fragment.l(w), w.forEach(M);
    } else
      r.fragment && r.fragment.c();
    e.intro && N(t.$$.fragment), Y(t, e.target, e.anchor), q();
  }
  z(u);
}
let Ce;
typeof HTMLElement == "function" && (Ce = class extends HTMLElement {
  constructor(e, n, s) {
    super();
    /** The Svelte component constructor */
    S(this, "$$ctor");
    /** Slots */
    S(this, "$$s");
    /** The Svelte component instance */
    S(this, "$$c");
    /** Whether or not the custom element is connected */
    S(this, "$$cn", !1);
    /** Component props data */
    S(this, "$$d", {});
    /** `true` if currently in the process of reflecting component props back to attributes */
    S(this, "$$r", !1);
    /** @type {Record<string, CustomElementPropDefinition>} Props definition (name, reflected, type etc) */
    S(this, "$$p_d", {});
    /** @type {Record<string, Function[]>} Event listeners */
    S(this, "$$l", {});
    /** @type {Map<Function, Function>} Event listener unsubscribe functions */
    S(this, "$$l_u", /* @__PURE__ */ new Map());
    this.$$ctor = e, this.$$s = n, s && this.attachShadow({ mode: "open" });
  }
  addEventListener(e, n, s) {
    if (this.$$l[e] = this.$$l[e] || [], this.$$l[e].push(n), this.$$c) {
      const l = this.$$c.$on(e, n);
      this.$$l_u.set(n, l);
    }
    super.addEventListener(e, n, s);
  }
  removeEventListener(e, n, s) {
    if (super.removeEventListener(e, n, s), this.$$c) {
      const l = this.$$l_u.get(n);
      l && (l(), this.$$l_u.delete(n));
    }
  }
  async connectedCallback() {
    if (this.$$cn = !0, !this.$$c) {
      let e = function(i) {
        return () => {
          let o;
          return {
            c: function() {
              o = g("slot"), i !== "default" && b(o, "name", i);
            },
            /**
             * @param {HTMLElement} target
             * @param {HTMLElement} [anchor]
             */
            m: function(r, m) {
              P(r, o, m);
            },
            d: function(r) {
              r && M(o);
            }
          };
        };
      };
      if (await Promise.resolve(), !this.$$cn || this.$$c)
        return;
      const n = {}, s = Pe(this);
      for (const i of this.$$s)
        i in s && (n[i] = [e(i)]);
      for (const i of this.attributes) {
        const o = this.$$g_p(i.name);
        o in this.$$d || (this.$$d[o] = Q(o, i.value, this.$$p_d, "toProp"));
      }
      for (const i in this.$$p_d)
        !(i in this.$$d) && this[i] !== void 0 && (this.$$d[i] = this[i], delete this[i]);
      this.$$c = new this.$$ctor({
        target: this.shadowRoot || this,
        props: {
          ...this.$$d,
          $$slots: n,
          $$scope: {
            ctx: []
          }
        }
      });
      const l = () => {
        this.$$r = !0;
        for (const i in this.$$p_d)
          if (this.$$d[i] = this.$$c.$$.ctx[this.$$c.$$.props[i]], this.$$p_d[i].reflect) {
            const o = Q(
              i,
              this.$$d[i],
              this.$$p_d,
              "toAttribute"
            );
            o == null ? this.removeAttribute(this.$$p_d[i].attribute || i) : this.setAttribute(this.$$p_d[i].attribute || i, o);
          }
        this.$$r = !1;
      };
      this.$$c.$$.after_update.push(l), l();
      for (const i in this.$$l)
        for (const o of this.$$l[i]) {
          const c = this.$$c.$on(i, o);
          this.$$l_u.set(o, c);
        }
      this.$$l = {};
    }
  }
  // We don't need this when working within Svelte code, but for compatibility of people using this outside of Svelte
  // and setting attributes through setAttribute etc, this is helpful
  attributeChangedCallback(e, n, s) {
    var l;
    this.$$r || (e = this.$$g_p(e), this.$$d[e] = Q(e, s, this.$$p_d, "toProp"), (l = this.$$c) == null || l.$set({ [e]: this.$$d[e] }));
  }
  disconnectedCallback() {
    this.$$cn = !1, Promise.resolve().then(() => {
      !this.$$cn && this.$$c && (this.$$c.$destroy(), this.$$c = void 0);
    });
  }
  $$g_p(e) {
    return Object.keys(this.$$p_d).find(
      (n) => this.$$p_d[n].attribute === e || !this.$$p_d[n].attribute && n.toLowerCase() === e
    ) || e;
  }
});
function Q(t, e, n, s) {
  var i;
  const l = (i = n[t]) == null ? void 0 : i.type;
  if (e = l === "Boolean" && typeof e != "boolean" ? e != null : e, !s || !n[t])
    return e;
  if (s === "toAttribute")
    switch (l) {
      case "Object":
      case "Array":
        return e == null ? null : JSON.stringify(e);
      case "Boolean":
        return e ? "" : null;
      case "Number":
        return e ?? null;
      default:
        return e;
    }
  else
    switch (l) {
      case "Object":
      case "Array":
        return e && JSON.parse(e);
      case "Boolean":
        return e;
      case "Number":
        return e != null ? +e : e;
      default:
        return e;
    }
}
function ee(t, e, n, s, l, i) {
  let o = class extends Ce {
    constructor() {
      super(t, n, l), this.$$p_d = e;
    }
    static get observedAttributes() {
      return Object.keys(e).map(
        (c) => (e[c].attribute || c).toLowerCase()
      );
    }
  };
  return Object.keys(e).forEach((c) => {
    Object.defineProperty(o.prototype, c, {
      get() {
        return this.$$c && c in this.$$c ? this.$$c[c] : this.$$d[c];
      },
      set(u) {
        var r;
        u = Q(c, u, e), this.$$d[c] = u, (r = this.$$c) == null || r.$set({ [c]: u });
      }
    });
  }), s.forEach((c) => {
    Object.defineProperty(o.prototype, c, {
      get() {
        var u;
        return (u = this.$$c) == null ? void 0 : u[c];
      }
    });
  }), t.element = /** @type {any} */
  o, o;
}
class te {
  constructor() {
    /**
     * ### PRIVATE API
     *
     * Do not use, may change at any time
     *
     * @type {any}
     */
    S(this, "$$");
    /**
     * ### PRIVATE API
     *
     * Do not use, may change at any time
     *
     * @type {any}
     */
    S(this, "$$set");
  }
  /** @returns {void} */
  $destroy() {
    Z(this, 1), this.$destroy = j;
  }
  /**
   * @template {Extract<keyof Events, string>} K
   * @param {K} type
   * @param {((e: Events[K]) => void) | null | undefined} callback
   * @returns {() => void}
   */
  $on(e, n) {
    if (!ce(n))
      return j;
    const s = this.$$.callbacks[e] || (this.$$.callbacks[e] = []);
    return s.push(n), () => {
      const l = s.indexOf(n);
      l !== -1 && s.splice(l, 1);
    };
  }
  /**
   * @param {Partial<Props>} props
   * @returns {void}
   */
  $set(e) {
    this.$$set && !Oe(e) && (this.$$.skip_bound = !0, this.$$set(e), this.$$.skip_bound = !1);
  }
}
const ze = "4";
typeof window < "u" && (window.__svelte || (window.__svelte = { v: /* @__PURE__ */ new Set() })).v.add(ze);
function We(t) {
  let e = "all";
  function n() {
    switch (window.location.hash) {
      case "#/active":
        e = "active";
        break;
      case "#/completed":
        e = "completed";
        break;
      default:
        e = "all";
    }
    t(e);
  }
  function s() {
    window.addEventListener("hashchange", n);
  }
  return {
    init: s
  };
}
async function Ge(t) {
  const e = [
    "/o/svelte/svelte-todo-mvc.css"
  ];
  for (const n of e)
    try {
      const l = await (await fetch(n)).text(), i = document.createElement("style");
      i.textContent = l, t.appendChild(i);
    } catch (s) {
      console.error(`Failed to load CSS from ${n}:`, s);
    }
}
function Ke(t) {
  let e, n, s, l, i, o;
  return {
    c() {
      e = g("header"), n = g("h1"), n.textContent = "todos", s = A(), l = g("input"), b(l, "class", "new-todo"), b(l, "placeholder", "What needs to be done?"), l.autofocus = !0, b(e, "class", "header");
    },
    m(c, u) {
      P(c, e, u), h(e, n), h(e, s), h(e, l), l.focus(), i || (o = B(
        l,
        "keydown",
        /*addItem*/
        t[0]
      ), i = !0);
    },
    p: j,
    i: j,
    o: j,
    d(c) {
      c && M(e), i = !1, o();
    }
  };
}
function Qe(t) {
  const e = ue();
  function n(s) {
    s.key === "Enter" && (e("addItem", { text: s.target.value }), s.target.value = "");
  }
  return [n];
}
class Ee extends te {
  constructor(e) {
    super(), x(this, e, Qe, Ke, X, {});
  }
}
ee(Ee, {}, [], [], !0);
function he(t) {
  let e, n, s;
  return {
    c() {
      e = g("button"), e.textContent = "Clear completed", b(e, "class", "clear-completed");
    },
    m(l, i) {
      P(l, e, i), n || (s = B(
        e,
        "click",
        /*removeCompletedItems*/
        t[3]
      ), n = !0);
    },
    p: j,
    d(l) {
      l && M(e), n = !1, s();
    }
  };
}
function Xe(t) {
  let e, n, s, l, i, o = (
    /*numActive*/
    t[0] === 1 ? "item" : "items"
  ), c, u, r, m, w, f, y, $, d, v, C, a, _, p = (
    /*numCompleted*/
    t[2] && he(t)
  );
  return {
    c() {
      e = g("footer"), n = g("span"), s = g("strong"), l = J(
        /*numActive*/
        t[0]
      ), i = A(), c = J(o), u = J(" left"), r = A(), m = g("ul"), w = g("li"), f = g("a"), f.textContent = "All", y = A(), $ = g("li"), d = g("a"), d.textContent = "Active", v = A(), C = g("li"), a = g("a"), a.textContent = "Completed", _ = A(), p && p.c(), b(n, "class", "todo-count"), b(f, "href", "#/"), L(
        f,
        "selected",
        /*currentFilter*/
        t[1] === "all"
      ), b(d, "href", "#/active"), L(
        d,
        "selected",
        /*currentFilter*/
        t[1] === "active"
      ), b(a, "href", "#/completed"), L(
        a,
        "selected",
        /*currentFilter*/
        t[1] === "completed"
      ), b(m, "class", "filters"), b(e, "class", "footer");
    },
    m(E, I) {
      P(E, e, I), h(e, n), h(n, s), h(s, l), h(n, i), h(n, c), h(n, u), h(e, r), h(e, m), h(m, w), h(w, f), h(m, y), h(m, $), h($, d), h(m, v), h(m, C), h(C, a), h(e, _), p && p.m(e, null);
    },
    p(E, [I]) {
      I & /*numActive*/
      1 && se(
        l,
        /*numActive*/
        E[0]
      ), I & /*numActive*/
      1 && o !== (o = /*numActive*/
      E[0] === 1 ? "item" : "items") && se(c, o), I & /*currentFilter*/
      2 && L(
        f,
        "selected",
        /*currentFilter*/
        E[1] === "all"
      ), I & /*currentFilter*/
      2 && L(
        d,
        "selected",
        /*currentFilter*/
        E[1] === "active"
      ), I & /*currentFilter*/
      2 && L(
        a,
        "selected",
        /*currentFilter*/
        E[1] === "completed"
      ), /*numCompleted*/
      E[2] ? p ? p.p(E, I) : (p = he(E), p.c(), p.m(e, null)) : p && (p.d(1), p = null);
    },
    i: j,
    o: j,
    d(E) {
      E && M(e), p && p.d();
    }
  };
}
function Ye(t, e, n) {
  let { numActive: s } = e, { currentFilter: l } = e, { numCompleted: i } = e;
  const o = ue();
  function c(u) {
    o("removeCompletedItems");
  }
  return t.$$set = (u) => {
    "numActive" in u && n(0, s = u.numActive), "currentFilter" in u && n(1, l = u.currentFilter), "numCompleted" in u && n(2, i = u.numCompleted);
  }, [s, l, i, c];
}
class Ae extends te {
  constructor(e) {
    super(), x(this, e, Ye, Xe, X, {
      numActive: 0,
      currentFilter: 1,
      numCompleted: 2
    });
  }
  get numActive() {
    return this.$$.ctx[0];
  }
  set numActive(e) {
    this.$$set({ numActive: e }), q();
  }
  get currentFilter() {
    return this.$$.ctx[1];
  }
  set currentFilter(e) {
    this.$$set({ currentFilter: e }), q();
  }
  get numCompleted() {
    return this.$$.ctx[2];
  }
  set numCompleted(e) {
    this.$$set({ numCompleted: e }), q();
  }
}
ee(Ae, { numActive: {}, currentFilter: {}, numCompleted: {} }, [], [], !0);
function $e(t) {
  let e, n, s, l, i, o, c;
  return {
    c() {
      e = g("div"), n = g("input"), l = A(), i = g("label"), i.textContent = "Edit Todo Input", n.value = s = /*item*/
      t[0].description, b(n, "id", "edit-todo-input"), b(n, "class", "edit"), b(i, "class", "visually-hidden"), b(i, "for", "edit-todo-input"), b(e, "class", "input-container");
    },
    m(u, r) {
      P(u, e, r), h(e, n), h(e, l), h(e, i), o || (c = [
        B(
          n,
          "keydown",
          /*handleEdit*/
          t[4]
        ),
        B(
          n,
          "blur",
          /*updateItem*/
          t[5]
        ),
        Fe(
          /*focusInput*/
          t[6].call(null, n)
        )
      ], o = !0);
    },
    p(u, r) {
      r & /*item*/
      1 && s !== (s = /*item*/
      u[0].description) && n.value !== s && (n.value = s);
    },
    d(u) {
      u && M(e), o = !1, T(c);
    }
  };
}
function Ze(t) {
  let e, n, s, l, i, o, c = (
    /*item*/
    t[0].description + ""
  ), u, r, m, w, f, y, $ = (
    /*editing*/
    t[1] && $e(t)
  );
  return {
    c() {
      e = g("li"), n = g("div"), s = g("input"), i = A(), o = g("label"), u = J(c), r = A(), m = g("button"), w = A(), $ && $.c(), b(s, "class", "toggle"), b(s, "type", "checkbox"), s.checked = l = /*item*/
      t[0].completed, b(m, "class", "destroy"), b(n, "class", "view"), L(
        e,
        "completed",
        /*item*/
        t[0].completed
      ), L(
        e,
        "editing",
        /*editing*/
        t[1]
      );
    },
    m(d, v) {
      P(d, e, v), h(e, n), h(n, s), h(n, i), h(n, o), h(o, u), h(n, r), h(n, m), h(e, w), $ && $.m(e, null), f || (y = [
        B(
          s,
          "change",
          /*change_handler*/
          t[7]
        ),
        B(
          o,
          "dblclick",
          /*startEdit*/
          t[3]
        ),
        B(
          m,
          "click",
          /*removeItem*/
          t[2]
        )
      ], f = !0);
    },
    p(d, [v]) {
      v & /*item*/
      1 && l !== (l = /*item*/
      d[0].completed) && (s.checked = l), v & /*item*/
      1 && c !== (c = /*item*/
      d[0].description + "") && se(u, c), /*editing*/
      d[1] ? $ ? $.p(d, v) : ($ = $e(d), $.c(), $.m(e, null)) : $ && ($.d(1), $ = null), v & /*item*/
      1 && L(
        e,
        "completed",
        /*item*/
        d[0].completed
      ), v & /*editing*/
      2 && L(
        e,
        "editing",
        /*editing*/
        d[1]
      );
    },
    i: j,
    o: j,
    d(d) {
      d && M(e), $ && $.d(), f = !1, T(y);
    }
  };
}
function xe(t, e, n) {
  let { item: s } = e;
  const l = ue();
  let i = !1;
  function o() {
    l("removeItem");
  }
  function c() {
    n(1, i = !0);
  }
  function u(f) {
    f.key === "Enter" ? f.target.blur() : f.key === "Escape" && n(1, i = !1);
  }
  function r(f) {
    if (!i) return;
    const { value: y } = f.target;
    y.length ? n(0, s.description = y, s) : o(), n(1, i = !1);
  }
  async function m(f) {
    await Te(), f.focus();
  }
  const w = (f) => n(0, s.completed = f.target.checked, s);
  return t.$$set = (f) => {
    "item" in f && n(0, s = f.item);
  }, [
    s,
    i,
    o,
    c,
    u,
    r,
    m,
    w
  ];
}
class Ie extends te {
  constructor(e) {
    super(), x(this, e, xe, Ze, X, { item: 0 });
  }
  get item() {
    return this.$$.ctx[0];
  }
  set item(e) {
    this.$$set({ item: e }), q();
  }
}
ee(Ie, { item: {} }, [], [], !0);
function me(t, e, n) {
  const s = t.slice();
  return s[12] = e[n], s[13] = e, s[14] = n, s;
}
function pe(t) {
  let e, n, s, l, i, o, c, u, r = [], m = /* @__PURE__ */ new Map(), w, f, y, $, d, v = ae(
    /*filtered*/
    t[4]
  );
  const C = (a) => (
    /*item*/
    a[12].id
  );
  for (let a = 0; a < v.length; a += 1) {
    let _ = me(t, v, a), p = C(_);
    m.set(p, r[a] = _e(p, _));
  }
  return f = new Ae({
    props: {
      numActive: (
        /*numActive*/
        t[3]
      ),
      currentFilter: (
        /*currentFilter*/
        t[0]
      ),
      numCompleted: (
        /*numCompleted*/
        t[2]
      )
    }
  }), f.$on(
    "removeCompletedItems",
    /*removeCompletedItems*/
    t[8]
  ), {
    c() {
      e = g("main"), n = g("div"), s = g("input"), i = A(), o = g("label"), o.textContent = "Mark all as complete", c = A(), u = g("ul");
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      w = A(), fe(f.$$.fragment), b(s, "id", "toggle-all"), b(s, "class", "toggle-all"), b(s, "type", "checkbox"), s.checked = l = /*numCompleted*/
      t[2] === /*items*/
      t[1].length, b(o, "for", "toggle-all"), b(n, "class", "toggle-all-container"), b(u, "class", "todo-list"), b(e, "class", "main");
    },
    m(a, _) {
      P(a, e, _), h(e, n), h(n, s), h(n, i), h(n, o), h(e, c), h(e, u);
      for (let p = 0; p < r.length; p += 1)
        r[p] && r[p].m(u, null);
      h(e, w), Y(f, e, null), y = !0, $ || (d = B(
        s,
        "change",
        /*toggleAllItems*/
        t[7]
      ), $ = !0);
    },
    p(a, _) {
      (!y || _ & /*numCompleted, items*/
      6 && l !== (l = /*numCompleted*/
      a[2] === /*items*/
      a[1].length)) && (s.checked = l), _ & /*filtered, removeItem*/
      80 && (v = ae(
        /*filtered*/
        a[4]
      ), ve(), r = Je(r, _, C, 1, a, v, m, u, De, _e, null, me), ke());
      const p = {};
      _ & /*numActive*/
      8 && (p.numActive = /*numActive*/
      a[3]), _ & /*currentFilter*/
      1 && (p.currentFilter = /*currentFilter*/
      a[0]), _ & /*numCompleted*/
      4 && (p.numCompleted = /*numCompleted*/
      a[2]), f.$set(p);
    },
    i(a) {
      if (!y) {
        for (let _ = 0; _ < v.length; _ += 1)
          N(r[_]);
        N(f.$$.fragment, a), y = !0;
      }
    },
    o(a) {
      for (let _ = 0; _ < r.length; _ += 1)
        H(r[_]);
      H(f.$$.fragment, a), y = !1;
    },
    d(a) {
      a && M(e);
      for (let _ = 0; _ < r.length; _ += 1)
        r[_].d();
      Z(f), $ = !1, d();
    }
  };
}
function _e(t, e) {
  let n, s, l, i;
  function o(r) {
    e[9](
      r,
      /*item*/
      e[12],
      /*each_value*/
      e[13],
      /*index*/
      e[14]
    );
  }
  function c() {
    return (
      /*removeItem_handler*/
      e[10](
        /*index*/
        e[14]
      )
    );
  }
  let u = {};
  return (
    /*item*/
    e[12] !== void 0 && (u.item = /*item*/
    e[12]), s = new Ie({ props: u }), ie.push(() => Ve(s, "item", o)), s.$on("removeItem", c), {
      key: t,
      first: null,
      c() {
        n = Le(), fe(s.$$.fragment), this.first = n;
      },
      m(r, m) {
        P(r, n, m), Y(s, r, m), i = !0;
      },
      p(r, m) {
        e = r;
        const w = {};
        !l && m & /*filtered*/
        16 && (l = !0, w.item = /*item*/
        e[12], Re(() => l = !1)), s.$set(w);
      },
      i(r) {
        i || (N(s.$$.fragment, r), i = !0);
      },
      o(r) {
        H(s.$$.fragment, r), i = !1;
      },
      d(r) {
        r && M(n), Z(s, r);
      }
    }
  );
}
function et(t) {
  let e, n, s, l;
  n = new Ee({}), n.$on(
    "addItem",
    /*addItem*/
    t[5]
  );
  let i = (
    /*items*/
    t[1].length > 0 && pe(t)
  );
  return {
    c() {
      e = g("div"), fe(n.$$.fragment), s = A(), i && i.c(), b(e, "class", "todo-app");
    },
    m(o, c) {
      P(o, e, c), Y(n, e, null), h(e, s), i && i.m(e, null), l = !0;
    },
    p(o, [c]) {
      /*items*/
      o[1].length > 0 ? i ? (i.p(o, c), c & /*items*/
      2 && N(i, 1)) : (i = pe(o), i.c(), N(i, 1), i.m(e, null)) : i && (ve(), H(i, 1, 1, () => {
        i = null;
      }), ke());
    },
    i(o) {
      l || (N(n.$$.fragment, o), N(i), l = !0);
    },
    o(o) {
      H(n.$$.fragment, o), H(i), l = !1;
    },
    d(o) {
      o && M(e), Z(n), i && i.d();
    }
  };
}
function tt(t, e, n) {
  let s, l, i, o = "all", c = [], u;
  function r(d) {
    n(1, c = [
      ...c,
      {
        id: crypto.randomUUID(),
        // This only works in secure contexts.
        description: d.detail.text,
        completed: !1
      }
    ]);
  }
  function m(d) {
    n(1, c = c.filter((v, C) => C !== d));
  }
  function w(d) {
    const v = d.target.checked;
    n(1, c = c.map((C) => ({ ...C, completed: v })));
  }
  function f() {
    n(1, c = c.filter((d) => !d.completed));
  }
  Be(async () => {
    u = document.querySelector("svelte-todo-mvc").shadowRoot, await Ge(u), We((d) => n(0, o = d)).init();
  });
  function y(d, v, C, a) {
    C[a] = d, n(4, s), n(0, o), n(1, c);
  }
  const $ = (d) => m(d);
  return t.$$.update = () => {
    t.$$.dirty & /*currentFilter, items*/
    3 && n(4, s = o === "all" ? c : o === "completed" ? c.filter((d) => d.completed) : c.filter((d) => !d.completed)), t.$$.dirty & /*items*/
    2 && n(3, l = c.filter((d) => !d.completed).length), t.$$.dirty & /*items*/
    2 && n(2, i = c.filter((d) => d.completed).length);
  }, [
    o,
    c,
    i,
    l,
    s,
    r,
    m,
    w,
    f,
    y,
    $
  ];
}
class nt extends te {
  constructor(e) {
    super(), x(this, e, tt, et, X, {});
  }
}
customElements.define("svelte-todo-mvc", ee(nt, {}, [], [], !0));
export {
  nt as default
};
