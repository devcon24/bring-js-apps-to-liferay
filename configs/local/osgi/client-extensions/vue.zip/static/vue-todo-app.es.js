/**
* @vue/shared v3.5.12
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function pt(e) {
  const t = /* @__PURE__ */ Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const Z = Object.freeze({}), Gt = Object.freeze([]), be = () => {
}, Tl = () => !1, $n = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), Yn = (e) => e.startsWith("onUpdate:"), ce = Object.assign, pr = (e, t) => {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}, Rl = Object.prototype.hasOwnProperty, J = (e, t) => Rl.call(e, t), N = Array.isArray, jt = (e) => An(e) === "[object Map]", po = (e) => An(e) === "[object Set]", Lr = (e) => An(e) === "[object Date]", L = (e) => typeof e == "function", le = (e) => typeof e == "string", et = (e) => typeof e == "symbol", Y = (e) => e !== null && typeof e == "object", hr = (e) => (Y(e) || L(e)) && L(e.then) && L(e.catch), Hs = Object.prototype.toString, An = (e) => Hs.call(e), mr = (e) => An(e).slice(8, -1), Ls = (e) => An(e) === "[object Object]", gr = (e) => le(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, pn = /* @__PURE__ */ pt(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Ol = /* @__PURE__ */ pt(
  "bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo"
), ho = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (n) => t[n] || (t[n] = e(n));
}, Pl = /-(\w)/g, Ve = ho(
  (e) => e.replace(Pl, (t, n) => n ? n.toUpperCase() : "")
), $l = /\B([A-Z])/g, ft = ho(
  (e) => e.replace($l, "-$1").toLowerCase()
), mo = ho((e) => e.charAt(0).toUpperCase() + e.slice(1)), It = ho(
  (e) => e ? `on${mo(e)}` : ""
), Ct = (e, t) => !Object.is(e, t), Bt = (e, ...t) => {
  for (let n = 0; n < e.length; n++)
    e[n](...t);
}, Qn = (e, t, n, o = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: o,
    value: n
  });
}, Uo = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
};
let Vr;
const In = () => Vr || (Vr = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function vr(e) {
  if (N(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const o = e[n], r = le(o) ? kl(o) : vr(o);
      if (r)
        for (const s in r)
          t[s] = r[s];
    }
    return t;
  } else if (le(e) || Y(e))
    return e;
}
const Al = /;(?![^(]*\))/g, Il = /:([^]+)/, Ml = /\/\*[^]*?\*\//g;
function kl(e) {
  const t = {};
  return e.replace(Ml, "").split(Al).forEach((n) => {
    if (n) {
      const o = n.split(Il);
      o.length > 1 && (t[o[0].trim()] = o[1].trim());
    }
  }), t;
}
function Dt(e) {
  let t = "";
  if (le(e))
    t = e;
  else if (N(e))
    for (let n = 0; n < e.length; n++) {
      const o = Dt(e[n]);
      o && (t += o + " ");
    }
  else if (Y(e))
    for (const n in e)
      e[n] && (t += n + " ");
  return t.trim();
}
const jl = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot", Dl = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view", Nl = "annotation,annotation-xml,maction,maligngroup,malignmark,math,menclose,merror,mfenced,mfrac,mfraction,mglyph,mi,mlabeledtr,mlongdiv,mmultiscripts,mn,mo,mover,mpadded,mphantom,mprescripts,mroot,mrow,ms,mscarries,mscarry,msgroup,msline,mspace,msqrt,msrow,mstack,mstyle,msub,msubsup,msup,mtable,mtd,mtext,mtr,munder,munderover,none,semantics", Fl = /* @__PURE__ */ pt(jl), Hl = /* @__PURE__ */ pt(Dl), Ll = /* @__PURE__ */ pt(Nl), Vl = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", Ul = /* @__PURE__ */ pt(Vl);
function Vs(e) {
  return !!e || e === "";
}
function Kl(e, t) {
  if (e.length !== t.length) return !1;
  let n = !0;
  for (let o = 0; n && o < e.length; o++)
    n = go(e[o], t[o]);
  return n;
}
function go(e, t) {
  if (e === t) return !0;
  let n = Lr(e), o = Lr(t);
  if (n || o)
    return n && o ? e.getTime() === t.getTime() : !1;
  if (n = et(e), o = et(t), n || o)
    return e === t;
  if (n = N(e), o = N(t), n || o)
    return n && o ? Kl(e, t) : !1;
  if (n = Y(e), o = Y(t), n || o) {
    if (!n || !o)
      return !1;
    const r = Object.keys(e).length, s = Object.keys(t).length;
    if (r !== s)
      return !1;
    for (const i in e) {
      const l = e.hasOwnProperty(i), c = t.hasOwnProperty(i);
      if (l && !c || !l && c || !go(e[i], t[i]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function Us(e, t) {
  return e.findIndex((n) => go(n, t));
}
const Ks = (e) => !!(e && e.__v_isRef === !0), Xn = (e) => le(e) ? e : e == null ? "" : N(e) || Y(e) && (e.toString === Hs || !L(e.toString)) ? Ks(e) ? Xn(e.value) : JSON.stringify(e, Bs, 2) : String(e), Bs = (e, t) => Ks(t) ? Bs(e, t.value) : jt(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (n, [o, r], s) => (n[Ro(o, s) + " =>"] = r, n),
    {}
  )
} : po(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((n) => Ro(n))
} : et(t) ? Ro(t) : Y(t) && !N(t) && !Ls(t) ? String(t) : t, Ro = (e, t = "") => {
  var n;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    et(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e
  );
};
/**
* @vue/reactivity v3.5.12
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function tt(e, ...t) {
  console.warn(`[Vue warn] ${e}`, ...t);
}
let $e;
class Bl {
  constructor(t = !1) {
    this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.parent = $e, !t && $e && (this.index = ($e.scopes || ($e.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].pause();
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++)
          this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++)
        this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = $e;
      try {
        return $e = this, t();
      } finally {
        $e = n;
      }
    } else
      tt("cannot run an inactive effect scope.");
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    $e = this;
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    $e = this.parent;
  }
  stop(t) {
    if (this._active) {
      let n, o;
      for (n = 0, o = this.effects.length; n < o; n++)
        this.effects[n].stop();
      for (n = 0, o = this.cleanups.length; n < o; n++)
        this.cleanups[n]();
      if (this.scopes)
        for (n = 0, o = this.scopes.length; n < o; n++)
          this.scopes[n].stop(!0);
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index);
      }
      this.parent = void 0, this._active = !1;
    }
  }
}
function Wl() {
  return $e;
}
let Q;
const Oo = /* @__PURE__ */ new WeakSet();
class Ws {
  constructor(t) {
    this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, $e && $e.active && $e.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 && (this.flags &= -65, Oo.has(this) && (Oo.delete(this), this.trigger()));
  }
  /**
   * @internal
   */
  notify() {
    this.flags & 2 && !(this.flags & 32) || this.flags & 8 || qs(this);
  }
  run() {
    if (!(this.flags & 1))
      return this.fn();
    this.flags |= 2, Ur(this), zs(this);
    const t = Q, n = Ue;
    Q = this, Ue = !0;
    try {
      return this.fn();
    } finally {
      Q !== this && tt(
        "Active effect was not restored correctly - this is likely a Vue internal bug."
      ), Js(this), Q = t, Ue = n, this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep)
        _r(t);
      this.deps = this.depsTail = void 0, Ur(this), this.onStop && this.onStop(), this.flags &= -2;
    }
  }
  trigger() {
    this.flags & 64 ? Oo.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
  }
  /**
   * @internal
   */
  runIfDirty() {
    Ko(this) && this.run();
  }
  get dirty() {
    return Ko(this);
  }
}
let Gs = 0, hn, mn;
function qs(e, t = !1) {
  if (e.flags |= 8, t) {
    e.next = mn, mn = e;
    return;
  }
  e.next = hn, hn = e;
}
function yr() {
  Gs++;
}
function br() {
  if (--Gs > 0)
    return;
  if (mn) {
    let t = mn;
    for (mn = void 0; t; ) {
      const n = t.next;
      t.next = void 0, t.flags &= -9, t = n;
    }
  }
  let e;
  for (; hn; ) {
    let t = hn;
    for (hn = void 0; t; ) {
      const n = t.next;
      if (t.next = void 0, t.flags &= -9, t.flags & 1)
        try {
          t.trigger();
        } catch (o) {
          e || (e = o);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function zs(e) {
  for (let t = e.deps; t; t = t.nextDep)
    t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Js(e) {
  let t, n = e.depsTail, o = n;
  for (; o; ) {
    const r = o.prevDep;
    o.version === -1 ? (o === n && (n = r), _r(o), Gl(o)) : t = o, o.dep.activeLink = o.prevActiveLink, o.prevActiveLink = void 0, o = r;
  }
  e.deps = t, e.depsTail = n;
}
function Ko(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (t.dep.version !== t.version || t.dep.computed && (Ys(t.dep.computed) || t.dep.version !== t.version))
      return !0;
  return !!e._dirty;
}
function Ys(e) {
  if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === En))
    return;
  e.globalVersion = En;
  const t = e.dep;
  if (e.flags |= 2, t.version > 0 && !e.isSSR && e.deps && !Ko(e)) {
    e.flags &= -3;
    return;
  }
  const n = Q, o = Ue;
  Q = e, Ue = !0;
  try {
    zs(e);
    const r = e.fn(e._value);
    (t.version === 0 || Ct(r, e._value)) && (e._value = r, t.version++);
  } catch (r) {
    throw t.version++, r;
  } finally {
    Q = n, Ue = o, Js(e), e.flags &= -3;
  }
}
function _r(e, t = !1) {
  const { dep: n, prevSub: o, nextSub: r } = e;
  if (o && (o.nextSub = r, e.prevSub = void 0), r && (r.prevSub = o, e.nextSub = void 0), n.subsHead === e && (n.subsHead = r), n.subs === e && (n.subs = o, !o && n.computed)) {
    n.computed.flags &= -5;
    for (let s = n.computed.deps; s; s = s.nextDep)
      _r(s, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function Gl(e) {
  const { prevDep: t, nextDep: n } = e;
  t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
let Ue = !0;
const Qs = [];
function ht() {
  Qs.push(Ue), Ue = !1;
}
function mt() {
  const e = Qs.pop();
  Ue = e === void 0 ? !0 : e;
}
function Ur(e) {
  const { cleanup: t } = e;
  if (e.cleanup = void 0, t) {
    const n = Q;
    Q = void 0;
    try {
      t();
    } finally {
      Q = n;
    }
  }
}
let En = 0;
class ql {
  constructor(t, n) {
    this.sub = t, this.dep = n, this.version = n.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class wr {
  constructor(t) {
    this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.subsHead = void 0;
  }
  track(t) {
    if (!Q || !Ue || Q === this.computed)
      return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== Q)
      n = this.activeLink = new ql(Q, this), Q.deps ? (n.prevDep = Q.depsTail, Q.depsTail.nextDep = n, Q.depsTail = n) : Q.deps = Q.depsTail = n, Xs(n);
    else if (n.version === -1 && (n.version = this.version, n.nextDep)) {
      const o = n.nextDep;
      o.prevDep = n.prevDep, n.prevDep && (n.prevDep.nextDep = o), n.prevDep = Q.depsTail, n.nextDep = void 0, Q.depsTail.nextDep = n, Q.depsTail = n, Q.deps === n && (Q.deps = o);
    }
    return Q.onTrack && Q.onTrack(
      ce(
        {
          effect: Q
        },
        t
      )
    ), n;
  }
  trigger(t) {
    this.version++, En++, this.notify(t);
  }
  notify(t) {
    yr();
    try {
      for (let n = this.subsHead; n; n = n.nextSub)
        n.sub.onTrigger && !(n.sub.flags & 8) && n.sub.onTrigger(
          ce(
            {
              effect: n.sub
            },
            t
          )
        );
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      br();
    }
  }
}
function Xs(e) {
  if (e.dep.sc++, e.sub.flags & 4) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let o = t.deps; o; o = o.nextDep)
        Xs(o);
    }
    const n = e.dep.subs;
    n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subsHead === void 0 && (e.dep.subsHead = e), e.dep.subs = e;
  }
}
const Bo = /* @__PURE__ */ new WeakMap(), Nt = Symbol(
  "Object iterate"
), Wo = Symbol(
  "Map keys iterate"
), Cn = Symbol(
  "Array iterate"
);
function pe(e, t, n) {
  if (Ue && Q) {
    let o = Bo.get(e);
    o || Bo.set(e, o = /* @__PURE__ */ new Map());
    let r = o.get(n);
    r || (o.set(n, r = new wr()), r.map = o, r.key = n), r.track({
      target: e,
      type: t,
      key: n
    });
  }
}
function Je(e, t, n, o, r, s) {
  const i = Bo.get(e);
  if (!i) {
    En++;
    return;
  }
  const l = (c) => {
    c && c.trigger({
      target: e,
      type: t,
      key: n,
      newValue: o,
      oldValue: r,
      oldTarget: s
    });
  };
  if (yr(), t === "clear")
    i.forEach(l);
  else {
    const c = N(e), d = c && gr(n);
    if (c && n === "length") {
      const f = Number(o);
      i.forEach((a, p) => {
        (p === "length" || p === Cn || !et(p) && p >= f) && l(a);
      });
    } else
      switch ((n !== void 0 || i.has(void 0)) && l(i.get(n)), d && l(i.get(Cn)), t) {
        case "add":
          c ? d && l(i.get("length")) : (l(i.get(Nt)), jt(e) && l(i.get(Wo)));
          break;
        case "delete":
          c || (l(i.get(Nt)), jt(e) && l(i.get(Wo)));
          break;
        case "set":
          jt(e) && l(i.get(Nt));
          break;
      }
  }
  br();
}
function Ut(e) {
  const t = U(e);
  return t === e ? t : (pe(t, "iterate", Cn), Ce(e) ? t : t.map(ye));
}
function vo(e) {
  return pe(e = U(e), "iterate", Cn), e;
}
const zl = {
  __proto__: null,
  [Symbol.iterator]() {
    return Po(this, Symbol.iterator, ye);
  },
  concat(...e) {
    return Ut(this).concat(
      ...e.map((t) => N(t) ? Ut(t) : t)
    );
  },
  entries() {
    return Po(this, "entries", (e) => (e[1] = ye(e[1]), e));
  },
  every(e, t) {
    return ot(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return ot(this, "filter", e, t, (n) => n.map(ye), arguments);
  },
  find(e, t) {
    return ot(this, "find", e, t, ye, arguments);
  },
  findIndex(e, t) {
    return ot(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return ot(this, "findLast", e, t, ye, arguments);
  },
  findLastIndex(e, t) {
    return ot(this, "findLastIndex", e, t, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(e, t) {
    return ot(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return $o(this, "includes", e);
  },
  indexOf(...e) {
    return $o(this, "indexOf", e);
  },
  join(e) {
    return Ut(this).join(e);
  },
  // keys() iterator only reads `length`, no optimisation required
  lastIndexOf(...e) {
    return $o(this, "lastIndexOf", e);
  },
  map(e, t) {
    return ot(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return on(this, "pop");
  },
  push(...e) {
    return on(this, "push", e);
  },
  reduce(e, ...t) {
    return Kr(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return Kr(this, "reduceRight", e, t);
  },
  shift() {
    return on(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(e, t) {
    return ot(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return on(this, "splice", e);
  },
  toReversed() {
    return Ut(this).toReversed();
  },
  toSorted(e) {
    return Ut(this).toSorted(e);
  },
  toSpliced(...e) {
    return Ut(this).toSpliced(...e);
  },
  unshift(...e) {
    return on(this, "unshift", e);
  },
  values() {
    return Po(this, "values", ye);
  }
};
function Po(e, t, n) {
  const o = vo(e), r = o[t]();
  return o !== e && !Ce(e) && (r._next = r.next, r.next = () => {
    const s = r._next();
    return s.value && (s.value = n(s.value)), s;
  }), r;
}
const Jl = Array.prototype;
function ot(e, t, n, o, r, s) {
  const i = vo(e), l = i !== e && !Ce(e), c = i[t];
  if (c !== Jl[t]) {
    const a = c.apply(e, s);
    return l ? ye(a) : a;
  }
  let d = n;
  i !== e && (l ? d = function(a, p) {
    return n.call(this, ye(a), p, e);
  } : n.length > 2 && (d = function(a, p) {
    return n.call(this, a, p, e);
  }));
  const f = c.call(i, d, o);
  return l && r ? r(f) : f;
}
function Kr(e, t, n, o) {
  const r = vo(e);
  let s = n;
  return r !== e && (Ce(e) ? n.length > 3 && (s = function(i, l, c) {
    return n.call(this, i, l, c, e);
  }) : s = function(i, l, c) {
    return n.call(this, i, ye(l), c, e);
  }), r[t](s, ...o);
}
function $o(e, t, n) {
  const o = U(e);
  pe(o, "iterate", Cn);
  const r = o[t](...n);
  return (r === -1 || r === !1) && Zn(n[0]) ? (n[0] = U(n[0]), o[t](...n)) : r;
}
function on(e, t, n = []) {
  ht(), yr();
  const o = U(e)[t].apply(e, n);
  return br(), mt(), o;
}
const Yl = /* @__PURE__ */ pt("__proto__,__v_isRef,__isVue"), Zs = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(et)
);
function Ql(e) {
  et(e) || (e = String(e));
  const t = U(this);
  return pe(t, "has", e), t.hasOwnProperty(e);
}
class ei {
  constructor(t = !1, n = !1) {
    this._isReadonly = t, this._isShallow = n;
  }
  get(t, n, o) {
    const r = this._isReadonly, s = this._isShallow;
    if (n === "__v_isReactive")
      return !r;
    if (n === "__v_isReadonly")
      return r;
    if (n === "__v_isShallow")
      return s;
    if (n === "__v_raw")
      return o === (r ? s ? ii : si : s ? ri : oi).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(o) ? t : void 0;
    const i = N(t);
    if (!r) {
      let c;
      if (i && (c = zl[n]))
        return c;
      if (n === "hasOwnProperty")
        return Ql;
    }
    const l = Reflect.get(
      t,
      n,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      ae(t) ? t : o
    );
    return (et(n) ? Zs.has(n) : Yl(n)) || (r || pe(t, "get", n), s) ? l : ae(l) ? i && gr(n) ? l : l.value : Y(l) ? r ? ci(l) : bo(l) : l;
  }
}
class ti extends ei {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, o, r) {
    let s = t[n];
    if (!this._isShallow) {
      const c = dt(s);
      if (!Ce(o) && !dt(o) && (s = U(s), o = U(o)), !N(t) && ae(s) && !ae(o))
        return c ? !1 : (s.value = o, !0);
    }
    const i = N(t) && gr(n) ? Number(n) < t.length : J(t, n), l = Reflect.set(
      t,
      n,
      o,
      ae(t) ? t : r
    );
    return t === U(r) && (i ? Ct(o, s) && Je(t, "set", n, o, s) : Je(t, "add", n, o)), l;
  }
  deleteProperty(t, n) {
    const o = J(t, n), r = t[n], s = Reflect.deleteProperty(t, n);
    return s && o && Je(t, "delete", n, void 0, r), s;
  }
  has(t, n) {
    const o = Reflect.has(t, n);
    return (!et(n) || !Zs.has(n)) && pe(t, "has", n), o;
  }
  ownKeys(t) {
    return pe(
      t,
      "iterate",
      N(t) ? "length" : Nt
    ), Reflect.ownKeys(t);
  }
}
class ni extends ei {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return tt(
      `Set operation on key "${String(n)}" failed: target is readonly.`,
      t
    ), !0;
  }
  deleteProperty(t, n) {
    return tt(
      `Delete operation on key "${String(n)}" failed: target is readonly.`,
      t
    ), !0;
  }
}
const Xl = /* @__PURE__ */ new ti(), Zl = /* @__PURE__ */ new ni(), ec = /* @__PURE__ */ new ti(!0), tc = /* @__PURE__ */ new ni(!0), Go = (e) => e, Hn = (e) => Reflect.getPrototypeOf(e);
function nc(e, t, n) {
  return function(...o) {
    const r = this.__v_raw, s = U(r), i = jt(s), l = e === "entries" || e === Symbol.iterator && i, c = e === "keys" && i, d = r[e](...o), f = n ? Go : t ? qo : ye;
    return !t && pe(
      s,
      "iterate",
      c ? Wo : Nt
    ), {
      // iterator protocol
      next() {
        const { value: a, done: p } = d.next();
        return p ? { value: a, done: p } : {
          value: l ? [f(a[0]), f(a[1])] : f(a),
          done: p
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function Ln(e) {
  return function(...t) {
    {
      const n = t[0] ? `on key "${t[0]}" ` : "";
      tt(
        `${mo(e)} operation ${n}failed: target is readonly.`,
        U(this)
      );
    }
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function oc(e, t) {
  const n = {
    get(r) {
      const s = this.__v_raw, i = U(s), l = U(r);
      e || (Ct(r, l) && pe(i, "get", r), pe(i, "get", l));
      const { has: c } = Hn(i), d = t ? Go : e ? qo : ye;
      if (c.call(i, r))
        return d(s.get(r));
      if (c.call(i, l))
        return d(s.get(l));
      s !== i && s.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return !e && pe(U(r), "iterate", Nt), Reflect.get(r, "size", r);
    },
    has(r) {
      const s = this.__v_raw, i = U(s), l = U(r);
      return e || (Ct(r, l) && pe(i, "has", r), pe(i, "has", l)), r === l ? s.has(r) : s.has(r) || s.has(l);
    },
    forEach(r, s) {
      const i = this, l = i.__v_raw, c = U(l), d = t ? Go : e ? qo : ye;
      return !e && pe(c, "iterate", Nt), l.forEach((f, a) => r.call(s, d(f), d(a), i));
    }
  };
  return ce(
    n,
    e ? {
      add: Ln("add"),
      set: Ln("set"),
      delete: Ln("delete"),
      clear: Ln("clear")
    } : {
      add(r) {
        !t && !Ce(r) && !dt(r) && (r = U(r));
        const s = U(this);
        return Hn(s).has.call(s, r) || (s.add(r), Je(s, "add", r, r)), this;
      },
      set(r, s) {
        !t && !Ce(s) && !dt(s) && (s = U(s));
        const i = U(this), { has: l, get: c } = Hn(i);
        let d = l.call(i, r);
        d ? Br(i, l, r) : (r = U(r), d = l.call(i, r));
        const f = c.call(i, r);
        return i.set(r, s), d ? Ct(s, f) && Je(i, "set", r, s, f) : Je(i, "add", r, s), this;
      },
      delete(r) {
        const s = U(this), { has: i, get: l } = Hn(s);
        let c = i.call(s, r);
        c ? Br(s, i, r) : (r = U(r), c = i.call(s, r));
        const d = l ? l.call(s, r) : void 0, f = s.delete(r);
        return c && Je(s, "delete", r, void 0, d), f;
      },
      clear() {
        const r = U(this), s = r.size !== 0, i = jt(r) ? new Map(r) : new Set(r), l = r.clear();
        return s && Je(
          r,
          "clear",
          void 0,
          void 0,
          i
        ), l;
      }
    }
  ), [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((r) => {
    n[r] = nc(r, e, t);
  }), n;
}
function yo(e, t) {
  const n = oc(e, t);
  return (o, r, s) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? o : Reflect.get(
    J(n, r) && r in o ? n : o,
    r,
    s
  );
}
const rc = {
  get: /* @__PURE__ */ yo(!1, !1)
}, sc = {
  get: /* @__PURE__ */ yo(!1, !0)
}, ic = {
  get: /* @__PURE__ */ yo(!0, !1)
}, lc = {
  get: /* @__PURE__ */ yo(!0, !0)
};
function Br(e, t, n) {
  const o = U(n);
  if (o !== n && t.call(e, o)) {
    const r = mr(e);
    tt(
      `Reactive ${r} contains both the raw and reactive versions of the same object${r === "Map" ? " as keys" : ""}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`
    );
  }
}
const oi = /* @__PURE__ */ new WeakMap(), ri = /* @__PURE__ */ new WeakMap(), si = /* @__PURE__ */ new WeakMap(), ii = /* @__PURE__ */ new WeakMap();
function cc(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function ac(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : cc(mr(e));
}
function bo(e) {
  return dt(e) ? e : _o(
    e,
    !1,
    Xl,
    rc,
    oi
  );
}
function li(e) {
  return _o(
    e,
    !1,
    ec,
    sc,
    ri
  );
}
function ci(e) {
  return _o(
    e,
    !0,
    Zl,
    ic,
    si
  );
}
function Qe(e) {
  return _o(
    e,
    !0,
    tc,
    lc,
    ii
  );
}
function _o(e, t, n, o, r) {
  if (!Y(e))
    return tt(
      `value cannot be made ${t ? "readonly" : "reactive"}: ${String(
        e
      )}`
    ), e;
  if (e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const s = r.get(e);
  if (s)
    return s;
  const i = ac(e);
  if (i === 0)
    return e;
  const l = new Proxy(
    e,
    i === 2 ? o : n
  );
  return r.set(e, l), l;
}
function Ft(e) {
  return dt(e) ? Ft(e.__v_raw) : !!(e && e.__v_isReactive);
}
function dt(e) {
  return !!(e && e.__v_isReadonly);
}
function Ce(e) {
  return !!(e && e.__v_isShallow);
}
function Zn(e) {
  return e ? !!e.__v_raw : !1;
}
function U(e) {
  const t = e && e.__v_raw;
  return t ? U(t) : e;
}
function uc(e) {
  return !J(e, "__v_skip") && Object.isExtensible(e) && Qn(e, "__v_skip", !0), e;
}
const ye = (e) => Y(e) ? bo(e) : e, qo = (e) => Y(e) ? ci(e) : e;
function ae(e) {
  return e ? e.__v_isRef === !0 : !1;
}
function gn(e) {
  return ai(e, !1);
}
function fc(e) {
  return ai(e, !0);
}
function ai(e, t) {
  return ae(e) ? e : new dc(e, t);
}
class dc {
  constructor(t, n) {
    this.dep = new wr(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = n ? t : U(t), this._value = n ? t : ye(t), this.__v_isShallow = n;
  }
  get value() {
    return this.dep.track({
      target: this,
      type: "get",
      key: "value"
    }), this._value;
  }
  set value(t) {
    const n = this._rawValue, o = this.__v_isShallow || Ce(t) || dt(t);
    t = o ? t : U(t), Ct(t, n) && (this._rawValue = t, this._value = o ? t : ye(t), this.dep.trigger({
      target: this,
      type: "set",
      key: "value",
      newValue: t,
      oldValue: n
    }));
  }
}
function xe(e) {
  return ae(e) ? e.value : e;
}
const pc = {
  get: (e, t, n) => t === "__v_raw" ? e : xe(Reflect.get(e, t, n)),
  set: (e, t, n, o) => {
    const r = e[t];
    return ae(r) && !ae(n) ? (r.value = n, !0) : Reflect.set(e, t, n, o);
  }
};
function ui(e) {
  return Ft(e) ? e : new Proxy(e, pc);
}
class hc {
  constructor(t, n, o) {
    this.fn = t, this.setter = n, this._value = void 0, this.dep = new wr(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = En - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !n, this.isSSR = o;
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags |= 16, !(this.flags & 8) && // avoid infinite self recursion
    Q !== this)
      return qs(this, !0), !0;
  }
  get value() {
    const t = this.dep.track({
      target: this,
      type: "get",
      key: "value"
    });
    return Ys(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter ? this.setter(t) : tt("Write operation failed: computed value is readonly");
  }
}
function mc(e, t, n = !1) {
  let o, r;
  return L(e) ? o = e : (o = e.get, r = e.set), new hc(o, r, n);
}
const Vn = {}, eo = /* @__PURE__ */ new WeakMap();
let Mt;
function gc(e, t = !1, n = Mt) {
  if (n) {
    let o = eo.get(n);
    o || eo.set(n, o = []), o.push(e);
  } else t || tt(
    "onWatcherCleanup() was called when there was no active watcher to associate with."
  );
}
function vc(e, t, n = Z) {
  const { immediate: o, deep: r, once: s, scheduler: i, augmentJob: l, call: c } = n, d = (I) => {
    (n.onWarn || tt)(
      "Invalid watch source: ",
      I,
      "A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types."
    );
  }, f = (I) => r ? I : Ce(I) || r === !1 || r === 0 ? at(I, 1) : at(I);
  let a, p, m, y, b = !1, M = !1;
  if (ae(e) ? (p = () => e.value, b = Ce(e)) : Ft(e) ? (p = () => f(e), b = !0) : N(e) ? (M = !0, b = e.some((I) => Ft(I) || Ce(I)), p = () => e.map((I) => {
    if (ae(I))
      return I.value;
    if (Ft(I))
      return f(I);
    if (L(I))
      return c ? c(I, 2) : I();
    d(I);
  })) : L(e) ? t ? p = c ? () => c(e, 2) : e : p = () => {
    if (m) {
      ht();
      try {
        m();
      } finally {
        mt();
      }
    }
    const I = Mt;
    Mt = a;
    try {
      return c ? c(e, 3, [y]) : e(y);
    } finally {
      Mt = I;
    }
  } : (p = be, d(e)), t && r) {
    const I = p, ne = r === !0 ? 1 / 0 : r;
    p = () => at(I(), ne);
  }
  const F = Wl(), j = () => {
    a.stop(), F && pr(F.effects, a);
  };
  if (s && t) {
    const I = t;
    t = (...ne) => {
      I(...ne), j();
    };
  }
  let A = M ? new Array(e.length).fill(Vn) : Vn;
  const te = (I) => {
    if (!(!(a.flags & 1) || !a.dirty && !I))
      if (t) {
        const ne = a.run();
        if (r || b || (M ? ne.some((re, fe) => Ct(re, A[fe])) : Ct(ne, A))) {
          m && m();
          const re = Mt;
          Mt = a;
          try {
            const fe = [
              ne,
              // pass undefined as the old value when it's changed for the first time
              A === Vn ? void 0 : M && A[0] === Vn ? [] : A,
              y
            ];
            c ? c(t, 3, fe) : (
              // @ts-expect-error
              t(...fe)
            ), A = ne;
          } finally {
            Mt = re;
          }
        }
      } else
        a.run();
  };
  return l && l(te), a = new Ws(p), a.scheduler = i ? () => i(te, !1) : te, y = (I) => gc(I, !1, a), m = a.onStop = () => {
    const I = eo.get(a);
    if (I) {
      if (c)
        c(I, 4);
      else
        for (const ne of I) ne();
      eo.delete(a);
    }
  }, a.onTrack = n.onTrack, a.onTrigger = n.onTrigger, t ? o ? te(!0) : A = a.run() : i ? i(te.bind(null, !0), !0) : a.run(), j.pause = a.pause.bind(a), j.resume = a.resume.bind(a), j.stop = j, j;
}
function at(e, t = 1 / 0, n) {
  if (t <= 0 || !Y(e) || e.__v_skip || (n = n || /* @__PURE__ */ new Set(), n.has(e)))
    return e;
  if (n.add(e), t--, ae(e))
    at(e.value, t, n);
  else if (N(e))
    for (let o = 0; o < e.length; o++)
      at(e[o], t, n);
  else if (po(e) || jt(e))
    e.forEach((o) => {
      at(o, t, n);
    });
  else if (Ls(e)) {
    for (const o in e)
      at(e[o], t, n);
    for (const o of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, o) && at(e[o], t, n);
  }
  return e;
}
/**
* @vue/runtime-core v3.5.12
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
const Ht = [];
function Kn(e) {
  Ht.push(e);
}
function Bn() {
  Ht.pop();
}
let Ao = !1;
function T(e, ...t) {
  if (Ao) return;
  Ao = !0, ht();
  const n = Ht.length ? Ht[Ht.length - 1].component : null, o = n && n.appContext.config.warnHandler, r = yc();
  if (o)
    tn(
      o,
      n,
      11,
      [
        // eslint-disable-next-line no-restricted-syntax
        e + t.map((s) => {
          var i, l;
          return (l = (i = s.toString) == null ? void 0 : i.call(s)) != null ? l : JSON.stringify(s);
        }).join(""),
        n && n.proxy,
        r.map(
          ({ vnode: s }) => `at <${Co(n, s.type)}>`
        ).join(`
`),
        r
      ]
    );
  else {
    const s = [`[Vue warn]: ${e}`, ...t];
    r.length && s.push(`
`, ...bc(r)), console.warn(...s);
  }
  mt(), Ao = !1;
}
function yc() {
  let e = Ht[Ht.length - 1];
  if (!e)
    return [];
  const t = [];
  for (; e; ) {
    const n = t[0];
    n && n.vnode === e ? n.recurseCount++ : t.push({
      vnode: e,
      recurseCount: 0
    });
    const o = e.component && e.component.parent;
    e = o && o.vnode;
  }
  return t;
}
function bc(e) {
  const t = [];
  return e.forEach((n, o) => {
    t.push(...o === 0 ? [] : [`
`], ..._c(n));
  }), t;
}
function _c({ vnode: e, recurseCount: t }) {
  const n = t > 0 ? `... (${t} recursive calls)` : "", o = e.component ? e.component.parent == null : !1, r = ` at <${Co(
    e.component,
    e.type,
    o
  )}`, s = ">" + n;
  return e.props ? [r, ...wc(e.props), s] : [r + s];
}
function wc(e) {
  const t = [], n = Object.keys(e);
  return n.slice(0, 3).forEach((o) => {
    t.push(...fi(o, e[o]));
  }), n.length > 3 && t.push(" ..."), t;
}
function fi(e, t, n) {
  return le(t) ? (t = JSON.stringify(t), n ? t : [`${e}=${t}`]) : typeof t == "number" || typeof t == "boolean" || t == null ? n ? t : [`${e}=${t}`] : ae(t) ? (t = fi(e, U(t.value), !0), n ? t : [`${e}=Ref<`, t, ">"]) : L(t) ? [`${e}=fn${t.name ? `<${t.name}>` : ""}`] : (t = U(t), n ? t : [`${e}=`, t]);
}
const xr = {
  sp: "serverPrefetch hook",
  bc: "beforeCreate hook",
  c: "created hook",
  bm: "beforeMount hook",
  m: "mounted hook",
  bu: "beforeUpdate hook",
  u: "updated",
  bum: "beforeUnmount hook",
  um: "unmounted hook",
  a: "activated hook",
  da: "deactivated hook",
  ec: "errorCaptured hook",
  rtc: "renderTracked hook",
  rtg: "renderTriggered hook",
  0: "setup function",
  1: "render function",
  2: "watcher getter",
  3: "watcher callback",
  4: "watcher cleanup function",
  5: "native event handler",
  6: "component event handler",
  7: "vnode hook",
  8: "directive hook",
  9: "transition hook",
  10: "app errorHandler",
  11: "app warnHandler",
  12: "ref function",
  13: "async component loader",
  14: "scheduler flush",
  15: "component update",
  16: "app unmount cleanup function"
};
function tn(e, t, n, o) {
  try {
    return o ? e(...o) : e();
  } catch (r) {
    Mn(r, t, n);
  }
}
function nt(e, t, n, o) {
  if (L(e)) {
    const r = tn(e, t, n, o);
    return r && hr(r) && r.catch((s) => {
      Mn(s, t, n);
    }), r;
  }
  if (N(e)) {
    const r = [];
    for (let s = 0; s < e.length; s++)
      r.push(nt(e[s], t, n, o));
    return r;
  } else
    T(
      `Invalid value type passed to callWithAsyncErrorHandling(): ${typeof e}`
    );
}
function Mn(e, t, n, o = !0) {
  const r = t ? t.vnode : null, { errorHandler: s, throwUnhandledErrorInProduction: i } = t && t.appContext.config || Z;
  if (t) {
    let l = t.parent;
    const c = t.proxy, d = xr[n];
    for (; l; ) {
      const f = l.ec;
      if (f) {
        for (let a = 0; a < f.length; a++)
          if (f[a](e, c, d) === !1)
            return;
      }
      l = l.parent;
    }
    if (s) {
      ht(), tn(s, null, 10, [
        e,
        c,
        d
      ]), mt();
      return;
    }
  }
  xc(e, n, r, o, i);
}
function xc(e, t, n, o = !0, r = !1) {
  {
    const s = xr[t];
    if (n && Kn(n), T(`Unhandled error${s ? ` during execution of ${s}` : ""}`), n && Bn(), o)
      throw e;
    console.error(e);
  }
}
const Se = [];
let ze = -1;
const qt = [];
let wt = null, Wt = 0;
const di = /* @__PURE__ */ Promise.resolve();
let to = null;
const Sc = 100;
function Sr(e) {
  const t = to || di;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Ec(e) {
  let t = ze + 1, n = Se.length;
  for (; t < n; ) {
    const o = t + n >>> 1, r = Se[o], s = Tn(r);
    s < e || s === e && r.flags & 2 ? t = o + 1 : n = o;
  }
  return t;
}
function wo(e) {
  if (!(e.flags & 1)) {
    const t = Tn(e), n = Se[Se.length - 1];
    !n || // fast path when the job id is larger than the tail
    !(e.flags & 2) && t >= Tn(n) ? Se.push(e) : Se.splice(Ec(t), 0, e), e.flags |= 1, pi();
  }
}
function pi() {
  to || (to = di.then(gi));
}
function hi(e) {
  N(e) ? qt.push(...e) : wt && e.id === -1 ? wt.splice(Wt + 1, 0, e) : e.flags & 1 || (qt.push(e), e.flags |= 1), pi();
}
function Wr(e, t, n = ze + 1) {
  for (t = t || /* @__PURE__ */ new Map(); n < Se.length; n++) {
    const o = Se[n];
    if (o && o.flags & 2) {
      if (e && o.id !== e.uid || Er(t, o))
        continue;
      Se.splice(n, 1), n--, o.flags & 4 && (o.flags &= -2), o(), o.flags & 4 || (o.flags &= -2);
    }
  }
}
function mi(e) {
  if (qt.length) {
    const t = [...new Set(qt)].sort(
      (n, o) => Tn(n) - Tn(o)
    );
    if (qt.length = 0, wt) {
      wt.push(...t);
      return;
    }
    for (wt = t, e = e || /* @__PURE__ */ new Map(), Wt = 0; Wt < wt.length; Wt++) {
      const n = wt[Wt];
      Er(e, n) || (n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), n.flags &= -2);
    }
    wt = null, Wt = 0;
  }
}
const Tn = (e) => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;
function gi(e) {
  e = e || /* @__PURE__ */ new Map();
  const t = (n) => Er(e, n);
  try {
    for (ze = 0; ze < Se.length; ze++) {
      const n = Se[ze];
      if (n && !(n.flags & 8)) {
        if (t(n))
          continue;
        n.flags & 4 && (n.flags &= -2), tn(
          n,
          n.i,
          n.i ? 15 : 14
        ), n.flags & 4 || (n.flags &= -2);
      }
    }
  } finally {
    for (; ze < Se.length; ze++) {
      const n = Se[ze];
      n && (n.flags &= -2);
    }
    ze = -1, Se.length = 0, mi(e), to = null, (Se.length || qt.length) && gi(e);
  }
}
function Er(e, t) {
  const n = e.get(t) || 0;
  if (n > Sc) {
    const o = t.i, r = o && Yi(o.type);
    return Mn(
      `Maximum recursive updates exceeded${r ? ` in component <${r}>` : ""}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`,
      null,
      10
    ), !0;
  }
  return e.set(t, n + 1), !1;
}
let Xe = !1;
const Wn = /* @__PURE__ */ new Map();
In().__VUE_HMR_RUNTIME__ = {
  createRecord: Io(vi),
  rerender: Io(Rc),
  reload: Io(Oc)
};
const Vt = /* @__PURE__ */ new Map();
function Cc(e) {
  const t = e.type.__hmrId;
  let n = Vt.get(t);
  n || (vi(t, e.type), n = Vt.get(t)), n.instances.add(e);
}
function Tc(e) {
  Vt.get(e.type.__hmrId).instances.delete(e);
}
function vi(e, t) {
  return Vt.has(e) ? !1 : (Vt.set(e, {
    initialDef: no(t),
    instances: /* @__PURE__ */ new Set()
  }), !0);
}
function no(e) {
  return Qi(e) ? e.__vccOpts : e;
}
function Rc(e, t) {
  const n = Vt.get(e);
  n && (n.initialDef.render = t, [...n.instances].forEach((o) => {
    t && (o.render = t, no(o.type).render = t), o.renderCache = [], Xe = !0, o.update(), Xe = !1;
  }));
}
function Oc(e, t) {
  const n = Vt.get(e);
  if (!n) return;
  t = no(t), Gr(n.initialDef, t);
  const o = [...n.instances];
  for (let r = 0; r < o.length; r++) {
    const s = o[r], i = no(s.type);
    let l = Wn.get(i);
    l || (i !== n.initialDef && Gr(i, t), Wn.set(i, l = /* @__PURE__ */ new Set())), l.add(s), s.appContext.propsCache.delete(s.type), s.appContext.emitsCache.delete(s.type), s.appContext.optionsCache.delete(s.type), s.ceReload ? (l.add(s), s.ceReload(t.styles), l.delete(s)) : s.parent ? wo(() => {
      Xe = !0, s.parent.update(), Xe = !1, l.delete(s);
    }) : s.appContext.reload ? s.appContext.reload() : typeof window < "u" ? window.location.reload() : console.warn(
      "[HMR] Root or manually mounted instance modified. Full reload required."
    ), s.root.ce && s !== s.root && s.root.ce._removeChildStyle(i);
  }
  hi(() => {
    Wn.clear();
  });
}
function Gr(e, t) {
  ce(e, t);
  for (const n in e)
    n !== "__file" && !(n in t) && delete e[n];
}
function Io(e) {
  return (t, n) => {
    try {
      return e(t, n);
    } catch (o) {
      console.error(o), console.warn(
        "[HMR] Something went wrong during Vue component hot-reload. Full reload required."
      );
    }
  };
}
let Ye, un = [], zo = !1;
function kn(e, ...t) {
  Ye ? Ye.emit(e, ...t) : zo || un.push({ event: e, args: t });
}
function yi(e, t) {
  var n, o;
  Ye = e, Ye ? (Ye.enabled = !0, un.forEach(({ event: r, args: s }) => Ye.emit(r, ...s)), un = []) : /* handle late devtools injection - only do this if we are in an actual */ /* browser environment to avoid the timer handle stalling test runner exit */ /* (#4815) */ typeof window < "u" && // some envs mock window but not fully
  window.HTMLElement && // also exclude jsdom
  // eslint-disable-next-line no-restricted-syntax
  !((o = (n = window.navigator) == null ? void 0 : n.userAgent) != null && o.includes("jsdom")) ? ((t.__VUE_DEVTOOLS_HOOK_REPLAY__ = t.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push((s) => {
    yi(s, t);
  }), setTimeout(() => {
    Ye || (t.__VUE_DEVTOOLS_HOOK_REPLAY__ = null, zo = !0, un = []);
  }, 3e3)) : (zo = !0, un = []);
}
function Pc(e, t) {
  kn("app:init", e, t, {
    Fragment: Ne,
    Text: jn,
    Comment: Ke,
    Static: qn
  });
}
function $c(e) {
  kn("app:unmount", e);
}
const Ac = /* @__PURE__ */ Cr(
  "component:added"
  /* COMPONENT_ADDED */
), bi = /* @__PURE__ */ Cr(
  "component:updated"
  /* COMPONENT_UPDATED */
), Ic = /* @__PURE__ */ Cr(
  "component:removed"
  /* COMPONENT_REMOVED */
), Mc = (e) => {
  Ye && typeof Ye.cleanupBuffer == "function" && // remove the component if it wasn't buffered
  !Ye.cleanupBuffer(e) && Ic(e);
};
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function Cr(e) {
  return (t) => {
    kn(
      e,
      t.appContext.app,
      t.uid,
      t.parent ? t.parent.uid : void 0,
      t
    );
  };
}
const kc = /* @__PURE__ */ _i(
  "perf:start"
  /* PERFORMANCE_START */
), jc = /* @__PURE__ */ _i(
  "perf:end"
  /* PERFORMANCE_END */
);
function _i(e) {
  return (t, n, o) => {
    kn(e, t.appContext.app, t.uid, t, n, o);
  };
}
function Dc(e, t, n) {
  kn(
    "component:emit",
    e.appContext.app,
    e,
    t,
    n
  );
}
let Ee = null, wi = null;
function oo(e) {
  const t = Ee;
  return Ee = e, wi = e && e.type.__scopeId || null, t;
}
function vn(e, t = Ee, n) {
  if (!t || e._n)
    return e;
  const o = (...r) => {
    o._d && os(-1);
    const s = oo(t);
    let i;
    try {
      i = e(...r);
    } finally {
      oo(s), o._d && os(1);
    }
    return bi(t), i;
  };
  return o._n = !0, o._c = !0, o._d = !0, o;
}
function xi(e) {
  Ol(e) && T("Do not use built-in directive ids as custom directive id: " + e);
}
function Yt(e, t) {
  if (Ee === null)
    return T("withDirectives can only be used inside render functions."), e;
  const n = Eo(Ee), o = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [s, i, l, c = Z] = t[r];
    s && (L(s) && (s = {
      mounted: s,
      updated: s
    }), s.deep && at(i), o.push({
      dir: s,
      instance: n,
      value: i,
      oldValue: void 0,
      arg: l,
      modifiers: c
    }));
  }
  return e;
}
function $t(e, t, n, o) {
  const r = e.dirs, s = t && t.dirs;
  for (let i = 0; i < r.length; i++) {
    const l = r[i];
    s && (l.oldValue = s[i].value);
    let c = l.dir[o];
    c && (ht(), nt(c, n, 8, [
      e.el,
      l,
      e,
      t
    ]), mt());
  }
}
const Nc = Symbol("_vte"), Fc = (e) => e.__isTeleport;
function Tr(e, t) {
  e.shapeFlag & 6 && e.component ? (e.transition = t, Tr(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function Si(e, t) {
  return L(e) ? (
    // #8236: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    ce({ name: e.name }, t, { setup: e })
  ) : e;
}
function Ei(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
const Hc = /* @__PURE__ */ new WeakSet();
function Jo(e, t, n, o, r = !1) {
  if (N(e)) {
    e.forEach(
      (y, b) => Jo(
        y,
        t && (N(t) ? t[b] : t),
        n,
        o,
        r
      )
    );
    return;
  }
  if (yn(o) && !r)
    return;
  const s = o.shapeFlag & 4 ? Eo(o.component) : o.el, i = r ? null : s, { i: l, r: c } = e;
  if (!l) {
    T(
      "Missing ref owner context. ref cannot be used on hoisted vnodes. A vnode with ref must be created inside the render function."
    );
    return;
  }
  const d = t && t.r, f = l.refs === Z ? l.refs = {} : l.refs, a = l.setupState, p = U(a), m = a === Z ? () => !1 : (y) => (J(p, y) && !ae(p[y]) && T(
    `Template ref "${y}" used on a non-ref value. It will not work in the production build.`
  ), Hc.has(p[y]) ? !1 : J(p, y));
  if (d != null && d !== c && (le(d) ? (f[d] = null, m(d) && (a[d] = null)) : ae(d) && (d.value = null)), L(c))
    tn(c, l, 12, [i, f]);
  else {
    const y = le(c), b = ae(c);
    if (y || b) {
      const M = () => {
        if (e.f) {
          const F = y ? m(c) ? a[c] : f[c] : c.value;
          r ? N(F) && pr(F, s) : N(F) ? F.includes(s) || F.push(s) : y ? (f[c] = [s], m(c) && (a[c] = f[c])) : (c.value = [s], e.k && (f[e.k] = c.value));
        } else y ? (f[c] = i, m(c) && (a[c] = i)) : b ? (c.value = i, e.k && (f[e.k] = i)) : T("Invalid template ref type:", c, `(${typeof c})`);
      };
      i ? (M.id = -1, Pe(M, n)) : M();
    } else
      T("Invalid template ref type:", c, `(${typeof c})`);
  }
}
In().requestIdleCallback;
In().cancelIdleCallback;
const yn = (e) => !!e.type.__asyncLoader, Rr = (e) => e.type.__isKeepAlive;
function Lc(e, t) {
  Ci(e, "a", t);
}
function Vc(e, t) {
  Ci(e, "da", t);
}
function Ci(e, t, n = he) {
  const o = e.__wdc || (e.__wdc = () => {
    let r = n;
    for (; r; ) {
      if (r.isDeactivated)
        return;
      r = r.parent;
    }
    return e();
  });
  if (xo(t, o, n), n) {
    let r = n.parent;
    for (; r && r.parent; )
      Rr(r.parent.vnode) && Uc(o, t, n, r), r = r.parent;
  }
}
function Uc(e, t, n, o) {
  const r = xo(
    t,
    e,
    o,
    !0
    /* prepend */
  );
  Ti(() => {
    pr(o[t], r);
  }, n);
}
function xo(e, t, n = he, o = !1) {
  if (n) {
    const r = n[e] || (n[e] = []), s = t.__weh || (t.__weh = (...i) => {
      ht();
      const l = Dn(n), c = nt(t, n, e, i);
      return l(), mt(), c;
    });
    return o ? r.unshift(s) : r.push(s), s;
  } else {
    const r = It(xr[e].replace(/ hook$/, ""));
    T(
      `${r} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup(). If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`
    );
  }
}
const gt = (e) => (t, n = he) => {
  (!On || e === "sp") && xo(e, (...o) => t(...o), n);
}, Kc = gt("bm"), Bc = gt("m"), Wc = gt(
  "bu"
), Gc = gt("u"), qc = gt(
  "bum"
), Ti = gt("um"), zc = gt(
  "sp"
), Jc = gt("rtg"), Yc = gt("rtc");
function Qc(e, t = he) {
  xo("ec", e, t);
}
const Xc = Symbol.for("v-ndc");
function Zc(e, t, n, o) {
  let r;
  const s = n, i = N(e);
  if (i || le(e)) {
    const l = i && Ft(e);
    let c = !1;
    l && (c = !Ce(e), e = vo(e)), r = new Array(e.length);
    for (let d = 0, f = e.length; d < f; d++)
      r[d] = t(
        c ? ye(e[d]) : e[d],
        d,
        void 0,
        s
      );
  } else if (typeof e == "number") {
    Number.isInteger(e) || T(`The v-for range expect an integer value but got ${e}.`), r = new Array(e);
    for (let l = 0; l < e; l++)
      r[l] = t(l + 1, l, void 0, s);
  } else if (Y(e))
    if (e[Symbol.iterator])
      r = Array.from(
        e,
        (l, c) => t(l, c, void 0, s)
      );
    else {
      const l = Object.keys(e);
      r = new Array(l.length);
      for (let c = 0, d = l.length; c < d; c++) {
        const f = l[c];
        r[c] = t(e[f], f, c, s);
      }
    }
  else
    r = [];
  return r;
}
const Yo = (e) => e ? zi(e) ? Eo(e) : Yo(e.parent) : null, Lt = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ ce(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => Qe(e.props),
    $attrs: (e) => Qe(e.attrs),
    $slots: (e) => Qe(e.slots),
    $refs: (e) => Qe(e.refs),
    $parent: (e) => Yo(e.parent),
    $root: (e) => Yo(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => Pr(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      wo(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Sr.bind(e.proxy)),
    $watch: (e) => Ia.bind(e)
  })
), Or = (e) => e === "_" || e === "$", Mo = (e, t) => e !== Z && !e.__isScriptSetup && J(e, t), Ri = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: n, setupState: o, data: r, props: s, accessCache: i, type: l, appContext: c } = e;
    if (t === "__isVue")
      return !0;
    let d;
    if (t[0] !== "$") {
      const m = i[t];
      if (m !== void 0)
        switch (m) {
          case 1:
            return o[t];
          case 2:
            return r[t];
          case 4:
            return n[t];
          case 3:
            return s[t];
        }
      else {
        if (Mo(o, t))
          return i[t] = 1, o[t];
        if (r !== Z && J(r, t))
          return i[t] = 2, r[t];
        if (
          // only cache other properties when instance has declared (thus stable)
          // props
          (d = e.propsOptions[0]) && J(d, t)
        )
          return i[t] = 3, s[t];
        if (n !== Z && J(n, t))
          return i[t] = 4, n[t];
        Qo && (i[t] = 0);
      }
    }
    const f = Lt[t];
    let a, p;
    if (f)
      return t === "$attrs" ? (pe(e.attrs, "get", ""), io()) : t === "$slots" && pe(e, "get", t), f(e);
    if (
      // css module (injected by vue-loader)
      (a = l.__cssModules) && (a = a[t])
    )
      return a;
    if (n !== Z && J(n, t))
      return i[t] = 4, n[t];
    if (
      // global properties
      p = c.config.globalProperties, J(p, t)
    )
      return p[t];
    Ee && (!le(t) || // #1091 avoid internal isRef/isVNode checks on component instance leading
    // to infinite warning loop
    t.indexOf("__v") !== 0) && (r !== Z && Or(t[0]) && J(r, t) ? T(
      `Property ${JSON.stringify(
        t
      )} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`
    ) : e === Ee && T(
      `Property ${JSON.stringify(t)} was accessed during render but is not defined on instance.`
    ));
  },
  set({ _: e }, t, n) {
    const { data: o, setupState: r, ctx: s } = e;
    return Mo(r, t) ? (r[t] = n, !0) : r.__isScriptSetup && J(r, t) ? (T(`Cannot mutate <script setup> binding "${t}" from Options API.`), !1) : o !== Z && J(o, t) ? (o[t] = n, !0) : J(e.props, t) ? (T(`Attempting to mutate prop "${t}". Props are readonly.`), !1) : t[0] === "$" && t.slice(1) in e ? (T(
      `Attempting to mutate public property "${t}". Properties starting with $ are reserved and readonly.`
    ), !1) : (t in e.appContext.config.globalProperties ? Object.defineProperty(s, t, {
      enumerable: !0,
      configurable: !0,
      value: n
    }) : s[t] = n, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: n, ctx: o, appContext: r, propsOptions: s }
  }, i) {
    let l;
    return !!n[i] || e !== Z && J(e, i) || Mo(t, i) || (l = s[0]) && J(l, i) || J(o, i) || J(Lt, i) || J(r.config.globalProperties, i);
  },
  defineProperty(e, t, n) {
    return n.get != null ? e._.accessCache[t] = 0 : J(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};
Ri.ownKeys = (e) => (T(
  "Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead."
), Reflect.ownKeys(e));
function ea(e) {
  const t = {};
  return Object.defineProperty(t, "_", {
    configurable: !0,
    enumerable: !1,
    get: () => e
  }), Object.keys(Lt).forEach((n) => {
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !1,
      get: () => Lt[n](e),
      // intercepted by the proxy so no need for implementation,
      // but needed to prevent set errors
      set: be
    });
  }), t;
}
function ta(e) {
  const {
    ctx: t,
    propsOptions: [n]
  } = e;
  n && Object.keys(n).forEach((o) => {
    Object.defineProperty(t, o, {
      enumerable: !0,
      configurable: !0,
      get: () => e.props[o],
      set: be
    });
  });
}
function na(e) {
  const { ctx: t, setupState: n } = e;
  Object.keys(U(n)).forEach((o) => {
    if (!n.__isScriptSetup) {
      if (Or(o[0])) {
        T(
          `setup() return property ${JSON.stringify(
            o
          )} should not start with "$" or "_" which are reserved prefixes for Vue internals.`
        );
        return;
      }
      Object.defineProperty(t, o, {
        enumerable: !0,
        configurable: !0,
        get: () => n[o],
        set: be
      });
    }
  });
}
function qr(e) {
  return N(e) ? e.reduce(
    (t, n) => (t[n] = null, t),
    {}
  ) : e;
}
function oa() {
  const e = /* @__PURE__ */ Object.create(null);
  return (t, n) => {
    e[n] ? T(`${t} property "${n}" is already defined in ${e[n]}.`) : e[n] = t;
  };
}
let Qo = !0;
function ra(e) {
  const t = Pr(e), n = e.proxy, o = e.ctx;
  Qo = !1, t.beforeCreate && zr(t.beforeCreate, e, "bc");
  const {
    // state
    data: r,
    computed: s,
    methods: i,
    watch: l,
    provide: c,
    inject: d,
    // lifecycle
    created: f,
    beforeMount: a,
    mounted: p,
    beforeUpdate: m,
    updated: y,
    activated: b,
    deactivated: M,
    beforeDestroy: F,
    beforeUnmount: j,
    destroyed: A,
    unmounted: te,
    render: I,
    renderTracked: ne,
    renderTriggered: re,
    errorCaptured: fe,
    serverPrefetch: de,
    // public API
    expose: Me,
    inheritAttrs: Fe,
    // assets
    components: Te,
    directives: Be,
    filters: Nn
  } = t, ke = oa();
  {
    const [W] = e.propsOptions;
    if (W)
      for (const G in W)
        ke("Props", G);
  }
  if (d && sa(d, o, ke), i)
    for (const W in i) {
      const G = i[W];
      L(G) ? (Object.defineProperty(o, W, {
        value: G.bind(n),
        configurable: !0,
        enumerable: !0,
        writable: !0
      }), ke("Methods", W)) : T(
        `Method "${W}" has type "${typeof G}" in the component definition. Did you reference the function correctly?`
      );
    }
  if (r) {
    L(r) || T(
      "The data option must be a function. Plain object usage is no longer supported."
    );
    const W = r.call(n, n);
    if (hr(W) && T(
      "data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>."
    ), !Y(W))
      T("data() should return an object.");
    else {
      e.data = bo(W);
      for (const G in W)
        ke("Data", G), Or(G[0]) || Object.defineProperty(o, G, {
          configurable: !0,
          enumerable: !0,
          get: () => W[G],
          set: be
        });
    }
  }
  if (Qo = !0, s)
    for (const W in s) {
      const G = s[W], je = L(G) ? G.bind(n, n) : L(G.get) ? G.get.bind(n, n) : be;
      je === be && T(`Computed property "${W}" has no getter.`);
      const Pt = !L(G) && L(G.set) ? G.set.bind(n) : () => {
        T(
          `Write operation failed: computed property "${W}" is readonly.`
        );
      }, vt = me({
        get: je,
        set: Pt
      });
      Object.defineProperty(o, W, {
        enumerable: !0,
        configurable: !0,
        get: () => vt.value,
        set: (We) => vt.value = We
      }), ke("Computed", W);
    }
  if (l)
    for (const W in l)
      Oi(l[W], o, n, W);
  if (c) {
    const W = L(c) ? c.call(n) : c;
    Reflect.ownKeys(W).forEach((G) => {
      Gn(G, W[G]);
    });
  }
  f && zr(f, e, "c");
  function ge(W, G) {
    N(G) ? G.forEach((je) => W(je.bind(n))) : G && W(G.bind(n));
  }
  if (ge(Kc, a), ge(Bc, p), ge(Wc, m), ge(Gc, y), ge(Lc, b), ge(Vc, M), ge(Qc, fe), ge(Yc, ne), ge(Jc, re), ge(qc, j), ge(Ti, te), ge(zc, de), N(Me))
    if (Me.length) {
      const W = e.exposed || (e.exposed = {});
      Me.forEach((G) => {
        Object.defineProperty(W, G, {
          get: () => n[G],
          set: (je) => n[G] = je
        });
      });
    } else e.exposed || (e.exposed = {});
  I && e.render === be && (e.render = I), Fe != null && (e.inheritAttrs = Fe), Te && (e.components = Te), Be && (e.directives = Be), de && Ei(e);
}
function sa(e, t, n = be) {
  N(e) && (e = Xo(e));
  for (const o in e) {
    const r = e[o];
    let s;
    Y(r) ? "default" in r ? s = Ze(
      r.from || o,
      r.default,
      !0
    ) : s = Ze(r.from || o) : s = Ze(r), ae(s) ? Object.defineProperty(t, o, {
      enumerable: !0,
      configurable: !0,
      get: () => s.value,
      set: (i) => s.value = i
    }) : t[o] = s, n("Inject", o);
  }
}
function zr(e, t, n) {
  nt(
    N(e) ? e.map((o) => o.bind(t.proxy)) : e.bind(t.proxy),
    t,
    n
  );
}
function Oi(e, t, n, o) {
  let r = o.includes(".") ? Li(n, o) : () => n[o];
  if (le(e)) {
    const s = t[e];
    L(s) ? bn(r, s) : T(`Invalid watch handler specified by key "${e}"`, s);
  } else if (L(e))
    bn(r, e.bind(n));
  else if (Y(e))
    if (N(e))
      e.forEach((s) => Oi(s, t, n, o));
    else {
      const s = L(e.handler) ? e.handler.bind(n) : t[e.handler];
      L(s) ? bn(r, s, e) : T(`Invalid watch handler specified by key "${e.handler}"`, s);
    }
  else
    T(`Invalid watch option: "${o}"`, e);
}
function Pr(e) {
  const t = e.type, { mixins: n, extends: o } = t, {
    mixins: r,
    optionsCache: s,
    config: { optionMergeStrategies: i }
  } = e.appContext, l = s.get(t);
  let c;
  return l ? c = l : !r.length && !n && !o ? c = t : (c = {}, r.length && r.forEach(
    (d) => ro(c, d, i, !0)
  ), ro(c, t, i)), Y(t) && s.set(t, c), c;
}
function ro(e, t, n, o = !1) {
  const { mixins: r, extends: s } = t;
  s && ro(e, s, n, !0), r && r.forEach(
    (i) => ro(e, i, n, !0)
  );
  for (const i in t)
    if (o && i === "expose")
      T(
        '"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.'
      );
    else {
      const l = ia[i] || n && n[i];
      e[i] = l ? l(e[i], t[i]) : t[i];
    }
  return e;
}
const ia = {
  data: Jr,
  props: Yr,
  emits: Yr,
  // objects
  methods: fn,
  computed: fn,
  // lifecycle
  beforeCreate: we,
  created: we,
  beforeMount: we,
  mounted: we,
  beforeUpdate: we,
  updated: we,
  beforeDestroy: we,
  beforeUnmount: we,
  destroyed: we,
  unmounted: we,
  activated: we,
  deactivated: we,
  errorCaptured: we,
  serverPrefetch: we,
  // assets
  components: fn,
  directives: fn,
  // watch
  watch: ca,
  // provide / inject
  provide: Jr,
  inject: la
};
function Jr(e, t) {
  return t ? e ? function() {
    return ce(
      L(e) ? e.call(this, this) : e,
      L(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function la(e, t) {
  return fn(Xo(e), Xo(t));
}
function Xo(e) {
  if (N(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++)
      t[e[n]] = e[n];
    return t;
  }
  return e;
}
function we(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function fn(e, t) {
  return e ? ce(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Yr(e, t) {
  return e ? N(e) && N(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : ce(
    /* @__PURE__ */ Object.create(null),
    qr(e),
    qr(t ?? {})
  ) : t;
}
function ca(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = ce(/* @__PURE__ */ Object.create(null), e);
  for (const o in t)
    n[o] = we(e[o], t[o]);
  return n;
}
function Pi() {
  return {
    app: null,
    config: {
      isNativeTag: Tl,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let aa = 0;
function ua(e, t) {
  return function(o, r = null) {
    L(o) || (o = ce({}, o)), r != null && !Y(r) && (T("root props passed to app.mount() must be an object."), r = null);
    const s = Pi(), i = /* @__PURE__ */ new WeakSet(), l = [];
    let c = !1;
    const d = s.app = {
      _uid: aa++,
      _component: o,
      _props: r,
      _container: null,
      _context: s,
      _instance: null,
      version: is,
      get config() {
        return s.config;
      },
      set config(f) {
        T(
          "app.config cannot be replaced. Modify individual options instead."
        );
      },
      use(f, ...a) {
        return i.has(f) ? T("Plugin has already been applied to target app.") : f && L(f.install) ? (i.add(f), f.install(d, ...a)) : L(f) ? (i.add(f), f(d, ...a)) : T(
          'A plugin must either be a function or an object with an "install" function.'
        ), d;
      },
      mixin(f) {
        return s.mixins.includes(f) ? T(
          "Mixin has already been applied to target app" + (f.name ? `: ${f.name}` : "")
        ) : s.mixins.push(f), d;
      },
      component(f, a) {
        return rr(f, s.config), a ? (s.components[f] && T(`Component "${f}" has already been registered in target app.`), s.components[f] = a, d) : s.components[f];
      },
      directive(f, a) {
        return xi(f), a ? (s.directives[f] && T(`Directive "${f}" has already been registered in target app.`), s.directives[f] = a, d) : s.directives[f];
      },
      mount(f, a, p) {
        if (c)
          T(
            "App has already been mounted.\nIf you want to remount the same app, move your app creation logic into a factory function and create fresh app instances for each mount - e.g. `const createMyApp = () => createApp(App)`"
          );
        else {
          f.__vue_app__ && T(
            "There is already an app instance mounted on the host container.\n If you want to mount another app on the same host container, you need to unmount the previous app by calling `app.unmount()` first."
          );
          const m = d._ceVNode || ue(o, r);
          return m.appContext = s, p === !0 ? p = "svg" : p === !1 && (p = void 0), s.reload = () => {
            e(
              Rt(m),
              f,
              p
            );
          }, a && t ? t(m, f) : e(m, f, p), c = !0, d._container = f, f.__vue_app__ = d, d._instance = m.component, Pc(d, is), Eo(m.component);
        }
      },
      onUnmount(f) {
        typeof f != "function" && T(
          `Expected function as first argument to app.onUnmount(), but got ${typeof f}`
        ), l.push(f);
      },
      unmount() {
        c ? (nt(
          l,
          d._instance,
          16
        ), e(null, d._container), d._instance = null, $c(d), delete d._container.__vue_app__) : T("Cannot unmount an app that is not mounted.");
      },
      provide(f, a) {
        return f in s.provides && T(
          `App already provides property with key "${String(f)}". It will be overwritten with the new value.`
        ), s.provides[f] = a, d;
      },
      runWithContext(f) {
        const a = zt;
        zt = d;
        try {
          return f();
        } finally {
          zt = a;
        }
      }
    };
    return d;
  };
}
let zt = null;
function Gn(e, t) {
  if (!he)
    T("provide() can only be used inside setup().");
  else {
    let n = he.provides;
    const o = he.parent && he.parent.provides;
    o === n && (n = he.provides = Object.create(o)), n[e] = t;
  }
}
function Ze(e, t, n = !1) {
  const o = he || Ee;
  if (o || zt) {
    const r = zt ? zt._context.provides : o ? o.parent == null ? o.vnode.appContext && o.vnode.appContext.provides : o.parent.provides : void 0;
    if (r && e in r)
      return r[e];
    if (arguments.length > 1)
      return n && L(t) ? t.call(o && o.proxy) : t;
    T(`injection "${String(e)}" not found.`);
  } else
    T("inject() can only be used inside setup() or functional components.");
}
const $i = {}, Ai = () => Object.create($i), Ii = (e) => Object.getPrototypeOf(e) === $i;
function fa(e, t, n, o = !1) {
  const r = {}, s = Ai();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), Mi(e, t, r, s);
  for (const i in e.propsOptions[0])
    i in r || (r[i] = void 0);
  ji(t || {}, r, e), n ? e.props = o ? r : li(r) : e.type.props ? e.props = r : e.props = s, e.attrs = s;
}
function da(e) {
  for (; e; ) {
    if (e.type.__hmrId) return !0;
    e = e.parent;
  }
}
function pa(e, t, n, o) {
  const {
    props: r,
    attrs: s,
    vnode: { patchFlag: i }
  } = e, l = U(r), [c] = e.propsOptions;
  let d = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    !da(e) && (o || i > 0) && !(i & 16)
  ) {
    if (i & 8) {
      const f = e.vnode.dynamicProps;
      for (let a = 0; a < f.length; a++) {
        let p = f[a];
        if (So(e.emitsOptions, p))
          continue;
        const m = t[p];
        if (c)
          if (J(s, p))
            m !== s[p] && (s[p] = m, d = !0);
          else {
            const y = Ve(p);
            r[y] = Zo(
              c,
              l,
              y,
              m,
              e,
              !1
            );
          }
        else
          m !== s[p] && (s[p] = m, d = !0);
      }
    }
  } else {
    Mi(e, t, r, s) && (d = !0);
    let f;
    for (const a in l)
      (!t || // for camelCase
      !J(t, a) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((f = ft(a)) === a || !J(t, f))) && (c ? n && // for camelCase
      (n[a] !== void 0 || // for kebab-case
      n[f] !== void 0) && (r[a] = Zo(
        c,
        l,
        a,
        void 0,
        e,
        !0
      )) : delete r[a]);
    if (s !== l)
      for (const a in s)
        (!t || !J(t, a)) && (delete s[a], d = !0);
  }
  d && Je(e.attrs, "set", ""), ji(t || {}, r, e);
}
function Mi(e, t, n, o) {
  const [r, s] = e.propsOptions;
  let i = !1, l;
  if (t)
    for (let c in t) {
      if (pn(c))
        continue;
      const d = t[c];
      let f;
      r && J(r, f = Ve(c)) ? !s || !s.includes(f) ? n[f] = d : (l || (l = {}))[f] = d : So(e.emitsOptions, c) || (!(c in o) || d !== o[c]) && (o[c] = d, i = !0);
    }
  if (s) {
    const c = U(n), d = l || Z;
    for (let f = 0; f < s.length; f++) {
      const a = s[f];
      n[a] = Zo(
        r,
        c,
        a,
        d[a],
        e,
        !J(d, a)
      );
    }
  }
  return i;
}
function Zo(e, t, n, o, r, s) {
  const i = e[n];
  if (i != null) {
    const l = J(i, "default");
    if (l && o === void 0) {
      const c = i.default;
      if (i.type !== Function && !i.skipFactory && L(c)) {
        const { propsDefaults: d } = r;
        if (n in d)
          o = d[n];
        else {
          const f = Dn(r);
          o = d[n] = c.call(
            null,
            t
          ), f();
        }
      } else
        o = c;
      r.ce && r.ce._setProp(n, o);
    }
    i[
      0
      /* shouldCast */
    ] && (s && !l ? o = !1 : i[
      1
      /* shouldCastTrue */
    ] && (o === "" || o === ft(n)) && (o = !0));
  }
  return o;
}
const ha = /* @__PURE__ */ new WeakMap();
function ki(e, t, n = !1) {
  const o = n ? ha : t.propsCache, r = o.get(e);
  if (r)
    return r;
  const s = e.props, i = {}, l = [];
  let c = !1;
  if (!L(e)) {
    const f = (a) => {
      c = !0;
      const [p, m] = ki(a, t, !0);
      ce(i, p), m && l.push(...m);
    };
    !n && t.mixins.length && t.mixins.forEach(f), e.extends && f(e.extends), e.mixins && e.mixins.forEach(f);
  }
  if (!s && !c)
    return Y(e) && o.set(e, Gt), Gt;
  if (N(s))
    for (let f = 0; f < s.length; f++) {
      le(s[f]) || T("props must be strings when using array syntax.", s[f]);
      const a = Ve(s[f]);
      Qr(a) && (i[a] = Z);
    }
  else if (s) {
    Y(s) || T("invalid props options", s);
    for (const f in s) {
      const a = Ve(f);
      if (Qr(a)) {
        const p = s[f], m = i[a] = N(p) || L(p) ? { type: p } : ce({}, p), y = m.type;
        let b = !1, M = !0;
        if (N(y))
          for (let F = 0; F < y.length; ++F) {
            const j = y[F], A = L(j) && j.name;
            if (A === "Boolean") {
              b = !0;
              break;
            } else A === "String" && (M = !1);
          }
        else
          b = L(y) && y.name === "Boolean";
        m[
          0
          /* shouldCast */
        ] = b, m[
          1
          /* shouldCastTrue */
        ] = M, (b || J(m, "default")) && l.push(a);
      }
    }
  }
  const d = [i, l];
  return Y(e) && o.set(e, d), d;
}
function Qr(e) {
  return e[0] !== "$" && !pn(e) ? !0 : (T(`Invalid prop name: "${e}" is a reserved property.`), !1);
}
function ma(e) {
  return e === null ? "null" : typeof e == "function" ? e.name || "" : typeof e == "object" && e.constructor && e.constructor.name || "";
}
function ji(e, t, n) {
  const o = U(t), r = n.propsOptions[0], s = Object.keys(e).map((i) => Ve(i));
  for (const i in r) {
    let l = r[i];
    l != null && ga(
      i,
      o[i],
      l,
      Qe(o),
      !s.includes(i)
    );
  }
}
function ga(e, t, n, o, r) {
  const { type: s, required: i, validator: l, skipCheck: c } = n;
  if (i && r) {
    T('Missing required prop: "' + e + '"');
    return;
  }
  if (!(t == null && !i)) {
    if (s != null && s !== !0 && !c) {
      let d = !1;
      const f = N(s) ? s : [s], a = [];
      for (let p = 0; p < f.length && !d; p++) {
        const { valid: m, expectedType: y } = ya(t, f[p]);
        a.push(y || ""), d = m;
      }
      if (!d) {
        T(ba(e, t, a));
        return;
      }
    }
    l && !l(t, o) && T('Invalid prop: custom validator check failed for prop "' + e + '".');
  }
}
const va = /* @__PURE__ */ pt(
  "String,Number,Boolean,Function,Symbol,BigInt"
);
function ya(e, t) {
  let n;
  const o = ma(t);
  if (o === "null")
    n = e === null;
  else if (va(o)) {
    const r = typeof e;
    n = r === o.toLowerCase(), !n && r === "object" && (n = e instanceof t);
  } else o === "Object" ? n = Y(e) : o === "Array" ? n = N(e) : n = e instanceof t;
  return {
    valid: n,
    expectedType: o
  };
}
function ba(e, t, n) {
  if (n.length === 0)
    return `Prop type [] for prop "${e}" won't match anything. Did you mean to use type Array instead?`;
  let o = `Invalid prop: type check failed for prop "${e}". Expected ${n.map(mo).join(" | ")}`;
  const r = n[0], s = mr(t), i = Xr(t, r), l = Xr(t, s);
  return n.length === 1 && Zr(r) && !_a(r, s) && (o += ` with value ${i}`), o += `, got ${s} `, Zr(s) && (o += `with value ${l}.`), o;
}
function Xr(e, t) {
  return t === "String" ? `"${e}"` : t === "Number" ? `${Number(e)}` : `${e}`;
}
function Zr(e) {
  return ["string", "number", "boolean"].some((n) => e.toLowerCase() === n);
}
function _a(...e) {
  return e.some((t) => t.toLowerCase() === "boolean");
}
const Di = (e) => e[0] === "_" || e === "$stable", $r = (e) => N(e) ? e.map(Le) : [Le(e)], wa = (e, t, n) => {
  if (t._n)
    return t;
  const o = vn((...r) => (he && (!n || n.root === he.root) && T(
    `Slot "${e}" invoked outside of the render function: this will not track dependencies used in the slot. Invoke the slot function inside the render function instead.`
  ), $r(t(...r))), n);
  return o._c = !1, o;
}, Ni = (e, t, n) => {
  const o = e._ctx;
  for (const r in e) {
    if (Di(r)) continue;
    const s = e[r];
    if (L(s))
      t[r] = wa(r, s, o);
    else if (s != null) {
      T(
        `Non-function value encountered for slot "${r}". Prefer function slots for better performance.`
      );
      const i = $r(s);
      t[r] = () => i;
    }
  }
}, Fi = (e, t) => {
  Rr(e.vnode) || T(
    "Non-function value encountered for default slot. Prefer function slots for better performance."
  );
  const n = $r(t);
  e.slots.default = () => n;
}, er = (e, t, n) => {
  for (const o in t)
    (n || o !== "_") && (e[o] = t[o]);
}, xa = (e, t, n) => {
  const o = e.slots = Ai();
  if (e.vnode.shapeFlag & 32) {
    const r = t._;
    r ? (er(o, t, n), n && Qn(o, "_", r, !0)) : Ni(t, o);
  } else t && Fi(e, t);
}, Sa = (e, t, n) => {
  const { vnode: o, slots: r } = e;
  let s = !0, i = Z;
  if (o.shapeFlag & 32) {
    const l = t._;
    l ? Xe ? (er(r, t, n), Je(e, "set", "$slots")) : n && l === 1 ? s = !1 : er(r, t, n) : (s = !t.$stable, Ni(t, r)), i = t;
  } else t && (Fi(e, t), i = { default: 1 });
  if (s)
    for (const l in r)
      !Di(l) && i[l] == null && delete r[l];
};
let rn, Et;
function st(e, t) {
  e.appContext.config.performance && so() && Et.mark(`vue-${t}-${e.uid}`), kc(e, t, so() ? Et.now() : Date.now());
}
function it(e, t) {
  if (e.appContext.config.performance && so()) {
    const n = `vue-${t}-${e.uid}`, o = n + ":end";
    Et.mark(o), Et.measure(
      `<${Co(e, e.type)}> ${t}`,
      n,
      o
    ), Et.clearMarks(n), Et.clearMarks(o);
  }
  jc(e, t, so() ? Et.now() : Date.now());
}
function so() {
  return rn !== void 0 || (typeof window < "u" && window.performance ? (rn = !0, Et = window.performance) : rn = !1), rn;
}
function Ea() {
  const e = [];
  if (e.length) {
    const t = e.length > 1;
    console.warn(
      `Feature flag${t ? "s" : ""} ${e.join(", ")} ${t ? "are" : "is"} not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.

For more details, see https://link.vuejs.org/feature-flags.`
    );
  }
}
const Pe = Ha;
function Ca(e) {
  return Ta(e);
}
function Ta(e, t) {
  Ea();
  const n = In();
  n.__VUE__ = !0, yi(n.__VUE_DEVTOOLS_GLOBAL_HOOK__, n);
  const {
    insert: o,
    remove: r,
    patchProp: s,
    createElement: i,
    createText: l,
    createComment: c,
    setText: d,
    setElementText: f,
    parentNode: a,
    nextSibling: p,
    setScopeId: m = be,
    insertStaticContent: y
  } = e, b = (u, h, g, _ = null, w = null, x = null, R = void 0, C = null, E = Xe ? !1 : !!h.dynamicChildren) => {
    if (u === h)
      return;
    u && !sn(u, h) && (_ = $(u), De(u, w, x, !0), u = null), h.patchFlag === -2 && (E = !1, h.dynamicChildren = null);
    const { type: S, ref: H, shapeFlag: O } = h;
    switch (S) {
      case jn:
        M(u, h, g, _);
        break;
      case Ke:
        F(u, h, g, _);
        break;
      case qn:
        u == null ? j(h, g, _, R) : A(u, h, g, R);
        break;
      case Ne:
        Be(
          u,
          h,
          g,
          _,
          w,
          x,
          R,
          C,
          E
        );
        break;
      default:
        O & 1 ? ne(
          u,
          h,
          g,
          _,
          w,
          x,
          R,
          C,
          E
        ) : O & 6 ? Nn(
          u,
          h,
          g,
          _,
          w,
          x,
          R,
          C,
          E
        ) : O & 64 || O & 128 ? S.process(
          u,
          h,
          g,
          _,
          w,
          x,
          R,
          C,
          E,
          q
        ) : T("Invalid VNode type:", S, `(${typeof S})`);
    }
    H != null && w && Jo(H, u && u.ref, x, h || u, !h);
  }, M = (u, h, g, _) => {
    if (u == null)
      o(
        h.el = l(h.children),
        g,
        _
      );
    else {
      const w = h.el = u.el;
      h.children !== u.children && d(w, h.children);
    }
  }, F = (u, h, g, _) => {
    u == null ? o(
      h.el = c(h.children || ""),
      g,
      _
    ) : h.el = u.el;
  }, j = (u, h, g, _) => {
    [u.el, u.anchor] = y(
      u.children,
      h,
      g,
      _,
      u.el,
      u.anchor
    );
  }, A = (u, h, g, _) => {
    if (h.children !== u.children) {
      const w = p(u.anchor);
      I(u), [h.el, h.anchor] = y(
        h.children,
        g,
        w,
        _
      );
    } else
      h.el = u.el, h.anchor = u.anchor;
  }, te = ({ el: u, anchor: h }, g, _) => {
    let w;
    for (; u && u !== h; )
      w = p(u), o(u, g, _), u = w;
    o(h, g, _);
  }, I = ({ el: u, anchor: h }) => {
    let g;
    for (; u && u !== h; )
      g = p(u), r(u), u = g;
    r(h);
  }, ne = (u, h, g, _, w, x, R, C, E) => {
    h.type === "svg" ? R = "svg" : h.type === "math" && (R = "mathml"), u == null ? re(
      h,
      g,
      _,
      w,
      x,
      R,
      C,
      E
    ) : Me(
      u,
      h,
      w,
      x,
      R,
      C,
      E
    );
  }, re = (u, h, g, _, w, x, R, C) => {
    let E, S;
    const { props: H, shapeFlag: O, transition: D, dirs: V } = u;
    if (E = u.el = i(
      u.type,
      x,
      H && H.is,
      H
    ), O & 8 ? f(E, u.children) : O & 16 && de(
      u.children,
      E,
      null,
      _,
      w,
      ko(u, x),
      R,
      C
    ), V && $t(u, null, _, "created"), fe(E, u, u.scopeId, R, _), H) {
      for (const oe in H)
        oe !== "value" && !pn(oe) && s(E, oe, null, H[oe], x, _);
      "value" in H && s(E, "value", null, H.value, x), (S = H.onVnodeBeforeMount) && qe(S, _, u);
    }
    Qn(E, "__vnode", u, !0), Qn(E, "__vueParentComponent", _, !0), V && $t(u, null, _, "beforeMount");
    const z = Ra(w, D);
    z && D.beforeEnter(E), o(E, h, g), ((S = H && H.onVnodeMounted) || z || V) && Pe(() => {
      S && qe(S, _, u), z && D.enter(E), V && $t(u, null, _, "mounted");
    }, w);
  }, fe = (u, h, g, _, w) => {
    if (g && m(u, g), _)
      for (let x = 0; x < _.length; x++)
        m(u, _[x]);
    if (w) {
      let x = w.subTree;
      if (x.patchFlag > 0 && x.patchFlag & 2048 && (x = Ir(x.children) || x), h === x || Ki(x.type) && (x.ssContent === h || x.ssFallback === h)) {
        const R = w.vnode;
        fe(
          u,
          R,
          R.scopeId,
          R.slotScopeIds,
          w.parent
        );
      }
    }
  }, de = (u, h, g, _, w, x, R, C, E = 0) => {
    for (let S = E; S < u.length; S++) {
      const H = u[S] = C ? xt(u[S]) : Le(u[S]);
      b(
        null,
        H,
        h,
        g,
        _,
        w,
        x,
        R,
        C
      );
    }
  }, Me = (u, h, g, _, w, x, R) => {
    const C = h.el = u.el;
    C.__vnode = h;
    let { patchFlag: E, dynamicChildren: S, dirs: H } = h;
    E |= u.patchFlag & 16;
    const O = u.props || Z, D = h.props || Z;
    let V;
    if (g && At(g, !1), (V = D.onVnodeBeforeUpdate) && qe(V, g, h, u), H && $t(h, u, g, "beforeUpdate"), g && At(g, !0), Xe && (E = 0, R = !1, S = null), (O.innerHTML && D.innerHTML == null || O.textContent && D.textContent == null) && f(C, ""), S ? (Fe(
      u.dynamicChildren,
      S,
      C,
      g,
      _,
      ko(h, w),
      x
    ), tr(u, h)) : R || je(
      u,
      h,
      C,
      null,
      g,
      _,
      ko(h, w),
      x,
      !1
    ), E > 0) {
      if (E & 16)
        Te(C, O, D, g, w);
      else if (E & 2 && O.class !== D.class && s(C, "class", null, D.class, w), E & 4 && s(C, "style", O.style, D.style, w), E & 8) {
        const z = h.dynamicProps;
        for (let oe = 0; oe < z.length; oe++) {
          const ee = z[oe], Re = O[ee], ve = D[ee];
          (ve !== Re || ee === "value") && s(C, ee, Re, ve, w, g);
        }
      }
      E & 1 && u.children !== h.children && f(C, h.children);
    } else !R && S == null && Te(C, O, D, g, w);
    ((V = D.onVnodeUpdated) || H) && Pe(() => {
      V && qe(V, g, h, u), H && $t(h, u, g, "updated");
    }, _);
  }, Fe = (u, h, g, _, w, x, R) => {
    for (let C = 0; C < h.length; C++) {
      const E = u[C], S = h[C], H = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        E.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (E.type === Ne || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !sn(E, S) || // - In the case of a component, it could contain anything.
        E.shapeFlag & 70) ? a(E.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          g
        )
      );
      b(
        E,
        S,
        H,
        null,
        _,
        w,
        x,
        R,
        !0
      );
    }
  }, Te = (u, h, g, _, w) => {
    if (h !== g) {
      if (h !== Z)
        for (const x in h)
          !pn(x) && !(x in g) && s(
            u,
            x,
            h[x],
            null,
            w,
            _
          );
      for (const x in g) {
        if (pn(x)) continue;
        const R = g[x], C = h[x];
        R !== C && x !== "value" && s(u, x, C, R, w, _);
      }
      "value" in g && s(u, "value", h.value, g.value, w);
    }
  }, Be = (u, h, g, _, w, x, R, C, E) => {
    const S = h.el = u ? u.el : l(""), H = h.anchor = u ? u.anchor : l("");
    let { patchFlag: O, dynamicChildren: D, slotScopeIds: V } = h;
    // #5523 dev root fragment may inherit directives
    (Xe || O & 2048) && (O = 0, E = !1, D = null), V && (C = C ? C.concat(V) : V), u == null ? (o(S, g, _), o(H, g, _), de(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      h.children || [],
      g,
      H,
      w,
      x,
      R,
      C,
      E
    )) : O > 0 && O & 64 && D && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    u.dynamicChildren ? (Fe(
      u.dynamicChildren,
      D,
      g,
      w,
      x,
      R,
      C
    ), tr(u, h)) : je(
      u,
      h,
      g,
      H,
      w,
      x,
      R,
      C,
      E
    );
  }, Nn = (u, h, g, _, w, x, R, C, E) => {
    h.slotScopeIds = C, u == null ? h.shapeFlag & 512 ? w.ctx.activate(
      h,
      g,
      _,
      R,
      E
    ) : ke(
      h,
      g,
      _,
      w,
      x,
      R,
      E
    ) : ge(u, h, E);
  }, ke = (u, h, g, _, w, x, R) => {
    const C = u.component = qa(
      u,
      _,
      w
    );
    if (C.type.__hmrId && Cc(C), Kn(u), st(C, "mount"), Rr(u) && (C.ctx.renderer = q), st(C, "init"), Ja(C, !1, R), it(C, "init"), C.asyncDep) {
      if (Xe && (u.el = null), w && w.registerDep(C, W, R), !u.el) {
        const E = C.subTree = ue(Ke);
        F(null, E, h, g);
      }
    } else
      W(
        C,
        u,
        h,
        g,
        w,
        x,
        R
      );
    Bn(), it(C, "mount");
  }, ge = (u, h, g) => {
    const _ = h.component = u.component;
    if (Na(u, h, g))
      if (_.asyncDep && !_.asyncResolved) {
        Kn(h), G(_, h, g), Bn();
        return;
      } else
        _.next = h, _.update();
    else
      h.el = u.el, _.vnode = h;
  }, W = (u, h, g, _, w, x, R) => {
    const C = () => {
      if (u.isMounted) {
        let { next: O, bu: D, u: V, parent: z, vnode: oe } = u;
        {
          const Oe = Hi(u);
          if (Oe) {
            O && (O.el = oe.el, G(u, O, R)), Oe.asyncDep.then(() => {
              u.isUnmounted || C();
            });
            return;
          }
        }
        let ee = O, Re;
        Kn(O || u.vnode), At(u, !1), O ? (O.el = oe.el, G(u, O, R)) : O = oe, D && Bt(D), (Re = O.props && O.props.onVnodeBeforeUpdate) && qe(Re, z, O, oe), At(u, !0), st(u, "render");
        const ve = jo(u);
        it(u, "render");
        const He = u.subTree;
        u.subTree = ve, st(u, "patch"), b(
          He,
          ve,
          // parent may have changed if it's in a teleport
          a(He.el),
          // anchor may have changed if it's in a fragment
          $(He),
          u,
          w,
          x
        ), it(u, "patch"), O.el = ve.el, ee === null && Fa(u, ve.el), V && Pe(V, w), (Re = O.props && O.props.onVnodeUpdated) && Pe(
          () => qe(Re, z, O, oe),
          w
        ), bi(u), Bn();
      } else {
        let O;
        const { el: D, props: V } = h, { bm: z, m: oe, parent: ee, root: Re, type: ve } = u, He = yn(h);
        if (At(u, !1), z && Bt(z), !He && (O = V && V.onVnodeBeforeMount) && qe(O, ee, h), At(u, !0), D && B) {
          const Oe = () => {
            st(u, "render"), u.subTree = jo(u), it(u, "render"), st(u, "hydrate"), B(
              D,
              u.subTree,
              u,
              w,
              null
            ), it(u, "hydrate");
          };
          He && ve.__asyncHydrate ? ve.__asyncHydrate(
            D,
            u,
            Oe
          ) : Oe();
        } else {
          Re.ce && Re.ce._injectChildStyle(ve), st(u, "render");
          const Oe = u.subTree = jo(u);
          it(u, "render"), st(u, "patch"), b(
            null,
            Oe,
            g,
            _,
            u,
            w,
            x
          ), it(u, "patch"), h.el = Oe.el;
        }
        if (oe && Pe(oe, w), !He && (O = V && V.onVnodeMounted)) {
          const Oe = h;
          Pe(
            () => qe(O, ee, Oe),
            w
          );
        }
        (h.shapeFlag & 256 || ee && yn(ee.vnode) && ee.vnode.shapeFlag & 256) && u.a && Pe(u.a, w), u.isMounted = !0, Ac(u), h = g = _ = null;
      }
    };
    u.scope.on();
    const E = u.effect = new Ws(C);
    u.scope.off();
    const S = u.update = E.run.bind(E), H = u.job = E.runIfDirty.bind(E);
    H.i = u, H.id = u.uid, E.scheduler = () => wo(H), At(u, !0), E.onTrack = u.rtc ? (O) => Bt(u.rtc, O) : void 0, E.onTrigger = u.rtg ? (O) => Bt(u.rtg, O) : void 0, S();
  }, G = (u, h, g) => {
    h.component = u;
    const _ = u.vnode.props;
    u.vnode = h, u.next = null, pa(u, h.props, _, g), Sa(u, h.children, g), ht(), Wr(u), mt();
  }, je = (u, h, g, _, w, x, R, C, E = !1) => {
    const S = u && u.children, H = u ? u.shapeFlag : 0, O = h.children, { patchFlag: D, shapeFlag: V } = h;
    if (D > 0) {
      if (D & 128) {
        vt(
          S,
          O,
          g,
          _,
          w,
          x,
          R,
          C,
          E
        );
        return;
      } else if (D & 256) {
        Pt(
          S,
          O,
          g,
          _,
          w,
          x,
          R,
          C,
          E
        );
        return;
      }
    }
    V & 8 ? (H & 16 && v(S, w, x), O !== S && f(g, O)) : H & 16 ? V & 16 ? vt(
      S,
      O,
      g,
      _,
      w,
      x,
      R,
      C,
      E
    ) : v(S, w, x, !0) : (H & 8 && f(g, ""), V & 16 && de(
      O,
      g,
      _,
      w,
      x,
      R,
      C,
      E
    ));
  }, Pt = (u, h, g, _, w, x, R, C, E) => {
    u = u || Gt, h = h || Gt;
    const S = u.length, H = h.length, O = Math.min(S, H);
    let D;
    for (D = 0; D < O; D++) {
      const V = h[D] = E ? xt(h[D]) : Le(h[D]);
      b(
        u[D],
        V,
        g,
        null,
        w,
        x,
        R,
        C,
        E
      );
    }
    S > H ? v(
      u,
      w,
      x,
      !0,
      !1,
      O
    ) : de(
      h,
      g,
      _,
      w,
      x,
      R,
      C,
      E,
      O
    );
  }, vt = (u, h, g, _, w, x, R, C, E) => {
    let S = 0;
    const H = h.length;
    let O = u.length - 1, D = H - 1;
    for (; S <= O && S <= D; ) {
      const V = u[S], z = h[S] = E ? xt(h[S]) : Le(h[S]);
      if (sn(V, z))
        b(
          V,
          z,
          g,
          null,
          w,
          x,
          R,
          C,
          E
        );
      else
        break;
      S++;
    }
    for (; S <= O && S <= D; ) {
      const V = u[O], z = h[D] = E ? xt(h[D]) : Le(h[D]);
      if (sn(V, z))
        b(
          V,
          z,
          g,
          null,
          w,
          x,
          R,
          C,
          E
        );
      else
        break;
      O--, D--;
    }
    if (S > O) {
      if (S <= D) {
        const V = D + 1, z = V < H ? h[V].el : _;
        for (; S <= D; )
          b(
            null,
            h[S] = E ? xt(h[S]) : Le(h[S]),
            g,
            z,
            w,
            x,
            R,
            C,
            E
          ), S++;
      }
    } else if (S > D)
      for (; S <= O; )
        De(u[S], w, x, !0), S++;
    else {
      const V = S, z = S, oe = /* @__PURE__ */ new Map();
      for (S = z; S <= D; S++) {
        const _e = h[S] = E ? xt(h[S]) : Le(h[S]);
        _e.key != null && (oe.has(_e.key) && T(
          "Duplicate keys found during update:",
          JSON.stringify(_e.key),
          "Make sure keys are unique."
        ), oe.set(_e.key, S));
      }
      let ee, Re = 0;
      const ve = D - z + 1;
      let He = !1, Oe = 0;
      const nn = new Array(ve);
      for (S = 0; S < ve; S++) nn[S] = 0;
      for (S = V; S <= O; S++) {
        const _e = u[S];
        if (Re >= ve) {
          De(_e, w, x, !0);
          continue;
        }
        let Ge;
        if (_e.key != null)
          Ge = oe.get(_e.key);
        else
          for (ee = z; ee <= D; ee++)
            if (nn[ee - z] === 0 && sn(_e, h[ee])) {
              Ge = ee;
              break;
            }
        Ge === void 0 ? De(_e, w, x, !0) : (nn[Ge - z] = S + 1, Ge >= Oe ? Oe = Ge : He = !0, b(
          _e,
          h[Ge],
          g,
          null,
          w,
          x,
          R,
          C,
          E
        ), Re++);
      }
      const Fr = He ? Oa(nn) : Gt;
      for (ee = Fr.length - 1, S = ve - 1; S >= 0; S--) {
        const _e = z + S, Ge = h[_e], Hr = _e + 1 < H ? h[_e + 1].el : _;
        nn[S] === 0 ? b(
          null,
          Ge,
          g,
          Hr,
          w,
          x,
          R,
          C,
          E
        ) : He && (ee < 0 || S !== Fr[ee] ? We(Ge, g, Hr, 2) : ee--);
      }
    }
  }, We = (u, h, g, _, w = null) => {
    const { el: x, type: R, transition: C, children: E, shapeFlag: S } = u;
    if (S & 6) {
      We(u.component.subTree, h, g, _);
      return;
    }
    if (S & 128) {
      u.suspense.move(h, g, _);
      return;
    }
    if (S & 64) {
      R.move(u, h, g, q);
      return;
    }
    if (R === Ne) {
      o(x, h, g);
      for (let O = 0; O < E.length; O++)
        We(E[O], h, g, _);
      o(u.anchor, h, g);
      return;
    }
    if (R === qn) {
      te(u, h, g);
      return;
    }
    if (_ !== 2 && S & 1 && C)
      if (_ === 0)
        C.beforeEnter(x), o(x, h, g), Pe(() => C.enter(x), w);
      else {
        const { leave: O, delayLeave: D, afterLeave: V } = C, z = () => o(x, h, g), oe = () => {
          O(x, () => {
            z(), V && V();
          });
        };
        D ? D(x, z, oe) : oe();
      }
    else
      o(x, h, g);
  }, De = (u, h, g, _ = !1, w = !1) => {
    const {
      type: x,
      props: R,
      ref: C,
      children: E,
      dynamicChildren: S,
      shapeFlag: H,
      patchFlag: O,
      dirs: D,
      cacheIndex: V
    } = u;
    if (O === -2 && (w = !1), C != null && Jo(C, null, g, u, !0), V != null && (h.renderCache[V] = void 0), H & 256) {
      h.ctx.deactivate(u);
      return;
    }
    const z = H & 1 && D, oe = !yn(u);
    let ee;
    if (oe && (ee = R && R.onVnodeBeforeUnmount) && qe(ee, h, u), H & 6)
      bt(u.component, g, _);
    else {
      if (H & 128) {
        u.suspense.unmount(g, _);
        return;
      }
      z && $t(u, null, h, "beforeUnmount"), H & 64 ? u.type.remove(
        u,
        h,
        g,
        q,
        _
      ) : S && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !S.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (x !== Ne || O > 0 && O & 64) ? v(
        S,
        h,
        g,
        !1,
        !0
      ) : (x === Ne && O & 384 || !w && H & 16) && v(E, h, g), _ && yt(u);
    }
    (oe && (ee = R && R.onVnodeUnmounted) || z) && Pe(() => {
      ee && qe(ee, h, u), z && $t(u, null, h, "unmounted");
    }, g);
  }, yt = (u) => {
    const { type: h, el: g, anchor: _, transition: w } = u;
    if (h === Ne) {
      u.patchFlag > 0 && u.patchFlag & 2048 && w && !w.persisted ? u.children.forEach((R) => {
        R.type === Ke ? r(R.el) : yt(R);
      }) : Fn(g, _);
      return;
    }
    if (h === qn) {
      I(u);
      return;
    }
    const x = () => {
      r(g), w && !w.persisted && w.afterLeave && w.afterLeave();
    };
    if (u.shapeFlag & 1 && w && !w.persisted) {
      const { leave: R, delayLeave: C } = w, E = () => R(g, x);
      C ? C(u.el, x, E) : E();
    } else
      x();
  }, Fn = (u, h) => {
    let g;
    for (; u !== h; )
      g = p(u), r(u), u = g;
    r(h);
  }, bt = (u, h, g) => {
    u.type.__hmrId && Tc(u);
    const { bum: _, scope: w, job: x, subTree: R, um: C, m: E, a: S } = u;
    es(E), es(S), _ && Bt(_), w.stop(), x && (x.flags |= 8, De(R, u, h, g)), C && Pe(C, h), Pe(() => {
      u.isUnmounted = !0;
    }, h), h && h.pendingBranch && !h.isUnmounted && u.asyncDep && !u.asyncResolved && u.suspenseId === h.pendingId && (h.deps--, h.deps === 0 && h.resolve()), Mc(u);
  }, v = (u, h, g, _ = !1, w = !1, x = 0) => {
    for (let R = x; R < u.length; R++)
      De(u[R], h, g, _, w);
  }, $ = (u) => {
    if (u.shapeFlag & 6)
      return $(u.component.subTree);
    if (u.shapeFlag & 128)
      return u.suspense.next();
    const h = p(u.anchor || u.el), g = h && h[Nc];
    return g ? p(g) : h;
  };
  let P = !1;
  const k = (u, h, g) => {
    u == null ? h._vnode && De(h._vnode, null, null, !0) : b(
      h._vnode || null,
      u,
      h,
      null,
      null,
      null,
      g
    ), h._vnode = u, P || (P = !0, Wr(), mi(), P = !1);
  }, q = {
    p: b,
    um: De,
    m: We,
    r: yt,
    mt: ke,
    mc: de,
    pc: je,
    pbc: Fe,
    n: $,
    o: e
  };
  let se, B;
  return {
    render: k,
    hydrate: se,
    createApp: ua(k, se)
  };
}
function ko({ type: e, props: t }, n) {
  return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function At({ effect: e, job: t }, n) {
  n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Ra(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function tr(e, t, n = !1) {
  const o = e.children, r = t.children;
  if (N(o) && N(r))
    for (let s = 0; s < o.length; s++) {
      const i = o[s];
      let l = r[s];
      l.shapeFlag & 1 && !l.dynamicChildren && ((l.patchFlag <= 0 || l.patchFlag === 32) && (l = r[s] = xt(r[s]), l.el = i.el), !n && l.patchFlag !== -2 && tr(i, l)), l.type === jn && (l.el = i.el), l.type === Ke && !l.el && (l.el = i.el);
    }
}
function Oa(e) {
  const t = e.slice(), n = [0];
  let o, r, s, i, l;
  const c = e.length;
  for (o = 0; o < c; o++) {
    const d = e[o];
    if (d !== 0) {
      if (r = n[n.length - 1], e[r] < d) {
        t[o] = r, n.push(o);
        continue;
      }
      for (s = 0, i = n.length - 1; s < i; )
        l = s + i >> 1, e[n[l]] < d ? s = l + 1 : i = l;
      d < e[n[s]] && (s > 0 && (t[o] = n[s - 1]), n[s] = o);
    }
  }
  for (s = n.length, i = n[s - 1]; s-- > 0; )
    n[s] = i, i = t[i];
  return n;
}
function Hi(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : Hi(t);
}
function es(e) {
  if (e)
    for (let t = 0; t < e.length; t++)
      e[t].flags |= 8;
}
const Pa = Symbol.for("v-scx"), $a = () => {
  {
    const e = Ze(Pa);
    return e || T(
      "Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build."
    ), e;
  }
};
function Aa(e, t) {
  return Ar(e, null, t);
}
function bn(e, t, n) {
  return L(t) || T(
    "`watch(fn, options?)` signature has been moved to a separate API. Use `watchEffect(fn, options?)` instead. `watch` now only supports `watch(source, cb, options?) signature."
  ), Ar(e, t, n);
}
function Ar(e, t, n = Z) {
  const { immediate: o, deep: r, flush: s, once: i } = n;
  t || (o !== void 0 && T(
    'watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.'
  ), r !== void 0 && T(
    'watch() "deep" option is only respected when using the watch(source, callback, options?) signature.'
  ), i !== void 0 && T(
    'watch() "once" option is only respected when using the watch(source, callback, options?) signature.'
  ));
  const l = ce({}, n);
  l.onWarn = T;
  const c = t && o || !t && s !== "post";
  let d;
  if (On) {
    if (s === "sync") {
      const m = $a();
      d = m.__watcherHandles || (m.__watcherHandles = []);
    } else if (!c) {
      const m = () => {
      };
      return m.stop = be, m.resume = be, m.pause = be, m;
    }
  }
  const f = he;
  l.call = (m, y, b) => nt(m, f, y, b);
  let a = !1;
  s === "post" ? l.scheduler = (m) => {
    Pe(m, f && f.suspense);
  } : s !== "sync" && (a = !0, l.scheduler = (m, y) => {
    y ? m() : wo(m);
  }), l.augmentJob = (m) => {
    t && (m.flags |= 4), a && (m.flags |= 2, f && (m.id = f.uid, m.i = f));
  };
  const p = vc(e, t, l);
  return On && (d ? d.push(p) : c && p()), p;
}
function Ia(e, t, n) {
  const o = this.proxy, r = le(e) ? e.includes(".") ? Li(o, e) : () => o[e] : e.bind(o, o);
  let s;
  L(t) ? s = t : (s = t.handler, n = t);
  const i = Dn(this), l = Ar(r, s.bind(o), n);
  return i(), l;
}
function Li(e, t) {
  const n = t.split(".");
  return () => {
    let o = e;
    for (let r = 0; r < n.length && o; r++)
      o = o[n[r]];
    return o;
  };
}
const Ma = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${Ve(t)}Modifiers`] || e[`${ft(t)}Modifiers`];
function ka(e, t, ...n) {
  if (e.isUnmounted) return;
  const o = e.vnode.props || Z;
  {
    const {
      emitsOptions: f,
      propsOptions: [a]
    } = e;
    if (f)
      if (!(t in f))
        (!a || !(It(Ve(t)) in a)) && T(
          `Component emitted event "${t}" but it is neither declared in the emits option nor as an "${It(Ve(t))}" prop.`
        );
      else {
        const p = f[t];
        L(p) && (p(...n) || T(
          `Invalid event arguments: event validation failed for event "${t}".`
        ));
      }
  }
  let r = n;
  const s = t.startsWith("update:"), i = s && Ma(o, t.slice(7));
  i && (i.trim && (r = n.map((f) => le(f) ? f.trim() : f)), i.number && (r = n.map(Uo))), Dc(e, t, r);
  {
    const f = t.toLowerCase();
    f !== t && o[It(f)] && T(
      `Event "${f}" is emitted in component ${Co(
        e,
        e.type
      )} but the handler is registered for "${t}". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "${ft(
        t
      )}" instead of "${t}".`
    );
  }
  let l, c = o[l = It(t)] || // also try camelCase event handler (#2249)
  o[l = It(Ve(t))];
  !c && s && (c = o[l = It(ft(t))]), c && nt(
    c,
    e,
    6,
    r
  );
  const d = o[l + "Once"];
  if (d) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[l])
      return;
    e.emitted[l] = !0, nt(
      d,
      e,
      6,
      r
    );
  }
}
function Vi(e, t, n = !1) {
  const o = t.emitsCache, r = o.get(e);
  if (r !== void 0)
    return r;
  const s = e.emits;
  let i = {}, l = !1;
  if (!L(e)) {
    const c = (d) => {
      const f = Vi(d, t, !0);
      f && (l = !0, ce(i, f));
    };
    !n && t.mixins.length && t.mixins.forEach(c), e.extends && c(e.extends), e.mixins && e.mixins.forEach(c);
  }
  return !s && !l ? (Y(e) && o.set(e, null), null) : (N(s) ? s.forEach((c) => i[c] = null) : ce(i, s), Y(e) && o.set(e, i), i);
}
function So(e, t) {
  return !e || !$n(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), J(e, t[0].toLowerCase() + t.slice(1)) || J(e, ft(t)) || J(e, t));
}
let nr = !1;
function io() {
  nr = !0;
}
function jo(e) {
  const {
    type: t,
    vnode: n,
    proxy: o,
    withProxy: r,
    propsOptions: [s],
    slots: i,
    attrs: l,
    emit: c,
    render: d,
    renderCache: f,
    props: a,
    data: p,
    setupState: m,
    ctx: y,
    inheritAttrs: b
  } = e, M = oo(e);
  let F, j;
  nr = !1;
  try {
    if (n.shapeFlag & 4) {
      const I = r || o, ne = m.__isScriptSetup ? new Proxy(I, {
        get(re, fe, de) {
          return T(
            `Property '${String(
              fe
            )}' was accessed via 'this'. Avoid using 'this' in templates.`
          ), Reflect.get(re, fe, de);
        }
      }) : I;
      F = Le(
        d.call(
          ne,
          I,
          f,
          Qe(a),
          m,
          p,
          y
        )
      ), j = l;
    } else {
      const I = t;
      l === a && io(), F = Le(
        I.length > 1 ? I(
          Qe(a),
          {
            get attrs() {
              return io(), Qe(l);
            },
            slots: i,
            emit: c
          }
        ) : I(
          Qe(a),
          null
        )
      ), j = t.props ? l : ja(l);
    }
  } catch (I) {
    _n.length = 0, Mn(I, e, 1), F = ue(Ke);
  }
  let A = F, te;
  if (F.patchFlag > 0 && F.patchFlag & 2048 && ([A, te] = Ui(F)), j && b !== !1) {
    const I = Object.keys(j), { shapeFlag: ne } = A;
    if (I.length) {
      if (ne & 7)
        s && I.some(Yn) && (j = Da(
          j,
          s
        )), A = Rt(A, j, !1, !0);
      else if (!nr && A.type !== Ke) {
        const re = Object.keys(l), fe = [], de = [];
        for (let Me = 0, Fe = re.length; Me < Fe; Me++) {
          const Te = re[Me];
          $n(Te) ? Yn(Te) || fe.push(Te[2].toLowerCase() + Te.slice(3)) : de.push(Te);
        }
        de.length && T(
          `Extraneous non-props attributes (${de.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes.`
        ), fe.length && T(
          `Extraneous non-emits event listeners (${fe.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes. If the listener is intended to be a component custom event listener only, declare it using the "emits" option.`
        );
      }
    }
  }
  return n.dirs && (ts(A) || T(
    "Runtime directive used on component with non-element root node. The directives will not function as intended."
  ), A = Rt(A, null, !1, !0), A.dirs = A.dirs ? A.dirs.concat(n.dirs) : n.dirs), n.transition && (ts(A) || T(
    "Component inside <Transition> renders non-element root node that cannot be animated."
  ), Tr(A, n.transition)), te ? te(A) : F = A, oo(M), F;
}
const Ui = (e) => {
  const t = e.children, n = e.dynamicChildren, o = Ir(t, !1);
  if (o) {
    if (o.patchFlag > 0 && o.patchFlag & 2048)
      return Ui(o);
  } else return [e, void 0];
  const r = t.indexOf(o), s = n ? n.indexOf(o) : -1, i = (l) => {
    t[r] = l, n && (s > -1 ? n[s] = l : l.patchFlag > 0 && (e.dynamicChildren = [...n, l]));
  };
  return [Le(o), i];
};
function Ir(e, t = !0) {
  let n;
  for (let o = 0; o < e.length; o++) {
    const r = e[o];
    if (Xt(r)) {
      if (r.type !== Ke || r.children === "v-if") {
        if (n)
          return;
        if (n = r, t && n.patchFlag > 0 && n.patchFlag & 2048)
          return Ir(n.children);
      }
    } else
      return;
  }
  return n;
}
const ja = (e) => {
  let t;
  for (const n in e)
    (n === "class" || n === "style" || $n(n)) && ((t || (t = {}))[n] = e[n]);
  return t;
}, Da = (e, t) => {
  const n = {};
  for (const o in e)
    (!Yn(o) || !(o.slice(9) in t)) && (n[o] = e[o]);
  return n;
}, ts = (e) => e.shapeFlag & 7 || e.type === Ke;
function Na(e, t, n) {
  const { props: o, children: r, component: s } = e, { props: i, children: l, patchFlag: c } = t, d = s.emitsOptions;
  if ((r || l) && Xe || t.dirs || t.transition)
    return !0;
  if (n && c >= 0) {
    if (c & 1024)
      return !0;
    if (c & 16)
      return o ? ns(o, i, d) : !!i;
    if (c & 8) {
      const f = t.dynamicProps;
      for (let a = 0; a < f.length; a++) {
        const p = f[a];
        if (i[p] !== o[p] && !So(d, p))
          return !0;
      }
    }
  } else
    return (r || l) && (!l || !l.$stable) ? !0 : o === i ? !1 : o ? i ? ns(o, i, d) : !0 : !!i;
  return !1;
}
function ns(e, t, n) {
  const o = Object.keys(t);
  if (o.length !== Object.keys(e).length)
    return !0;
  for (let r = 0; r < o.length; r++) {
    const s = o[r];
    if (t[s] !== e[s] && !So(n, s))
      return !0;
  }
  return !1;
}
function Fa({ vnode: e, parent: t }, n) {
  for (; t; ) {
    const o = t.subTree;
    if (o.suspense && o.suspense.activeBranch === e && (o.el = e.el), o === e)
      (e = t.vnode).el = n, t = t.parent;
    else
      break;
  }
}
const Ki = (e) => e.__isSuspense;
function Ha(e, t) {
  t && t.pendingBranch ? N(e) ? t.effects.push(...e) : t.effects.push(e) : hi(e);
}
const Ne = Symbol.for("v-fgt"), jn = Symbol.for("v-txt"), Ke = Symbol.for("v-cmt"), qn = Symbol.for("v-stc"), _n = [];
let Ae = null;
function Tt(e = !1) {
  _n.push(Ae = e ? null : []);
}
function La() {
  _n.pop(), Ae = _n[_n.length - 1] || null;
}
let Rn = 1;
function os(e) {
  Rn += e, e < 0 && Ae && (Ae.hasOnce = !0);
}
function Bi(e) {
  return e.dynamicChildren = Rn > 0 ? Ae || Gt : null, La(), Rn > 0 && Ae && Ae.push(e), e;
}
function Qt(e, t, n, o, r, s) {
  return Bi(
    ie(
      e,
      t,
      n,
      o,
      r,
      s,
      !0
    )
  );
}
function Wi(e, t, n, o, r) {
  return Bi(
    ue(
      e,
      t,
      n,
      o,
      r,
      !0
    )
  );
}
function Xt(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function sn(e, t) {
  if (t.shapeFlag & 6 && e.component) {
    const n = Wn.get(t.type);
    if (n && n.has(e.component))
      return e.shapeFlag &= -257, t.shapeFlag &= -513, !1;
  }
  return e.type === t.type && e.key === t.key;
}
const Va = (...e) => Ua(
  ...e
), Gi = ({ key: e }) => e ?? null, zn = ({
  ref: e,
  ref_key: t,
  ref_for: n
}) => (typeof e == "number" && (e = "" + e), e != null ? le(e) || ae(e) || L(e) ? { i: Ee, r: e, k: t, f: !!n } : e : null);
function ie(e, t = null, n = null, o = 0, r = null, s = e === Ne ? 0 : 1, i = !1, l = !1) {
  const c = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Gi(t),
    ref: t && zn(t),
    scopeId: wi,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: s,
    patchFlag: o,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: Ee
  };
  return l ? (Mr(c, n), s & 128 && e.normalize(c)) : n && (c.shapeFlag |= le(n) ? 8 : 16), c.key !== c.key && T("VNode created with invalid key (NaN). VNode type:", c.type), Rn > 0 && // avoid a block node from tracking itself
  !i && // has current parent block
  Ae && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (c.patchFlag > 0 || s & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  c.patchFlag !== 32 && Ae.push(c), c;
}
const ue = Va;
function Ua(e, t = null, n = null, o = 0, r = null, s = !1) {
  if ((!e || e === Xc) && (e || T(`Invalid vnode type when creating vnode: ${e}.`), e = Ke), Xt(e)) {
    const l = Rt(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return n && Mr(l, n), Rn > 0 && !s && Ae && (l.shapeFlag & 6 ? Ae[Ae.indexOf(e)] = l : Ae.push(l)), l.patchFlag = -2, l;
  }
  if (Qi(e) && (e = e.__vccOpts), t) {
    t = Ka(t);
    let { class: l, style: c } = t;
    l && !le(l) && (t.class = Dt(l)), Y(c) && (Zn(c) && !N(c) && (c = ce({}, c)), t.style = vr(c));
  }
  const i = le(e) ? 1 : Ki(e) ? 128 : Fc(e) ? 64 : Y(e) ? 4 : L(e) ? 2 : 0;
  return i & 4 && Zn(e) && (e = U(e), T(
    "Vue received a Component that was made a reactive object. This can lead to unnecessary performance overhead and should be avoided by marking the component with `markRaw` or using `shallowRef` instead of `ref`.",
    `
Component that was made reactive: `,
    e
  )), ie(
    e,
    t,
    n,
    o,
    r,
    i,
    s,
    !0
  );
}
function Ka(e) {
  return e ? Zn(e) || Ii(e) ? ce({}, e) : e : null;
}
function Rt(e, t, n = !1, o = !1) {
  const { props: r, ref: s, patchFlag: i, children: l, transition: c } = e, d = t ? Ba(r || {}, t) : r, f = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: d,
    key: d && Gi(d),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      n && s ? N(s) ? s.concat(zn(t)) : [s, zn(t)] : zn(t)
    ) : s,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: i === -1 && N(l) ? l.map(qi) : l,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== Ne ? i === -1 ? 16 : i | 16 : i,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: c,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && Rt(e.ssContent),
    ssFallback: e.ssFallback && Rt(e.ssFallback),
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return c && o && Tr(
    f,
    c.clone(f)
  ), f;
}
function qi(e) {
  const t = Rt(e);
  return N(e.children) && (t.children = e.children.map(qi)), t;
}
function dn(e = " ", t = 0) {
  return ue(jn, null, e, t);
}
function Le(e) {
  return e == null || typeof e == "boolean" ? ue(Ke) : N(e) ? ue(
    Ne,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : Xt(e) ? xt(e) : ue(jn, null, String(e));
}
function xt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : Rt(e);
}
function Mr(e, t) {
  let n = 0;
  const { shapeFlag: o } = e;
  if (t == null)
    t = null;
  else if (N(t))
    n = 16;
  else if (typeof t == "object")
    if (o & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), Mr(e, r()), r._c && (r._d = !0));
      return;
    } else {
      n = 32;
      const r = t._;
      !r && !Ii(t) ? t._ctx = Ee : r === 3 && Ee && (Ee.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else L(t) ? (t = { default: t, _ctx: Ee }, n = 32) : (t = String(t), o & 64 ? (n = 16, t = [dn(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n;
}
function Ba(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const o = e[n];
    for (const r in o)
      if (r === "class")
        t.class !== o.class && (t.class = Dt([t.class, o.class]));
      else if (r === "style")
        t.style = vr([t.style, o.style]);
      else if ($n(r)) {
        const s = t[r], i = o[r];
        i && s !== i && !(N(s) && s.includes(i)) && (t[r] = s ? [].concat(s, i) : i);
      } else r !== "" && (t[r] = o[r]);
  }
  return t;
}
function qe(e, t, n, o = null) {
  nt(e, t, 7, [
    n,
    o
  ]);
}
const Wa = Pi();
let Ga = 0;
function qa(e, t, n) {
  const o = e.type, r = (t ? t.appContext : e.appContext) || Wa, s = {
    uid: Ga++,
    vnode: e,
    type: o,
    parent: t,
    appContext: r,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new Bl(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(r.provides),
    ids: t ? t.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: ki(o, r),
    emitsOptions: Vi(o, r),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: Z,
    // inheritAttrs
    inheritAttrs: o.inheritAttrs,
    // state
    ctx: Z,
    data: Z,
    props: Z,
    attrs: Z,
    slots: Z,
    refs: Z,
    setupState: Z,
    setupContext: null,
    // suspense related
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return s.ctx = ea(s), s.root = t ? t.root : s, s.emit = ka.bind(null, s), e.ce && e.ce(s), s;
}
let he = null;
const kr = () => he || Ee;
let lo, or;
{
  const e = In(), t = (n, o) => {
    let r;
    return (r = e[n]) || (r = e[n] = []), r.push(o), (s) => {
      r.length > 1 ? r.forEach((i) => i(s)) : r[0](s);
    };
  };
  lo = t(
    "__VUE_INSTANCE_SETTERS__",
    (n) => he = n
  ), or = t(
    "__VUE_SSR_SETTERS__",
    (n) => On = n
  );
}
const Dn = (e) => {
  const t = he;
  return lo(e), e.scope.on(), () => {
    e.scope.off(), lo(t);
  };
}, rs = () => {
  he && he.scope.off(), lo(null);
}, za = /* @__PURE__ */ pt("slot,component");
function rr(e, { isNativeTag: t }) {
  (za(e) || t(e)) && T(
    "Do not use built-in or reserved HTML elements as component id: " + e
  );
}
function zi(e) {
  return e.vnode.shapeFlag & 4;
}
let On = !1;
function Ja(e, t = !1, n = !1) {
  t && or(t);
  const { props: o, children: r } = e.vnode, s = zi(e);
  fa(e, o, s, t), xa(e, r, n);
  const i = s ? Ya(e, t) : void 0;
  return t && or(!1), i;
}
function Ya(e, t) {
  var n;
  const o = e.type;
  {
    if (o.name && rr(o.name, e.appContext.config), o.components) {
      const s = Object.keys(o.components);
      for (let i = 0; i < s.length; i++)
        rr(s[i], e.appContext.config);
    }
    if (o.directives) {
      const s = Object.keys(o.directives);
      for (let i = 0; i < s.length; i++)
        xi(s[i]);
    }
    o.compilerOptions && Qa() && T(
      '"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.'
    );
  }
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, Ri), ta(e);
  const { setup: r } = o;
  if (r) {
    ht();
    const s = e.setupContext = r.length > 1 ? eu(e) : null, i = Dn(e), l = tn(
      r,
      e,
      0,
      [
        Qe(e.props),
        s
      ]
    ), c = hr(l);
    if (mt(), i(), (c || e.sp) && !yn(e) && Ei(e), c) {
      if (l.then(rs, rs), t)
        return l.then((d) => {
          ss(e, d, t);
        }).catch((d) => {
          Mn(d, e, 0);
        });
      if (e.asyncDep = l, !e.suspense) {
        const d = (n = o.name) != null ? n : "Anonymous";
        T(
          `Component <${d}>: setup function returned a promise, but no <Suspense> boundary was found in the parent component tree. A component with async setup() must be nested in a <Suspense> in order to be rendered.`
        );
      }
    } else
      ss(e, l, t);
  } else
    Ji(e, t);
}
function ss(e, t, n) {
  L(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : Y(t) ? (Xt(t) && T(
    "setup() should not return VNodes directly - return a render function instead."
  ), e.devtoolsRawSetupState = t, e.setupState = ui(t), na(e)) : t !== void 0 && T(
    `setup() should return an object. Received: ${t === null ? "null" : typeof t}`
  ), Ji(e, n);
}
let sr;
const Qa = () => !sr;
function Ji(e, t, n) {
  const o = e.type;
  if (!e.render) {
    if (!t && sr && !o.render) {
      const r = o.template || Pr(e).template;
      if (r) {
        st(e, "compile");
        const { isCustomElement: s, compilerOptions: i } = e.appContext.config, { delimiters: l, compilerOptions: c } = o, d = ce(
          ce(
            {
              isCustomElement: s,
              delimiters: l
            },
            i
          ),
          c
        );
        o.render = sr(r, d), it(e, "compile");
      }
    }
    e.render = o.render || be;
  }
  {
    const r = Dn(e);
    ht();
    try {
      ra(e);
    } finally {
      mt(), r();
    }
  }
  !o.render && e.render === be && !t && (o.template ? T(
    'Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".'
  ) : T("Component is missing template or render function: ", o));
}
const Xa = {
  get(e, t) {
    return io(), pe(e, "get", ""), e[t];
  },
  set() {
    return T("setupContext.attrs is readonly."), !1;
  },
  deleteProperty() {
    return T("setupContext.attrs is readonly."), !1;
  }
};
function Za(e) {
  return new Proxy(e.slots, {
    get(t, n) {
      return pe(e, "get", "$slots"), t[n];
    }
  });
}
function eu(e) {
  const t = (n) => {
    if (e.exposed && T("expose() should be called only once per setup()."), n != null) {
      let o = typeof n;
      o === "object" && (N(n) ? o = "array" : ae(n) && (o = "ref")), o !== "object" && T(
        `expose() should be passed a plain object, received ${o}.`
      );
    }
    e.exposed = n || {};
  };
  {
    let n, o;
    return Object.freeze({
      get attrs() {
        return n || (n = new Proxy(e.attrs, Xa));
      },
      get slots() {
        return o || (o = Za(e));
      },
      get emit() {
        return (r, ...s) => e.emit(r, ...s);
      },
      expose: t
    });
  }
}
function Eo(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(ui(uc(e.exposed)), {
    get(t, n) {
      if (n in t)
        return t[n];
      if (n in Lt)
        return Lt[n](e);
    },
    has(t, n) {
      return n in t || n in Lt;
    }
  })) : e.proxy;
}
const tu = /(?:^|[-_])(\w)/g, nu = (e) => e.replace(tu, (t) => t.toUpperCase()).replace(/[-_]/g, "");
function Yi(e, t = !0) {
  return L(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function Co(e, t, n = !1) {
  let o = Yi(t);
  if (!o && t.__file) {
    const r = t.__file.match(/([^/\\]+)\.\w+$/);
    r && (o = r[1]);
  }
  if (!o && e && e.parent) {
    const r = (s) => {
      for (const i in s)
        if (s[i] === t)
          return i;
    };
    o = r(
      e.components || e.parent.type.components
    ) || r(e.appContext.components);
  }
  return o ? nu(o) : n ? "App" : "Anonymous";
}
function Qi(e) {
  return L(e) && "__vccOpts" in e;
}
const me = (e, t) => {
  const n = mc(e, t, On);
  {
    const o = kr();
    o && o.appContext.config.warnRecursiveComputed && (n._warnRecursive = !0);
  }
  return n;
};
function Xi(e, t, n) {
  const o = arguments.length;
  return o === 2 ? Y(t) && !N(t) ? Xt(t) ? ue(e, null, [t]) : ue(e, t) : ue(e, null, t) : (o > 3 ? n = Array.prototype.slice.call(arguments, 2) : o === 3 && Xt(n) && (n = [n]), ue(e, t, n));
}
function ou() {
  if (typeof window > "u")
    return;
  const e = { style: "color:#3ba776" }, t = { style: "color:#1677ff" }, n = { style: "color:#f5222d" }, o = { style: "color:#eb2f96" }, r = {
    __vue_custom_formatter: !0,
    header(a) {
      return Y(a) ? a.__isVue ? ["div", e, "VueInstance"] : ae(a) ? [
        "div",
        {},
        ["span", e, f(a)],
        "<",
        // avoid debugger accessing value affecting behavior
        l("_value" in a ? a._value : a),
        ">"
      ] : Ft(a) ? [
        "div",
        {},
        ["span", e, Ce(a) ? "ShallowReactive" : "Reactive"],
        "<",
        l(a),
        `>${dt(a) ? " (readonly)" : ""}`
      ] : dt(a) ? [
        "div",
        {},
        ["span", e, Ce(a) ? "ShallowReadonly" : "Readonly"],
        "<",
        l(a),
        ">"
      ] : null : null;
    },
    hasBody(a) {
      return a && a.__isVue;
    },
    body(a) {
      if (a && a.__isVue)
        return [
          "div",
          {},
          ...s(a.$)
        ];
    }
  };
  function s(a) {
    const p = [];
    a.type.props && a.props && p.push(i("props", U(a.props))), a.setupState !== Z && p.push(i("setup", a.setupState)), a.data !== Z && p.push(i("data", U(a.data)));
    const m = c(a, "computed");
    m && p.push(i("computed", m));
    const y = c(a, "inject");
    return y && p.push(i("injected", y)), p.push([
      "div",
      {},
      [
        "span",
        {
          style: o.style + ";opacity:0.66"
        },
        "$ (internal): "
      ],
      ["object", { object: a }]
    ]), p;
  }
  function i(a, p) {
    return p = ce({}, p), Object.keys(p).length ? [
      "div",
      { style: "line-height:1.25em;margin-bottom:0.6em" },
      [
        "div",
        {
          style: "color:#476582"
        },
        a
      ],
      [
        "div",
        {
          style: "padding-left:1.25em"
        },
        ...Object.keys(p).map((m) => [
          "div",
          {},
          ["span", o, m + ": "],
          l(p[m], !1)
        ])
      ]
    ] : ["span", {}];
  }
  function l(a, p = !0) {
    return typeof a == "number" ? ["span", t, a] : typeof a == "string" ? ["span", n, JSON.stringify(a)] : typeof a == "boolean" ? ["span", o, a] : Y(a) ? ["object", { object: p ? U(a) : a }] : ["span", n, String(a)];
  }
  function c(a, p) {
    const m = a.type;
    if (L(m))
      return;
    const y = {};
    for (const b in a.ctx)
      d(m, b, p) && (y[b] = a.ctx[b]);
    return y;
  }
  function d(a, p, m) {
    const y = a[m];
    if (N(y) && y.includes(p) || Y(y) && p in y || a.extends && d(a.extends, p, m) || a.mixins && a.mixins.some((b) => d(b, p, m)))
      return !0;
  }
  function f(a) {
    return Ce(a) ? "ShallowRef" : a.effect ? "ComputedRef" : "Ref";
  }
  window.devtoolsFormatters ? window.devtoolsFormatters.push(r) : window.devtoolsFormatters = [r];
}
const is = "3.5.12", ut = T;
/**
* @vue/runtime-dom v3.5.12
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let ir;
const ls = typeof window < "u" && window.trustedTypes;
if (ls)
  try {
    ir = /* @__PURE__ */ ls.createPolicy("vue", {
      createHTML: (e) => e
    });
  } catch (e) {
    ut(`Error creating trusted types policy: ${e}`);
  }
const Zi = ir ? (e) => ir.createHTML(e) : (e) => e, ru = "http://www.w3.org/2000/svg", su = "http://www.w3.org/1998/Math/MathML", lt = typeof document < "u" ? document : null, cs = lt && /* @__PURE__ */ lt.createElement("template"), iu = {
  insert: (e, t, n) => {
    t.insertBefore(e, n || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, n, o) => {
    const r = t === "svg" ? lt.createElementNS(ru, e) : t === "mathml" ? lt.createElementNS(su, e) : n ? lt.createElement(e, { is: n }) : lt.createElement(e);
    return e === "select" && o && o.multiple != null && r.setAttribute("multiple", o.multiple), r;
  },
  createText: (e) => lt.createTextNode(e),
  createComment: (e) => lt.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => lt.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, n, o, r, s) {
    const i = n ? n.previousSibling : t.lastChild;
    if (r && (r === s || r.nextSibling))
      for (; t.insertBefore(r.cloneNode(!0), n), !(r === s || !(r = r.nextSibling)); )
        ;
    else {
      cs.innerHTML = Zi(
        o === "svg" ? `<svg>${e}</svg>` : o === "mathml" ? `<math>${e}</math>` : e
      );
      const l = cs.content;
      if (o === "svg" || o === "mathml") {
        const c = l.firstChild;
        for (; c.firstChild; )
          l.appendChild(c.firstChild);
        l.removeChild(c);
      }
      t.insertBefore(l, n);
    }
    return [
      // first
      i ? i.nextSibling : t.firstChild,
      // last
      n ? n.previousSibling : t.lastChild
    ];
  }
}, lu = Symbol("_vtc");
function cu(e, t, n) {
  const o = e[lu];
  o && (t = (t ? [t, ...o] : [...o]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
const co = Symbol("_vod"), el = Symbol("_vsh"), ao = {
  beforeMount(e, { value: t }, { transition: n }) {
    e[co] = e.style.display === "none" ? "" : e.style.display, n && t ? n.beforeEnter(e) : ln(e, t);
  },
  mounted(e, { value: t }, { transition: n }) {
    n && t && n.enter(e);
  },
  updated(e, { value: t, oldValue: n }, { transition: o }) {
    !t != !n && (o ? t ? (o.beforeEnter(e), ln(e, !0), o.enter(e)) : o.leave(e, () => {
      ln(e, !1);
    }) : ln(e, t));
  },
  beforeUnmount(e, { value: t }) {
    ln(e, t);
  }
};
ao.name = "show";
function ln(e, t) {
  e.style.display = t ? e[co] : "none", e[el] = !t;
}
const au = Symbol("CSS_VAR_TEXT"), uu = /(^|;)\s*display\s*:/;
function fu(e, t, n) {
  const o = e.style, r = le(n);
  let s = !1;
  if (n && !r) {
    if (t)
      if (le(t))
        for (const i of t.split(";")) {
          const l = i.slice(0, i.indexOf(":")).trim();
          n[l] == null && Jn(o, l, "");
        }
      else
        for (const i in t)
          n[i] == null && Jn(o, i, "");
    for (const i in n)
      i === "display" && (s = !0), Jn(o, i, n[i]);
  } else if (r) {
    if (t !== n) {
      const i = o[au];
      i && (n += ";" + i), o.cssText = n, s = uu.test(n);
    }
  } else t && e.removeAttribute("style");
  co in e && (e[co] = s ? o.display : "", e[el] && (o.display = "none"));
}
const du = /[^\\];\s*$/, as = /\s*!important$/;
function Jn(e, t, n) {
  if (N(n))
    n.forEach((o) => Jn(e, t, o));
  else if (n == null && (n = ""), du.test(n) && ut(
    `Unexpected semicolon at the end of '${t}' style value: '${n}'`
  ), t.startsWith("--"))
    e.setProperty(t, n);
  else {
    const o = pu(e, t);
    as.test(n) ? e.setProperty(
      ft(o),
      n.replace(as, ""),
      "important"
    ) : e[o] = n;
  }
}
const us = ["Webkit", "Moz", "ms"], Do = {};
function pu(e, t) {
  const n = Do[t];
  if (n)
    return n;
  let o = Ve(t);
  if (o !== "filter" && o in e)
    return Do[t] = o;
  o = mo(o);
  for (let r = 0; r < us.length; r++) {
    const s = us[r] + o;
    if (s in e)
      return Do[t] = s;
  }
  return t;
}
const fs = "http://www.w3.org/1999/xlink";
function ds(e, t, n, o, r, s = Ul(t)) {
  o && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(fs, t.slice(6, t.length)) : e.setAttributeNS(fs, t, n) : n == null || s && !Vs(n) ? e.removeAttribute(t) : e.setAttribute(
    t,
    s ? "" : et(n) ? String(n) : n
  );
}
function ps(e, t, n, o, r) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? Zi(n) : n);
    return;
  }
  const s = e.tagName;
  if (t === "value" && s !== "PROGRESS" && // custom elements may use _value internally
  !s.includes("-")) {
    const l = s === "OPTION" ? e.getAttribute("value") || "" : e.value, c = n == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      e.type === "checkbox" ? "on" : ""
    ) : String(n);
    (l !== c || !("_value" in e)) && (e.value = c), n == null && e.removeAttribute(t), e._value = n;
    return;
  }
  let i = !1;
  if (n === "" || n == null) {
    const l = typeof e[t];
    l === "boolean" ? n = Vs(n) : n == null && l === "string" ? (n = "", i = !0) : l === "number" && (n = 0, i = !0);
  }
  try {
    e[t] = n;
  } catch (l) {
    i || ut(
      `Failed setting prop "${t}" on <${s.toLowerCase()}>: value ${n} is invalid.`,
      l
    );
  }
  i && e.removeAttribute(r || t);
}
function kt(e, t, n, o) {
  e.addEventListener(t, n, o);
}
function hu(e, t, n, o) {
  e.removeEventListener(t, n, o);
}
const hs = Symbol("_vei");
function mu(e, t, n, o, r = null) {
  const s = e[hs] || (e[hs] = {}), i = s[t];
  if (o && i)
    i.value = gs(o, t);
  else {
    const [l, c] = gu(t);
    if (o) {
      const d = s[t] = bu(
        gs(o, t),
        r
      );
      kt(e, l, d, c);
    } else i && (hu(e, l, i, c), s[t] = void 0);
  }
}
const ms = /(?:Once|Passive|Capture)$/;
function gu(e) {
  let t;
  if (ms.test(e)) {
    t = {};
    let o;
    for (; o = e.match(ms); )
      e = e.slice(0, e.length - o[0].length), t[o[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : ft(e.slice(2)), t];
}
let No = 0;
const vu = /* @__PURE__ */ Promise.resolve(), yu = () => No || (vu.then(() => No = 0), No = Date.now());
function bu(e, t) {
  const n = (o) => {
    if (!o._vts)
      o._vts = Date.now();
    else if (o._vts <= n.attached)
      return;
    nt(
      _u(o, n.value),
      t,
      5,
      [o]
    );
  };
  return n.value = e, n.attached = yu(), n;
}
function gs(e, t) {
  return L(e) || N(e) ? e : (ut(
    `Wrong type passed as event handler to ${t} - did you forget @ or : in front of your prop?
Expected function or array of functions, received type ${typeof e}.`
  ), be);
}
function _u(e, t) {
  if (N(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0;
    }, t.map(
      (o) => (r) => !r._stopped && o && o(r)
    );
  } else
    return t;
}
const vs = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, wu = (e, t, n, o, r, s) => {
  const i = r === "svg";
  t === "class" ? cu(e, o, i) : t === "style" ? fu(e, n, o) : $n(t) ? Yn(t) || mu(e, t, n, o, s) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : xu(e, t, o, i)) ? (ps(e, t, o), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && ds(e, t, o, i, s, t !== "value")) : /* #11081 force set props for possible async custom element */ e._isVueCE && (/[A-Z]/.test(t) || !le(o)) ? ps(e, Ve(t), o, s, t) : (t === "true-value" ? e._trueValue = o : t === "false-value" && (e._falseValue = o), ds(e, t, o, i));
};
function xu(e, t, n, o) {
  if (o)
    return !!(t === "innerHTML" || t === "textContent" || t in e && vs(t) && L(n));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return vs(t) && le(n) ? !1 : t in e;
}
const uo = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return N(t) ? (n) => Bt(t, n) : t;
};
function Su(e) {
  e.target.composing = !0;
}
function ys(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const Jt = Symbol("_assign"), Eu = {
  created(e, { modifiers: { lazy: t, trim: n, number: o } }, r) {
    e[Jt] = uo(r);
    const s = o || r.props && r.props.type === "number";
    kt(e, t ? "change" : "input", (i) => {
      if (i.target.composing) return;
      let l = e.value;
      n && (l = l.trim()), s && (l = Uo(l)), e[Jt](l);
    }), n && kt(e, "change", () => {
      e.value = e.value.trim();
    }), t || (kt(e, "compositionstart", Su), kt(e, "compositionend", ys), kt(e, "change", ys));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: o, trim: r, number: s } }, i) {
    if (e[Jt] = uo(i), e.composing) return;
    const l = (s || e.type === "number") && !/^0\d/.test(e.value) ? Uo(e.value) : e.value, c = t ?? "";
    l !== c && (document.activeElement === e && e.type !== "range" && (o && t === n || r && e.value.trim() === c) || (e.value = c));
  }
}, tl = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, n) {
    e[Jt] = uo(n), kt(e, "change", () => {
      const o = e._modelValue, r = Cu(e), s = e.checked, i = e[Jt];
      if (N(o)) {
        const l = Us(o, r), c = l !== -1;
        if (s && !c)
          i(o.concat(r));
        else if (!s && c) {
          const d = [...o];
          d.splice(l, 1), i(d);
        }
      } else if (po(o)) {
        const l = new Set(o);
        s ? l.add(r) : l.delete(r), i(l);
      } else
        i(nl(e, s));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: bs,
  beforeUpdate(e, t, n) {
    e[Jt] = uo(n), bs(e, t, n);
  }
};
function bs(e, { value: t, oldValue: n }, o) {
  e._modelValue = t;
  let r;
  if (N(t))
    r = Us(t, o.props.value) > -1;
  else if (po(t))
    r = t.has(o.props.value);
  else {
    if (t === n) return;
    r = go(t, nl(e, !0));
  }
  e.checked !== r && (e.checked = r);
}
function Cu(e) {
  return "_value" in e ? e._value : e.value;
}
function nl(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t;
}
const Tu = ["ctrl", "shift", "alt", "meta"], Ru = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, t) => Tu.some((n) => e[`${n}Key`] && !t.includes(n))
}, Ou = (e, t) => {
  const n = e._withMods || (e._withMods = {}), o = t.join(".");
  return n[o] || (n[o] = (r, ...s) => {
    for (let i = 0; i < t.length; i++) {
      const l = Ru[t[i]];
      if (l && l(r, t)) return;
    }
    return e(r, ...s);
  });
}, Pu = {
  esc: "escape",
  space: " ",
  up: "arrow-up",
  left: "arrow-left",
  right: "arrow-right",
  down: "arrow-down",
  delete: "backspace"
}, ol = (e, t) => {
  const n = e._withKeys || (e._withKeys = {}), o = t.join(".");
  return n[o] || (n[o] = (r) => {
    if (!("key" in r))
      return;
    const s = ft(r.key);
    if (t.some(
      (i) => i === s || Pu[i] === s
    ))
      return e(r);
  });
}, $u = /* @__PURE__ */ ce({ patchProp: wu }, iu);
let _s;
function Au() {
  return _s || (_s = Ca($u));
}
const Iu = (...e) => {
  const t = Au().createApp(...e);
  ku(t), ju(t);
  const { mount: n } = t;
  return t.mount = (o) => {
    const r = Du(o);
    if (!r) return;
    const s = t._component;
    !L(s) && !s.render && !s.template && (s.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
    const i = n(r, !1, Mu(r));
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), i;
  }, t;
};
function Mu(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function ku(e) {
  Object.defineProperty(e.config, "isNativeTag", {
    value: (t) => Fl(t) || Hl(t) || Ll(t),
    writable: !1
  });
}
function ju(e) {
  {
    const t = e.config.isCustomElement;
    Object.defineProperty(e.config, "isCustomElement", {
      get() {
        return t;
      },
      set() {
        ut(
          "The `isCustomElement` config option is deprecated. Use `compilerOptions.isCustomElement` instead."
        );
      }
    });
    const n = e.config.compilerOptions, o = 'The `compilerOptions` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, `compilerOptions` must be passed to `@vue/compiler-dom` in the build setup instead.\n- For vue-loader: pass it via vue-loader\'s `compilerOptions` loader option.\n- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader\n- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc';
    Object.defineProperty(e.config, "compilerOptions", {
      get() {
        return ut(o), n;
      },
      set() {
        ut(o);
      }
    });
  }
}
function Du(e) {
  if (le(e)) {
    const t = document.querySelector(e);
    return t || ut(
      `Failed to mount app: mount target selector "${e}" returned null.`
    ), t;
  }
  return window.ShadowRoot && e instanceof window.ShadowRoot && e.mode === "closed" && ut(
    'mounting on a ShadowRoot with `{mode: "closed"}` may lead to unpredictable bugs'
  ), e;
}
/**
* vue v3.5.12
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function Nu() {
  ou();
}
Nu();
function Fu() {
  return rl().__VUE_DEVTOOLS_GLOBAL_HOOK__;
}
function rl() {
  return typeof navigator < "u" && typeof window < "u" ? window : typeof globalThis < "u" ? globalThis : {};
}
const Hu = typeof Proxy == "function", Lu = "devtools-plugin:setup", Vu = "plugin:settings:set";
let Kt, lr;
function Uu() {
  var e;
  return Kt !== void 0 || (typeof window < "u" && window.performance ? (Kt = !0, lr = window.performance) : typeof globalThis < "u" && (!((e = globalThis.perf_hooks) === null || e === void 0) && e.performance) ? (Kt = !0, lr = globalThis.perf_hooks.performance) : Kt = !1), Kt;
}
function Ku() {
  return Uu() ? lr.now() : Date.now();
}
class Bu {
  constructor(t, n) {
    this.target = null, this.targetQueue = [], this.onQueue = [], this.plugin = t, this.hook = n;
    const o = {};
    if (t.settings)
      for (const i in t.settings) {
        const l = t.settings[i];
        o[i] = l.defaultValue;
      }
    const r = `__vue-devtools-plugin-settings__${t.id}`;
    let s = Object.assign({}, o);
    try {
      const i = localStorage.getItem(r), l = JSON.parse(i);
      Object.assign(s, l);
    } catch {
    }
    this.fallbacks = {
      getSettings() {
        return s;
      },
      setSettings(i) {
        try {
          localStorage.setItem(r, JSON.stringify(i));
        } catch {
        }
        s = i;
      },
      now() {
        return Ku();
      }
    }, n && n.on(Vu, (i, l) => {
      i === this.plugin.id && this.fallbacks.setSettings(l);
    }), this.proxiedOn = new Proxy({}, {
      get: (i, l) => this.target ? this.target.on[l] : (...c) => {
        this.onQueue.push({
          method: l,
          args: c
        });
      }
    }), this.proxiedTarget = new Proxy({}, {
      get: (i, l) => this.target ? this.target[l] : l === "on" ? this.proxiedOn : Object.keys(this.fallbacks).includes(l) ? (...c) => (this.targetQueue.push({
        method: l,
        args: c,
        resolve: () => {
        }
      }), this.fallbacks[l](...c)) : (...c) => new Promise((d) => {
        this.targetQueue.push({
          method: l,
          args: c,
          resolve: d
        });
      })
    });
  }
  async setRealTarget(t) {
    this.target = t;
    for (const n of this.onQueue)
      this.target.on[n.method](...n.args);
    for (const n of this.targetQueue)
      n.resolve(await this.target[n.method](...n.args));
  }
}
function Wu(e, t) {
  const n = e, o = rl(), r = Fu(), s = Hu && n.enableEarlyProxy;
  if (r && (o.__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__ || !s))
    r.emit(Lu, e, t);
  else {
    const i = s ? new Bu(n, r) : null;
    (o.__VUE_DEVTOOLS_PLUGINS__ = o.__VUE_DEVTOOLS_PLUGINS__ || []).push({
      pluginDescriptor: n,
      setupFn: t,
      proxy: i
    }), i && t(i.proxiedTarget);
  }
}
/*!
  * vue-router v4.4.5
  * (c) 2024 Eduardo San Martin Morote
  * @license MIT
  */
const ct = typeof document < "u";
function sl(e) {
  return typeof e == "object" || "displayName" in e || "props" in e || "__vccOpts" in e;
}
function Gu(e) {
  return e.__esModule || e[Symbol.toStringTag] === "Module" || // support CF with dynamic imports that do not
  // add the Module string tag
  e.default && sl(e.default);
}
const X = Object.assign;
function Fo(e, t) {
  const n = {};
  for (const o in t) {
    const r = t[o];
    n[o] = Ie(r) ? r.map(e) : e(r);
  }
  return n;
}
const wn = () => {
}, Ie = Array.isArray;
function K(e) {
  const t = Array.from(arguments).slice(1);
  console.warn.apply(console, ["[Vue Router warn]: " + e].concat(t));
}
const il = /#/g, qu = /&/g, zu = /\//g, Ju = /=/g, Yu = /\?/g, ll = /\+/g, Qu = /%5B/g, Xu = /%5D/g, cl = /%5E/g, Zu = /%60/g, al = /%7B/g, ef = /%7C/g, ul = /%7D/g, tf = /%20/g;
function jr(e) {
  return encodeURI("" + e).replace(ef, "|").replace(Qu, "[").replace(Xu, "]");
}
function nf(e) {
  return jr(e).replace(al, "{").replace(ul, "}").replace(cl, "^");
}
function cr(e) {
  return jr(e).replace(ll, "%2B").replace(tf, "+").replace(il, "%23").replace(qu, "%26").replace(Zu, "`").replace(al, "{").replace(ul, "}").replace(cl, "^");
}
function of(e) {
  return cr(e).replace(Ju, "%3D");
}
function rf(e) {
  return jr(e).replace(il, "%23").replace(Yu, "%3F");
}
function sf(e) {
  return e == null ? "" : rf(e).replace(zu, "%2F");
}
function Zt(e) {
  try {
    return decodeURIComponent("" + e);
  } catch {
    K(`Error decoding "${e}". Using original value`);
  }
  return "" + e;
}
const lf = /\/$/, cf = (e) => e.replace(lf, "");
function Ho(e, t, n = "/") {
  let o, r = {}, s = "", i = "";
  const l = t.indexOf("#");
  let c = t.indexOf("?");
  return l < c && l >= 0 && (c = -1), c > -1 && (o = t.slice(0, c), s = t.slice(c + 1, l > -1 ? l : t.length), r = e(s)), l > -1 && (o = o || t.slice(0, l), i = t.slice(l, t.length)), o = ff(o ?? t, n), {
    fullPath: o + (s && "?") + s + i,
    path: o,
    query: r,
    hash: Zt(i)
  };
}
function af(e, t) {
  const n = t.query ? e(t.query) : "";
  return t.path + (n && "?") + n + (t.hash || "");
}
function ws(e, t) {
  return !t || !e.toLowerCase().startsWith(t.toLowerCase()) ? e : e.slice(t.length) || "/";
}
function xs(e, t, n) {
  const o = t.matched.length - 1, r = n.matched.length - 1;
  return o > -1 && o === r && Ot(t.matched[o], n.matched[r]) && fl(t.params, n.params) && e(t.query) === e(n.query) && t.hash === n.hash;
}
function Ot(e, t) {
  return (e.aliasOf || e) === (t.aliasOf || t);
}
function fl(e, t) {
  if (Object.keys(e).length !== Object.keys(t).length)
    return !1;
  for (const n in e)
    if (!uf(e[n], t[n]))
      return !1;
  return !0;
}
function uf(e, t) {
  return Ie(e) ? Ss(e, t) : Ie(t) ? Ss(t, e) : e === t;
}
function Ss(e, t) {
  return Ie(t) ? e.length === t.length && e.every((n, o) => n === t[o]) : e.length === 1 && e[0] === t;
}
function ff(e, t) {
  if (e.startsWith("/"))
    return e;
  if (!t.startsWith("/"))
    return K(`Cannot resolve a relative location without an absolute path. Trying to resolve "${e}" from "${t}". It should look like "/${t}".`), e;
  if (!e)
    return t;
  const n = t.split("/"), o = e.split("/"), r = o[o.length - 1];
  (r === ".." || r === ".") && o.push("");
  let s = n.length - 1, i, l;
  for (i = 0; i < o.length; i++)
    if (l = o[i], l !== ".")
      if (l === "..")
        s > 1 && s--;
      else
        break;
  return n.slice(0, s).join("/") + "/" + o.slice(i).join("/");
}
const _t = {
  path: "/",
  // TODO: could we use a symbol in the future?
  name: void 0,
  params: {},
  query: {},
  hash: "",
  fullPath: "/",
  matched: [],
  meta: {},
  redirectedFrom: void 0
};
var Pn;
(function(e) {
  e.pop = "pop", e.push = "push";
})(Pn || (Pn = {}));
var xn;
(function(e) {
  e.back = "back", e.forward = "forward", e.unknown = "";
})(xn || (xn = {}));
function df(e) {
  if (!e)
    if (ct) {
      const t = document.querySelector("base");
      e = t && t.getAttribute("href") || "/", e = e.replace(/^\w+:\/\/[^\/]+/, "");
    } else
      e = "/";
  return e[0] !== "/" && e[0] !== "#" && (e = "/" + e), cf(e);
}
const pf = /^[^#]+#/;
function hf(e, t) {
  return e.replace(pf, "#") + t;
}
function mf(e, t) {
  const n = document.documentElement.getBoundingClientRect(), o = e.getBoundingClientRect();
  return {
    behavior: t.behavior,
    left: o.left - n.left - (t.left || 0),
    top: o.top - n.top - (t.top || 0)
  };
}
const To = () => ({
  left: window.scrollX,
  top: window.scrollY
});
function gf(e) {
  let t;
  if ("el" in e) {
    const n = e.el, o = typeof n == "string" && n.startsWith("#");
    if (typeof e.el == "string" && (!o || !document.getElementById(e.el.slice(1))))
      try {
        const s = document.querySelector(e.el);
        if (o && s) {
          K(`The selector "${e.el}" should be passed as "el: document.querySelector('${e.el}')" because it starts with "#".`);
          return;
        }
      } catch {
        K(`The selector "${e.el}" is invalid. If you are using an id selector, make sure to escape it. You can find more information about escaping characters in selectors at https://mathiasbynens.be/notes/css-escapes or use CSS.escape (https://developer.mozilla.org/en-US/docs/Web/API/CSS/escape).`);
        return;
      }
    const r = typeof n == "string" ? o ? document.getElementById(n.slice(1)) : document.querySelector(n) : n;
    if (!r) {
      K(`Couldn't find element using selector "${e.el}" returned by scrollBehavior.`);
      return;
    }
    t = mf(r, e);
  } else
    t = e;
  "scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(t.left != null ? t.left : window.scrollX, t.top != null ? t.top : window.scrollY);
}
function Es(e, t) {
  return (history.state ? history.state.position - t : -1) + e;
}
const ar = /* @__PURE__ */ new Map();
function vf(e, t) {
  ar.set(e, t);
}
function yf(e) {
  const t = ar.get(e);
  return ar.delete(e), t;
}
let bf = () => location.protocol + "//" + location.host;
function dl(e, t) {
  const { pathname: n, search: o, hash: r } = t, s = e.indexOf("#");
  if (s > -1) {
    let l = r.includes(e.slice(s)) ? e.slice(s).length : 1, c = r.slice(l);
    return c[0] !== "/" && (c = "/" + c), ws(c, "");
  }
  return ws(n, e) + o + r;
}
function _f(e, t, n, o) {
  let r = [], s = [], i = null;
  const l = ({ state: p }) => {
    const m = dl(e, location), y = n.value, b = t.value;
    let M = 0;
    if (p) {
      if (n.value = m, t.value = p, i && i === y) {
        i = null;
        return;
      }
      M = b ? p.position - b.position : 0;
    } else
      o(m);
    r.forEach((F) => {
      F(n.value, y, {
        delta: M,
        type: Pn.pop,
        direction: M ? M > 0 ? xn.forward : xn.back : xn.unknown
      });
    });
  };
  function c() {
    i = n.value;
  }
  function d(p) {
    r.push(p);
    const m = () => {
      const y = r.indexOf(p);
      y > -1 && r.splice(y, 1);
    };
    return s.push(m), m;
  }
  function f() {
    const { history: p } = window;
    p.state && p.replaceState(X({}, p.state, { scroll: To() }), "");
  }
  function a() {
    for (const p of s)
      p();
    s = [], window.removeEventListener("popstate", l), window.removeEventListener("beforeunload", f);
  }
  return window.addEventListener("popstate", l), window.addEventListener("beforeunload", f, {
    passive: !0
  }), {
    pauseListeners: c,
    listen: d,
    destroy: a
  };
}
function Cs(e, t, n, o = !1, r = !1) {
  return {
    back: e,
    current: t,
    forward: n,
    replaced: o,
    position: window.history.length,
    scroll: r ? To() : null
  };
}
function wf(e) {
  const { history: t, location: n } = window, o = {
    value: dl(e, n)
  }, r = { value: t.state };
  r.value || s(o.value, {
    back: null,
    current: o.value,
    forward: null,
    // the length is off by one, we need to decrease it
    position: t.length - 1,
    replaced: !0,
    // don't add a scroll as the user may have an anchor, and we want
    // scrollBehavior to be triggered without a saved position
    scroll: null
  }, !0);
  function s(c, d, f) {
    const a = e.indexOf("#"), p = a > -1 ? (n.host && document.querySelector("base") ? e : e.slice(a)) + c : bf() + e + c;
    try {
      t[f ? "replaceState" : "pushState"](d, "", p), r.value = d;
    } catch (m) {
      K("Error with push/replace State", m), n[f ? "replace" : "assign"](p);
    }
  }
  function i(c, d) {
    const f = X({}, t.state, Cs(
      r.value.back,
      // keep back and forward entries but override current position
      c,
      r.value.forward,
      !0
    ), d, { position: r.value.position });
    s(c, f, !0), o.value = c;
  }
  function l(c, d) {
    const f = X(
      {},
      // use current history state to gracefully handle a wrong call to
      // history.replaceState
      // https://github.com/vuejs/router/issues/366
      r.value,
      t.state,
      {
        forward: c,
        scroll: To()
      }
    );
    t.state || K(`history.state seems to have been manually replaced without preserving the necessary values. Make sure to preserve existing history state if you are manually calling history.replaceState:

history.replaceState(history.state, '', url)

You can find more information at https://router.vuejs.org/guide/migration/#Usage-of-history-state`), s(f.current, f, !0);
    const a = X({}, Cs(o.value, c, null), { position: f.position + 1 }, d);
    s(c, a, !1), o.value = c;
  }
  return {
    location: o,
    state: r,
    push: l,
    replace: i
  };
}
function xf(e) {
  e = df(e);
  const t = wf(e), n = _f(e, t.state, t.location, t.replace);
  function o(s, i = !0) {
    i || n.pauseListeners(), history.go(s);
  }
  const r = X({
    // it's overridden right after
    location: "",
    base: e,
    go: o,
    createHref: hf.bind(null, e)
  }, t, n);
  return Object.defineProperty(r, "location", {
    enumerable: !0,
    get: () => t.location.value
  }), Object.defineProperty(r, "state", {
    enumerable: !0,
    get: () => t.state.value
  }), r;
}
function Sf(e) {
  return e = location.host ? e || location.pathname + location.search : "", e.includes("#") || (e += "#"), !e.endsWith("#/") && !e.endsWith("#") && K(`A hash base must end with a "#":
"${e}" should be "${e.replace(/#.*$/, "#")}".`), xf(e);
}
function fo(e) {
  return typeof e == "string" || e && typeof e == "object";
}
function pl(e) {
  return typeof e == "string" || typeof e == "symbol";
}
const hl = Symbol("navigation failure");
var Ts;
(function(e) {
  e[e.aborted = 4] = "aborted", e[e.cancelled = 8] = "cancelled", e[e.duplicated = 16] = "duplicated";
})(Ts || (Ts = {}));
const Ef = {
  1({ location: e, currentLocation: t }) {
    return `No match for
 ${JSON.stringify(e)}${t ? `
while being at
` + JSON.stringify(t) : ""}`;
  },
  2({ from: e, to: t }) {
    return `Redirected from "${e.fullPath}" to "${Tf(t)}" via a navigation guard.`;
  },
  4({ from: e, to: t }) {
    return `Navigation aborted from "${e.fullPath}" to "${t.fullPath}" via a navigation guard.`;
  },
  8({ from: e, to: t }) {
    return `Navigation cancelled from "${e.fullPath}" to "${t.fullPath}" with a new navigation.`;
  },
  16({ from: e, to: t }) {
    return `Avoided redundant navigation to current location: "${e.fullPath}".`;
  }
};
function en(e, t) {
  return X(new Error(Ef[e](t)), {
    type: e,
    [hl]: !0
  }, t);
}
function rt(e, t) {
  return e instanceof Error && hl in e && (t == null || !!(e.type & t));
}
const Cf = ["params", "query", "hash"];
function Tf(e) {
  if (typeof e == "string")
    return e;
  if (e.path != null)
    return e.path;
  const t = {};
  for (const n of Cf)
    n in e && (t[n] = e[n]);
  return JSON.stringify(t, null, 2);
}
const Rs = "[^/]+?", Rf = {
  sensitive: !1,
  strict: !1,
  start: !0,
  end: !0
}, Of = /[.+*?^${}()[\]/\\]/g;
function Pf(e, t) {
  const n = X({}, Rf, t), o = [];
  let r = n.start ? "^" : "";
  const s = [];
  for (const d of e) {
    const f = d.length ? [] : [
      90
      /* PathScore.Root */
    ];
    n.strict && !d.length && (r += "/");
    for (let a = 0; a < d.length; a++) {
      const p = d[a];
      let m = 40 + (n.sensitive ? 0.25 : 0);
      if (p.type === 0)
        a || (r += "/"), r += p.value.replace(Of, "\\$&"), m += 40;
      else if (p.type === 1) {
        const { value: y, repeatable: b, optional: M, regexp: F } = p;
        s.push({
          name: y,
          repeatable: b,
          optional: M
        });
        const j = F || Rs;
        if (j !== Rs) {
          m += 10;
          try {
            new RegExp(`(${j})`);
          } catch (te) {
            throw new Error(`Invalid custom RegExp for param "${y}" (${j}): ` + te.message);
          }
        }
        let A = b ? `((?:${j})(?:/(?:${j}))*)` : `(${j})`;
        a || (A = // avoid an optional / if there are more segments e.g. /:p?-static
        // or /:p?-:p2
        M && d.length < 2 ? `(?:/${A})` : "/" + A), M && (A += "?"), r += A, m += 20, M && (m += -8), b && (m += -20), j === ".*" && (m += -50);
      }
      f.push(m);
    }
    o.push(f);
  }
  if (n.strict && n.end) {
    const d = o.length - 1;
    o[d][o[d].length - 1] += 0.7000000000000001;
  }
  n.strict || (r += "/?"), n.end ? r += "$" : n.strict && (r += "(?:/|$)");
  const i = new RegExp(r, n.sensitive ? "" : "i");
  function l(d) {
    const f = d.match(i), a = {};
    if (!f)
      return null;
    for (let p = 1; p < f.length; p++) {
      const m = f[p] || "", y = s[p - 1];
      a[y.name] = m && y.repeatable ? m.split("/") : m;
    }
    return a;
  }
  function c(d) {
    let f = "", a = !1;
    for (const p of e) {
      (!a || !f.endsWith("/")) && (f += "/"), a = !1;
      for (const m of p)
        if (m.type === 0)
          f += m.value;
        else if (m.type === 1) {
          const { value: y, repeatable: b, optional: M } = m, F = y in d ? d[y] : "";
          if (Ie(F) && !b)
            throw new Error(`Provided param "${y}" is an array but it is not repeatable (* or + modifiers)`);
          const j = Ie(F) ? F.join("/") : F;
          if (!j)
            if (M)
              p.length < 2 && (f.endsWith("/") ? f = f.slice(0, -1) : a = !0);
            else
              throw new Error(`Missing required param "${y}"`);
          f += j;
        }
    }
    return f || "/";
  }
  return {
    re: i,
    score: o,
    keys: s,
    parse: l,
    stringify: c
  };
}
function $f(e, t) {
  let n = 0;
  for (; n < e.length && n < t.length; ) {
    const o = t[n] - e[n];
    if (o)
      return o;
    n++;
  }
  return e.length < t.length ? e.length === 1 && e[0] === 80 ? -1 : 1 : e.length > t.length ? t.length === 1 && t[0] === 80 ? 1 : -1 : 0;
}
function ml(e, t) {
  let n = 0;
  const o = e.score, r = t.score;
  for (; n < o.length && n < r.length; ) {
    const s = $f(o[n], r[n]);
    if (s)
      return s;
    n++;
  }
  if (Math.abs(r.length - o.length) === 1) {
    if (Os(o))
      return 1;
    if (Os(r))
      return -1;
  }
  return r.length - o.length;
}
function Os(e) {
  const t = e[e.length - 1];
  return e.length > 0 && t[t.length - 1] < 0;
}
const Af = {
  type: 0,
  value: ""
}, If = /[a-zA-Z0-9_]/;
function Mf(e) {
  if (!e)
    return [[]];
  if (e === "/")
    return [[Af]];
  if (!e.startsWith("/"))
    throw new Error(`Route paths should start with a "/": "${e}" should be "/${e}".`);
  function t(m) {
    throw new Error(`ERR (${n})/"${d}": ${m}`);
  }
  let n = 0, o = n;
  const r = [];
  let s;
  function i() {
    s && r.push(s), s = [];
  }
  let l = 0, c, d = "", f = "";
  function a() {
    d && (n === 0 ? s.push({
      type: 0,
      value: d
    }) : n === 1 || n === 2 || n === 3 ? (s.length > 1 && (c === "*" || c === "+") && t(`A repeatable param (${d}) must be alone in its segment. eg: '/:ids+.`), s.push({
      type: 1,
      value: d,
      regexp: f,
      repeatable: c === "*" || c === "+",
      optional: c === "*" || c === "?"
    })) : t("Invalid state to consume buffer"), d = "");
  }
  function p() {
    d += c;
  }
  for (; l < e.length; ) {
    if (c = e[l++], c === "\\" && n !== 2) {
      o = n, n = 4;
      continue;
    }
    switch (n) {
      case 0:
        c === "/" ? (d && a(), i()) : c === ":" ? (a(), n = 1) : p();
        break;
      case 4:
        p(), n = o;
        break;
      case 1:
        c === "(" ? n = 2 : If.test(c) ? p() : (a(), n = 0, c !== "*" && c !== "?" && c !== "+" && l--);
        break;
      case 2:
        c === ")" ? f[f.length - 1] == "\\" ? f = f.slice(0, -1) + c : n = 3 : f += c;
        break;
      case 3:
        a(), n = 0, c !== "*" && c !== "?" && c !== "+" && l--, f = "";
        break;
      default:
        t("Unknown state");
        break;
    }
  }
  return n === 2 && t(`Unfinished custom RegExp for param "${d}"`), a(), i(), r;
}
function kf(e, t, n) {
  const o = Pf(Mf(e.path), n);
  {
    const s = /* @__PURE__ */ new Set();
    for (const i of o.keys)
      s.has(i.name) && K(`Found duplicated params with name "${i.name}" for path "${e.path}". Only the last one will be available on "$route.params".`), s.add(i.name);
  }
  const r = X(o, {
    record: e,
    parent: t,
    // these needs to be populated by the parent
    children: [],
    alias: []
  });
  return t && !r.record.aliasOf == !t.record.aliasOf && t.children.push(r), r;
}
function jf(e, t) {
  const n = [], o = /* @__PURE__ */ new Map();
  t = Is({ strict: !1, end: !0, sensitive: !1 }, t);
  function r(a) {
    return o.get(a);
  }
  function s(a, p, m) {
    const y = !m, b = $s(a);
    Hf(b, p), b.aliasOf = m && m.record;
    const M = Is(t, a), F = [b];
    if ("alias" in a) {
      const te = typeof a.alias == "string" ? [a.alias] : a.alias;
      for (const I of te)
        F.push(
          // we need to normalize again to ensure the `mods` property
          // being non enumerable
          $s(X({}, b, {
            // this allows us to hold a copy of the `components` option
            // so that async components cache is hold on the original record
            components: m ? m.record.components : b.components,
            path: I,
            // we might be the child of an alias
            aliasOf: m ? m.record : b
            // the aliases are always of the same kind as the original since they
            // are defined on the same record
          }))
        );
    }
    let j, A;
    for (const te of F) {
      const { path: I } = te;
      if (p && I[0] !== "/") {
        const ne = p.record.path, re = ne[ne.length - 1] === "/" ? "" : "/";
        te.path = p.record.path + (I && re + I);
      }
      if (te.path === "*")
        throw new Error(`Catch all routes ("*") must now be defined using a param with a custom regexp.
See more at https://router.vuejs.org/guide/migration/#Removed-star-or-catch-all-routes.`);
      if (j = kf(te, p, M), p && I[0] === "/" && Lf(j, p), m ? (m.alias.push(j), Ff(m, j)) : (A = A || j, A !== j && A.alias.push(j), y && a.name && !As(j) && i(a.name)), gl(j) && c(j), b.children) {
        const ne = b.children;
        for (let re = 0; re < ne.length; re++)
          s(ne[re], j, m && m.children[re]);
      }
      m = m || j;
    }
    return A ? () => {
      i(A);
    } : wn;
  }
  function i(a) {
    if (pl(a)) {
      const p = o.get(a);
      p && (o.delete(a), n.splice(n.indexOf(p), 1), p.children.forEach(i), p.alias.forEach(i));
    } else {
      const p = n.indexOf(a);
      p > -1 && (n.splice(p, 1), a.record.name && o.delete(a.record.name), a.children.forEach(i), a.alias.forEach(i));
    }
  }
  function l() {
    return n;
  }
  function c(a) {
    const p = Vf(a, n);
    n.splice(p, 0, a), a.record.name && !As(a) && o.set(a.record.name, a);
  }
  function d(a, p) {
    let m, y = {}, b, M;
    if ("name" in a && a.name) {
      if (m = o.get(a.name), !m)
        throw en(1, {
          location: a
        });
      {
        const A = Object.keys(a.params || {}).filter((te) => !m.keys.find((I) => I.name === te));
        A.length && K(`Discarded invalid param(s) "${A.join('", "')}" when navigating. See https://github.com/vuejs/router/blob/main/packages/router/CHANGELOG.md#414-2022-08-22 for more details.`);
      }
      M = m.record.name, y = X(
        // paramsFromLocation is a new object
        Ps(
          p.params,
          // only keep params that exist in the resolved location
          // only keep optional params coming from a parent record
          m.keys.filter((A) => !A.optional).concat(m.parent ? m.parent.keys.filter((A) => A.optional) : []).map((A) => A.name)
        ),
        // discard any existing params in the current location that do not exist here
        // #1497 this ensures better active/exact matching
        a.params && Ps(a.params, m.keys.map((A) => A.name))
      ), b = m.stringify(y);
    } else if (a.path != null)
      b = a.path, b.startsWith("/") || K(`The Matcher cannot resolve relative paths but received "${b}". Unless you directly called \`matcher.resolve("${b}")\`, this is probably a bug in vue-router. Please open an issue at https://github.com/vuejs/router/issues/new/choose.`), m = n.find((A) => A.re.test(b)), m && (y = m.parse(b), M = m.record.name);
    else {
      if (m = p.name ? o.get(p.name) : n.find((A) => A.re.test(p.path)), !m)
        throw en(1, {
          location: a,
          currentLocation: p
        });
      M = m.record.name, y = X({}, p.params, a.params), b = m.stringify(y);
    }
    const F = [];
    let j = m;
    for (; j; )
      F.unshift(j.record), j = j.parent;
    return {
      name: M,
      path: b,
      params: y,
      matched: F,
      meta: Nf(F)
    };
  }
  e.forEach((a) => s(a));
  function f() {
    n.length = 0, o.clear();
  }
  return {
    addRoute: s,
    resolve: d,
    removeRoute: i,
    clearRoutes: f,
    getRoutes: l,
    getRecordMatcher: r
  };
}
function Ps(e, t) {
  const n = {};
  for (const o of t)
    o in e && (n[o] = e[o]);
  return n;
}
function $s(e) {
  const t = {
    path: e.path,
    redirect: e.redirect,
    name: e.name,
    meta: e.meta || {},
    aliasOf: e.aliasOf,
    beforeEnter: e.beforeEnter,
    props: Df(e),
    children: e.children || [],
    instances: {},
    leaveGuards: /* @__PURE__ */ new Set(),
    updateGuards: /* @__PURE__ */ new Set(),
    enterCallbacks: {},
    // must be declared afterwards
    // mods: {},
    components: "components" in e ? e.components || null : e.component && { default: e.component }
  };
  return Object.defineProperty(t, "mods", {
    value: {}
  }), t;
}
function Df(e) {
  const t = {}, n = e.props || !1;
  if ("component" in e)
    t.default = n;
  else
    for (const o in e.components)
      t[o] = typeof n == "object" ? n[o] : n;
  return t;
}
function As(e) {
  for (; e; ) {
    if (e.record.aliasOf)
      return !0;
    e = e.parent;
  }
  return !1;
}
function Nf(e) {
  return e.reduce((t, n) => X(t, n.meta), {});
}
function Is(e, t) {
  const n = {};
  for (const o in e)
    n[o] = o in t ? t[o] : e[o];
  return n;
}
function ur(e, t) {
  return e.name === t.name && e.optional === t.optional && e.repeatable === t.repeatable;
}
function Ff(e, t) {
  for (const n of e.keys)
    if (!n.optional && !t.keys.find(ur.bind(null, n)))
      return K(`Alias "${t.record.path}" and the original record: "${e.record.path}" must have the exact same param named "${n.name}"`);
  for (const n of t.keys)
    if (!n.optional && !e.keys.find(ur.bind(null, n)))
      return K(`Alias "${t.record.path}" and the original record: "${e.record.path}" must have the exact same param named "${n.name}"`);
}
function Hf(e, t) {
  t && t.record.name && !e.name && !e.path && K(`The route named "${String(t.record.name)}" has a child without a name and an empty path. Using that name won't render the empty path child so you probably want to move the name to the child instead. If this is intentional, add a name to the child route to remove the warning.`);
}
function Lf(e, t) {
  for (const n of t.keys)
    if (!e.keys.find(ur.bind(null, n)))
      return K(`Absolute path "${e.record.path}" must have the exact same param named "${n.name}" as its parent "${t.record.path}".`);
}
function Vf(e, t) {
  let n = 0, o = t.length;
  for (; n !== o; ) {
    const s = n + o >> 1;
    ml(e, t[s]) < 0 ? o = s : n = s + 1;
  }
  const r = Uf(e);
  return r && (o = t.lastIndexOf(r, o - 1), o < 0 && K(`Finding ancestor route "${r.record.path}" failed for "${e.record.path}"`)), o;
}
function Uf(e) {
  let t = e;
  for (; t = t.parent; )
    if (gl(t) && ml(e, t) === 0)
      return t;
}
function gl({ record: e }) {
  return !!(e.name || e.components && Object.keys(e.components).length || e.redirect);
}
function Kf(e) {
  const t = {};
  if (e === "" || e === "?")
    return t;
  const o = (e[0] === "?" ? e.slice(1) : e).split("&");
  for (let r = 0; r < o.length; ++r) {
    const s = o[r].replace(ll, " "), i = s.indexOf("="), l = Zt(i < 0 ? s : s.slice(0, i)), c = i < 0 ? null : Zt(s.slice(i + 1));
    if (l in t) {
      let d = t[l];
      Ie(d) || (d = t[l] = [d]), d.push(c);
    } else
      t[l] = c;
  }
  return t;
}
function Ms(e) {
  let t = "";
  for (let n in e) {
    const o = e[n];
    if (n = of(n), o == null) {
      o !== void 0 && (t += (t.length ? "&" : "") + n);
      continue;
    }
    (Ie(o) ? o.map((s) => s && cr(s)) : [o && cr(o)]).forEach((s) => {
      s !== void 0 && (t += (t.length ? "&" : "") + n, s != null && (t += "=" + s));
    });
  }
  return t;
}
function Bf(e) {
  const t = {};
  for (const n in e) {
    const o = e[n];
    o !== void 0 && (t[n] = Ie(o) ? o.map((r) => r == null ? null : "" + r) : o == null ? o : "" + o);
  }
  return t;
}
const Wf = Symbol("router view location matched"), ks = Symbol("router view depth"), Dr = Symbol("router"), Nr = Symbol("route location"), fr = Symbol("router view location");
function cn() {
  let e = [];
  function t(o) {
    return e.push(o), () => {
      const r = e.indexOf(o);
      r > -1 && e.splice(r, 1);
    };
  }
  function n() {
    e = [];
  }
  return {
    add: t,
    list: () => e.slice(),
    reset: n
  };
}
function St(e, t, n, o, r, s = (i) => i()) {
  const i = o && // name is defined if record is because of the function overload
  (o.enterCallbacks[r] = o.enterCallbacks[r] || []);
  return () => new Promise((l, c) => {
    const d = (p) => {
      p === !1 ? c(en(4, {
        from: n,
        to: t
      })) : p instanceof Error ? c(p) : fo(p) ? c(en(2, {
        from: t,
        to: p
      })) : (i && // since enterCallbackArray is truthy, both record and name also are
      o.enterCallbacks[r] === i && typeof p == "function" && i.push(p), l());
    }, f = s(() => e.call(o && o.instances[r], t, n, Gf(d, t, n)));
    let a = Promise.resolve(f);
    if (e.length < 3 && (a = a.then(d)), e.length > 2) {
      const p = `The "next" callback was never called inside of ${e.name ? '"' + e.name + '"' : ""}:
${e.toString()}
. If you are returning a value instead of calling "next", make sure to remove the "next" parameter from your function.`;
      if (typeof f == "object" && "then" in f)
        a = a.then((m) => d._called ? m : (K(p), Promise.reject(new Error("Invalid navigation guard"))));
      else if (f !== void 0 && !d._called) {
        K(p), c(new Error("Invalid navigation guard"));
        return;
      }
    }
    a.catch((p) => c(p));
  });
}
function Gf(e, t, n) {
  let o = 0;
  return function() {
    o++ === 1 && K(`The "next" callback was called more than once in one navigation guard when going from "${n.fullPath}" to "${t.fullPath}". It should be called exactly one time in each navigation guard. This will fail in production.`), e._called = !0, o === 1 && e.apply(null, arguments);
  };
}
function Lo(e, t, n, o, r = (s) => s()) {
  const s = [];
  for (const i of e) {
    !i.components && !i.children.length && K(`Record with path "${i.path}" is either missing a "component(s)" or "children" property.`);
    for (const l in i.components) {
      let c = i.components[l];
      {
        if (!c || typeof c != "object" && typeof c != "function")
          throw K(`Component "${l}" in record with path "${i.path}" is not a valid component. Received "${String(c)}".`), new Error("Invalid route component");
        if ("then" in c) {
          K(`Component "${l}" in record with path "${i.path}" is a Promise instead of a function that returns a Promise. Did you write "import('./MyPage.vue')" instead of "() => import('./MyPage.vue')" ? This will break in production if not fixed.`);
          const d = c;
          c = () => d;
        } else c.__asyncLoader && // warn only once per component
        !c.__warnedDefineAsync && (c.__warnedDefineAsync = !0, K(`Component "${l}" in record with path "${i.path}" is defined using "defineAsyncComponent()". Write "() => import('./MyPage.vue')" instead of "defineAsyncComponent(() => import('./MyPage.vue'))".`));
      }
      if (!(t !== "beforeRouteEnter" && !i.instances[l]))
        if (sl(c)) {
          const f = (c.__vccOpts || c)[t];
          f && s.push(St(f, n, o, i, l, r));
        } else {
          let d = c();
          "catch" in d || (K(`Component "${l}" in record with path "${i.path}" is a function that does not return a Promise. If you were passing a functional component, make sure to add a "displayName" to the component. This will break in production if not fixed.`), d = Promise.resolve(d)), s.push(() => d.then((f) => {
            if (!f)
              throw new Error(`Couldn't resolve component "${l}" at "${i.path}"`);
            const a = Gu(f) ? f.default : f;
            i.mods[l] = f, i.components[l] = a;
            const m = (a.__vccOpts || a)[t];
            return m && St(m, n, o, i, l, r)();
          }));
        }
    }
  }
  return s;
}
function js(e) {
  const t = Ze(Dr), n = Ze(Nr);
  let o = !1, r = null;
  const s = me(() => {
    const f = xe(e.to);
    return (!o || f !== r) && (fo(f) || (o ? K(`Invalid value for prop "to" in useLink()
- to:`, f, `
- previous to:`, r, `
- props:`, e) : K(`Invalid value for prop "to" in useLink()
- to:`, f, `
- props:`, e)), r = f, o = !0), t.resolve(f);
  }), i = me(() => {
    const { matched: f } = s.value, { length: a } = f, p = f[a - 1], m = n.matched;
    if (!p || !m.length)
      return -1;
    const y = m.findIndex(Ot.bind(null, p));
    if (y > -1)
      return y;
    const b = Ds(f[a - 2]);
    return (
      // we are dealing with nested routes
      a > 1 && // if the parent and matched route have the same path, this link is
      // referring to the empty child. Or we currently are on a different
      // child of the same parent
      Ds(p) === b && // avoid comparing the child with its parent
      m[m.length - 1].path !== b ? m.findIndex(Ot.bind(null, f[a - 2])) : y
    );
  }), l = me(() => i.value > -1 && Jf(n.params, s.value.params)), c = me(() => i.value > -1 && i.value === n.matched.length - 1 && fl(n.params, s.value.params));
  function d(f = {}) {
    return zf(f) ? t[xe(e.replace) ? "replace" : "push"](
      xe(e.to)
      // avoid uncaught errors are they are logged anyway
    ).catch(wn) : Promise.resolve();
  }
  if (ct) {
    const f = kr();
    if (f) {
      const a = {
        route: s.value,
        isActive: l.value,
        isExactActive: c.value,
        error: null
      };
      f.__vrl_devtools = f.__vrl_devtools || [], f.__vrl_devtools.push(a), Aa(() => {
        a.route = s.value, a.isActive = l.value, a.isExactActive = c.value, a.error = fo(xe(e.to)) ? null : 'Invalid "to" value';
      }, { flush: "post" });
    }
  }
  return {
    route: s,
    href: me(() => s.value.href),
    isActive: l,
    isExactActive: c,
    navigate: d
  };
}
const qf = /* @__PURE__ */ Si({
  name: "RouterLink",
  compatConfig: { MODE: 3 },
  props: {
    to: {
      type: [String, Object],
      required: !0
    },
    replace: Boolean,
    activeClass: String,
    // inactiveClass: String,
    exactActiveClass: String,
    custom: Boolean,
    ariaCurrentValue: {
      type: String,
      default: "page"
    }
  },
  useLink: js,
  setup(e, { slots: t }) {
    const n = bo(js(e)), { options: o } = Ze(Dr), r = me(() => ({
      [Ns(e.activeClass, o.linkActiveClass, "router-link-active")]: n.isActive,
      // [getLinkClass(
      //   props.inactiveClass,
      //   options.linkInactiveClass,
      //   'router-link-inactive'
      // )]: !link.isExactActive,
      [Ns(e.exactActiveClass, o.linkExactActiveClass, "router-link-exact-active")]: n.isExactActive
    }));
    return () => {
      const s = t.default && t.default(n);
      return e.custom ? s : Xi("a", {
        "aria-current": n.isExactActive ? e.ariaCurrentValue : null,
        href: n.href,
        // this would override user added attrs but Vue will still add
        // the listener, so we end up triggering both
        onClick: n.navigate,
        class: r.value
      }, s);
    };
  }
}), Sn = qf;
function zf(e) {
  if (!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && !(e.button !== void 0 && e.button !== 0)) {
    if (e.currentTarget && e.currentTarget.getAttribute) {
      const t = e.currentTarget.getAttribute("target");
      if (/\b_blank\b/i.test(t))
        return;
    }
    return e.preventDefault && e.preventDefault(), !0;
  }
}
function Jf(e, t) {
  for (const n in t) {
    const o = t[n], r = e[n];
    if (typeof o == "string") {
      if (o !== r)
        return !1;
    } else if (!Ie(r) || r.length !== o.length || o.some((s, i) => s !== r[i]))
      return !1;
  }
  return !0;
}
function Ds(e) {
  return e ? e.aliasOf ? e.aliasOf.path : e.path : "";
}
const Ns = (e, t, n) => e ?? t ?? n, Yf = /* @__PURE__ */ Si({
  name: "RouterView",
  // #674 we manually inherit them
  inheritAttrs: !1,
  props: {
    name: {
      type: String,
      default: "default"
    },
    route: Object
  },
  // Better compat for @vue/compat users
  // https://github.com/vuejs/router/issues/1315
  compatConfig: { MODE: 3 },
  setup(e, { attrs: t, slots: n }) {
    Qf();
    const o = Ze(fr), r = me(() => e.route || o.value), s = Ze(ks, 0), i = me(() => {
      let d = xe(s);
      const { matched: f } = r.value;
      let a;
      for (; (a = f[d]) && !a.components; )
        d++;
      return d;
    }), l = me(() => r.value.matched[i.value]);
    Gn(ks, me(() => i.value + 1)), Gn(Wf, l), Gn(fr, r);
    const c = gn();
    return bn(() => [c.value, l.value, e.name], ([d, f, a], [p, m, y]) => {
      f && (f.instances[a] = d, m && m !== f && d && d === p && (f.leaveGuards.size || (f.leaveGuards = m.leaveGuards), f.updateGuards.size || (f.updateGuards = m.updateGuards))), d && f && // if there is no instance but to and from are the same this might be
      // the first visit
      (!m || !Ot(f, m) || !p) && (f.enterCallbacks[a] || []).forEach((b) => b(d));
    }, { flush: "post" }), () => {
      const d = r.value, f = e.name, a = l.value, p = a && a.components[f];
      if (!p)
        return Fs(n.default, { Component: p, route: d });
      const m = a.props[f], y = m ? m === !0 ? d.params : typeof m == "function" ? m(d) : m : null, M = Xi(p, X({}, y, t, {
        onVnodeUnmounted: (F) => {
          F.component.isUnmounted && (a.instances[f] = null);
        },
        ref: c
      }));
      if (ct && M.ref) {
        const F = {
          depth: i.value,
          name: a.name,
          path: a.path,
          meta: a.meta
        };
        (Ie(M.ref) ? M.ref.map((A) => A.i) : [M.ref.i]).forEach((A) => {
          A.__vrv_devtools = F;
        });
      }
      return (
        // pass the vnode to the slot as a prop.
        // h and <component :is="..."> both accept vnodes
        Fs(n.default, { Component: M, route: d }) || M
      );
    };
  }
});
function Fs(e, t) {
  if (!e)
    return null;
  const n = e(t);
  return n.length === 1 ? n[0] : n;
}
const vl = Yf;
function Qf() {
  const e = kr(), t = e.parent && e.parent.type.name, n = e.parent && e.parent.subTree && e.parent.subTree.type;
  if (t && (t === "KeepAlive" || t.includes("Transition")) && typeof n == "object" && n.name === "RouterView") {
    const o = t === "KeepAlive" ? "keep-alive" : "transition";
    K(`<router-view> can no longer be used directly inside <transition> or <keep-alive>.
Use slot props instead:

<router-view v-slot="{ Component }">
  <${o}>
    <component :is="Component" />
  </${o}>
</router-view>`);
  }
}
function an(e, t) {
  const n = X({}, e, {
    // remove variables that can contain vue instances
    matched: e.matched.map((o) => cd(o, ["instances", "children", "aliasOf"]))
  });
  return {
    _custom: {
      type: null,
      readOnly: !0,
      display: e.fullPath,
      tooltip: t,
      value: n
    }
  };
}
function Un(e) {
  return {
    _custom: {
      display: e
    }
  };
}
let Xf = 0;
function Zf(e, t, n) {
  if (t.__hasDevtools)
    return;
  t.__hasDevtools = !0;
  const o = Xf++;
  Wu({
    id: "org.vuejs.router" + (o ? "." + o : ""),
    label: "Vue Router",
    packageName: "vue-router",
    homepage: "https://router.vuejs.org",
    logo: "https://router.vuejs.org/logo.png",
    componentStateTypes: ["Routing"],
    app: e
  }, (r) => {
    typeof r.now != "function" && console.warn("[Vue Router]: You seem to be using an outdated version of Vue Devtools. Are you still using the Beta release instead of the stable one? You can find the links at https://devtools.vuejs.org/guide/installation.html."), r.on.inspectComponent((f, a) => {
      f.instanceData && f.instanceData.state.push({
        type: "Routing",
        key: "$route",
        editable: !1,
        value: an(t.currentRoute.value, "Current Route")
      });
    }), r.on.visitComponentTree(({ treeNode: f, componentInstance: a }) => {
      if (a.__vrv_devtools) {
        const p = a.__vrv_devtools;
        f.tags.push({
          label: (p.name ? `${p.name.toString()}: ` : "") + p.path,
          textColor: 0,
          tooltip: "This component is rendered by &lt;router-view&gt;",
          backgroundColor: yl
        });
      }
      Ie(a.__vrl_devtools) && (a.__devtoolsApi = r, a.__vrl_devtools.forEach((p) => {
        let m = p.route.path, y = wl, b = "", M = 0;
        p.error ? (m = p.error, y = rd, M = sd) : p.isExactActive ? (y = _l, b = "This is exactly active") : p.isActive && (y = bl, b = "This link is active"), f.tags.push({
          label: m,
          textColor: M,
          tooltip: b,
          backgroundColor: y
        });
      }));
    }), bn(t.currentRoute, () => {
      c(), r.notifyComponentUpdate(), r.sendInspectorTree(l), r.sendInspectorState(l);
    });
    const s = "router:navigations:" + o;
    r.addTimelineLayer({
      id: s,
      label: `Router${o ? " " + o : ""} Navigations`,
      color: 4237508
    }), t.onError((f, a) => {
      r.addTimelineEvent({
        layerId: s,
        event: {
          title: "Error during Navigation",
          subtitle: a.fullPath,
          logType: "error",
          time: r.now(),
          data: { error: f },
          groupId: a.meta.__navigationId
        }
      });
    });
    let i = 0;
    t.beforeEach((f, a) => {
      const p = {
        guard: Un("beforeEach"),
        from: an(a, "Current Location during this navigation"),
        to: an(f, "Target location")
      };
      Object.defineProperty(f.meta, "__navigationId", {
        value: i++
      }), r.addTimelineEvent({
        layerId: s,
        event: {
          time: r.now(),
          title: "Start of navigation",
          subtitle: f.fullPath,
          data: p,
          groupId: f.meta.__navigationId
        }
      });
    }), t.afterEach((f, a, p) => {
      const m = {
        guard: Un("afterEach")
      };
      p ? (m.failure = {
        _custom: {
          type: Error,
          readOnly: !0,
          display: p ? p.message : "",
          tooltip: "Navigation Failure",
          value: p
        }
      }, m.status = Un("❌")) : m.status = Un("✅"), m.from = an(a, "Current Location during this navigation"), m.to = an(f, "Target location"), r.addTimelineEvent({
        layerId: s,
        event: {
          title: "End of navigation",
          subtitle: f.fullPath,
          time: r.now(),
          data: m,
          logType: p ? "warning" : "default",
          groupId: f.meta.__navigationId
        }
      });
    });
    const l = "router-inspector:" + o;
    r.addInspector({
      id: l,
      label: "Routes" + (o ? " " + o : ""),
      icon: "book",
      treeFilterPlaceholder: "Search routes"
    });
    function c() {
      if (!d)
        return;
      const f = d;
      let a = n.getRoutes().filter((p) => !p.parent || // these routes have a parent with no component which will not appear in the view
      // therefore we still need to include them
      !p.parent.record.components);
      a.forEach(El), f.filter && (a = a.filter((p) => (
        // save matches state based on the payload
        dr(p, f.filter.toLowerCase())
      ))), a.forEach((p) => Sl(p, t.currentRoute.value)), f.rootNodes = a.map(xl);
    }
    let d;
    r.on.getInspectorTree((f) => {
      d = f, f.app === e && f.inspectorId === l && c();
    }), r.on.getInspectorState((f) => {
      if (f.app === e && f.inspectorId === l) {
        const p = n.getRoutes().find((m) => m.record.__vd_id === f.nodeId);
        p && (f.state = {
          options: td(p)
        });
      }
    }), r.sendInspectorTree(l), r.sendInspectorState(l);
  });
}
function ed(e) {
  return e.optional ? e.repeatable ? "*" : "?" : e.repeatable ? "+" : "";
}
function td(e) {
  const { record: t } = e, n = [
    { editable: !1, key: "path", value: t.path }
  ];
  return t.name != null && n.push({
    editable: !1,
    key: "name",
    value: t.name
  }), n.push({ editable: !1, key: "regexp", value: e.re }), e.keys.length && n.push({
    editable: !1,
    key: "keys",
    value: {
      _custom: {
        type: null,
        readOnly: !0,
        display: e.keys.map((o) => `${o.name}${ed(o)}`).join(" "),
        tooltip: "Param keys",
        value: e.keys
      }
    }
  }), t.redirect != null && n.push({
    editable: !1,
    key: "redirect",
    value: t.redirect
  }), e.alias.length && n.push({
    editable: !1,
    key: "aliases",
    value: e.alias.map((o) => o.record.path)
  }), Object.keys(e.record.meta).length && n.push({
    editable: !1,
    key: "meta",
    value: e.record.meta
  }), n.push({
    key: "score",
    editable: !1,
    value: {
      _custom: {
        type: null,
        readOnly: !0,
        display: e.score.map((o) => o.join(", ")).join(" | "),
        tooltip: "Score used to sort routes",
        value: e.score
      }
    }
  }), n;
}
const yl = 15485081, bl = 2450411, _l = 8702998, nd = 2282478, wl = 16486972, od = 6710886, rd = 16704226, sd = 12131356;
function xl(e) {
  const t = [], { record: n } = e;
  n.name != null && t.push({
    label: String(n.name),
    textColor: 0,
    backgroundColor: nd
  }), n.aliasOf && t.push({
    label: "alias",
    textColor: 0,
    backgroundColor: wl
  }), e.__vd_match && t.push({
    label: "matches",
    textColor: 0,
    backgroundColor: yl
  }), e.__vd_exactActive && t.push({
    label: "exact",
    textColor: 0,
    backgroundColor: _l
  }), e.__vd_active && t.push({
    label: "active",
    textColor: 0,
    backgroundColor: bl
  }), n.redirect && t.push({
    label: typeof n.redirect == "string" ? `redirect: ${n.redirect}` : "redirects",
    textColor: 16777215,
    backgroundColor: od
  });
  let o = n.__vd_id;
  return o == null && (o = String(id++), n.__vd_id = o), {
    id: o,
    label: n.path,
    tags: t,
    children: e.children.map(xl)
  };
}
let id = 0;
const ld = /^\/(.*)\/([a-z]*)$/;
function Sl(e, t) {
  const n = t.matched.length && Ot(t.matched[t.matched.length - 1], e.record);
  e.__vd_exactActive = e.__vd_active = n, n || (e.__vd_active = t.matched.some((o) => Ot(o, e.record))), e.children.forEach((o) => Sl(o, t));
}
function El(e) {
  e.__vd_match = !1, e.children.forEach(El);
}
function dr(e, t) {
  const n = String(e.re).match(ld);
  if (e.__vd_match = !1, !n || n.length < 3)
    return !1;
  if (new RegExp(n[1].replace(/\$$/, ""), n[2]).test(t))
    return e.children.forEach((i) => dr(i, t)), e.record.path !== "/" || t === "/" ? (e.__vd_match = e.re.test(t), !0) : !1;
  const r = e.record.path.toLowerCase(), s = Zt(r);
  return !t.startsWith("/") && (s.includes(t) || r.includes(t)) || s.startsWith(t) || r.startsWith(t) || e.record.name && String(e.record.name).includes(t) ? !0 : e.children.some((i) => dr(i, t));
}
function cd(e, t) {
  const n = {};
  for (const o in e)
    t.includes(o) || (n[o] = e[o]);
  return n;
}
function ad(e) {
  const t = jf(e.routes, e), n = e.parseQuery || Kf, o = e.stringifyQuery || Ms, r = e.history;
  if (!r)
    throw new Error('Provide the "history" option when calling "createRouter()": https://router.vuejs.org/api/interfaces/RouterOptions.html#history');
  const s = cn(), i = cn(), l = cn(), c = fc(_t);
  let d = _t;
  ct && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
  const f = Fo.bind(null, (v) => "" + v), a = Fo.bind(null, sf), p = (
    // @ts-expect-error: intentionally avoid the type check
    Fo.bind(null, Zt)
  );
  function m(v, $) {
    let P, k;
    return pl(v) ? (P = t.getRecordMatcher(v), P || K(`Parent route "${String(v)}" not found when adding child route`, $), k = $) : k = v, t.addRoute(k, P);
  }
  function y(v) {
    const $ = t.getRecordMatcher(v);
    $ ? t.removeRoute($) : K(`Cannot remove non-existent route "${String(v)}"`);
  }
  function b() {
    return t.getRoutes().map((v) => v.record);
  }
  function M(v) {
    return !!t.getRecordMatcher(v);
  }
  function F(v, $) {
    if ($ = X({}, $ || c.value), typeof v == "string") {
      const u = Ho(n, v, $.path), h = t.resolve({ path: u.path }, $), g = r.createHref(u.fullPath);
      return g.startsWith("//") ? K(`Location "${v}" resolved to "${g}". A resolved location cannot start with multiple slashes.`) : h.matched.length || K(`No match found for location with path "${v}"`), X(u, h, {
        params: p(h.params),
        hash: Zt(u.hash),
        redirectedFrom: void 0,
        href: g
      });
    }
    if (!fo(v))
      return K(`router.resolve() was passed an invalid location. This will fail in production.
- Location:`, v), F({});
    let P;
    if (v.path != null)
      "params" in v && !("name" in v) && // @ts-expect-error: the type is never
      Object.keys(v.params).length && K(`Path "${v.path}" was passed with params but they will be ignored. Use a named route alongside params instead.`), P = X({}, v, {
        path: Ho(n, v.path, $.path).path
      });
    else {
      const u = X({}, v.params);
      for (const h in u)
        u[h] == null && delete u[h];
      P = X({}, v, {
        params: a(u)
      }), $.params = a($.params);
    }
    const k = t.resolve(P, $), q = v.hash || "";
    q && !q.startsWith("#") && K(`A \`hash\` should always start with the character "#". Replace "${q}" with "#${q}".`), k.params = f(p(k.params));
    const se = af(o, X({}, v, {
      hash: nf(q),
      path: k.path
    })), B = r.createHref(se);
    return B.startsWith("//") ? K(`Location "${v}" resolved to "${B}". A resolved location cannot start with multiple slashes.`) : k.matched.length || K(`No match found for location with path "${v.path != null ? v.path : v}"`), X({
      fullPath: se,
      // keep the hash encoded so fullPath is effectively path + encodedQuery +
      // hash
      hash: q,
      query: (
        // if the user is using a custom query lib like qs, we might have
        // nested objects, so we keep the query as is, meaning it can contain
        // numbers at `$route.query`, but at the point, the user will have to
        // use their own type anyway.
        // https://github.com/vuejs/router/issues/328#issuecomment-649481567
        o === Ms ? Bf(v.query) : v.query || {}
      )
    }, k, {
      redirectedFrom: void 0,
      href: B
    });
  }
  function j(v) {
    return typeof v == "string" ? Ho(n, v, c.value.path) : X({}, v);
  }
  function A(v, $) {
    if (d !== v)
      return en(8, {
        from: $,
        to: v
      });
  }
  function te(v) {
    return re(v);
  }
  function I(v) {
    return te(X(j(v), { replace: !0 }));
  }
  function ne(v) {
    const $ = v.matched[v.matched.length - 1];
    if ($ && $.redirect) {
      const { redirect: P } = $;
      let k = typeof P == "function" ? P(v) : P;
      if (typeof k == "string" && (k = k.includes("?") || k.includes("#") ? k = j(k) : (
        // force empty params
        { path: k }
      ), k.params = {}), k.path == null && !("name" in k))
        throw K(`Invalid redirect found:
${JSON.stringify(k, null, 2)}
 when navigating to "${v.fullPath}". A redirect must contain a name or path. This will break in production.`), new Error("Invalid redirect");
      return X({
        query: v.query,
        hash: v.hash,
        // avoid transferring params if the redirect has a path
        params: k.path != null ? {} : v.params
      }, k);
    }
  }
  function re(v, $) {
    const P = d = F(v), k = c.value, q = v.state, se = v.force, B = v.replace === !0, u = ne(P);
    if (u)
      return re(
        X(j(u), {
          state: typeof u == "object" ? X({}, q, u.state) : q,
          force: se,
          replace: B
        }),
        // keep original redirectedFrom if it exists
        $ || P
      );
    const h = P;
    h.redirectedFrom = $;
    let g;
    return !se && xs(o, k, P) && (g = en(16, { to: h, from: k }), vt(
      k,
      k,
      // this is a push, the only way for it to be triggered from a
      // history.listen is with a redirect, which makes it become a push
      !0,
      // This cannot be the first navigation because the initial location
      // cannot be manually navigated to
      !1
    )), (g ? Promise.resolve(g) : Me(h, k)).catch((_) => rt(_) ? (
      // navigation redirects still mark the router as ready
      rt(
        _,
        2
        /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
      ) ? _ : Pt(_)
    ) : (
      // reject any unknown error
      G(_, h, k)
    )).then((_) => {
      if (_) {
        if (rt(
          _,
          2
          /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
        ))
          return (
            // we are redirecting to the same location we were already at
            xs(o, F(_.to), h) && // and we have done it a couple of times
            $ && // @ts-expect-error: added only in dev
            ($._count = $._count ? (
              // @ts-expect-error
              $._count + 1
            ) : 1) > 30 ? (K(`Detected a possibly infinite redirection in a navigation guard when going from "${k.fullPath}" to "${h.fullPath}". Aborting to avoid a Stack Overflow.
 Are you always returning a new location within a navigation guard? That would lead to this error. Only return when redirecting or aborting, that should fix this. This might break in production if not fixed.`), Promise.reject(new Error("Infinite redirect in navigation guard"))) : re(
              // keep options
              X({
                // preserve an existing replacement but allow the redirect to override it
                replace: B
              }, j(_.to), {
                state: typeof _.to == "object" ? X({}, q, _.to.state) : q,
                force: se
              }),
              // preserve the original redirectedFrom if any
              $ || h
            )
          );
      } else
        _ = Te(h, k, !0, B, q);
      return Fe(h, k, _), _;
    });
  }
  function fe(v, $) {
    const P = A(v, $);
    return P ? Promise.reject(P) : Promise.resolve();
  }
  function de(v) {
    const $ = yt.values().next().value;
    return $ && typeof $.runWithContext == "function" ? $.runWithContext(v) : v();
  }
  function Me(v, $) {
    let P;
    const [k, q, se] = ud(v, $);
    P = Lo(k.reverse(), "beforeRouteLeave", v, $);
    for (const u of k)
      u.leaveGuards.forEach((h) => {
        P.push(St(h, v, $));
      });
    const B = fe.bind(null, v, $);
    return P.push(B), bt(P).then(() => {
      P = [];
      for (const u of s.list())
        P.push(St(u, v, $));
      return P.push(B), bt(P);
    }).then(() => {
      P = Lo(q, "beforeRouteUpdate", v, $);
      for (const u of q)
        u.updateGuards.forEach((h) => {
          P.push(St(h, v, $));
        });
      return P.push(B), bt(P);
    }).then(() => {
      P = [];
      for (const u of se)
        if (u.beforeEnter)
          if (Ie(u.beforeEnter))
            for (const h of u.beforeEnter)
              P.push(St(h, v, $));
          else
            P.push(St(u.beforeEnter, v, $));
      return P.push(B), bt(P);
    }).then(() => (v.matched.forEach((u) => u.enterCallbacks = {}), P = Lo(se, "beforeRouteEnter", v, $, de), P.push(B), bt(P))).then(() => {
      P = [];
      for (const u of i.list())
        P.push(St(u, v, $));
      return P.push(B), bt(P);
    }).catch((u) => rt(
      u,
      8
      /* ErrorTypes.NAVIGATION_CANCELLED */
    ) ? u : Promise.reject(u));
  }
  function Fe(v, $, P) {
    l.list().forEach((k) => de(() => k(v, $, P)));
  }
  function Te(v, $, P, k, q) {
    const se = A(v, $);
    if (se)
      return se;
    const B = $ === _t, u = ct ? history.state : {};
    P && (k || B ? r.replace(v.fullPath, X({
      scroll: B && u && u.scroll
    }, q)) : r.push(v.fullPath, q)), c.value = v, vt(v, $, P, B), Pt();
  }
  let Be;
  function Nn() {
    Be || (Be = r.listen((v, $, P) => {
      if (!Fn.listening)
        return;
      const k = F(v), q = ne(k);
      if (q) {
        re(X(q, { replace: !0 }), k).catch(wn);
        return;
      }
      d = k;
      const se = c.value;
      ct && vf(Es(se.fullPath, P.delta), To()), Me(k, se).catch((B) => rt(
        B,
        12
        /* ErrorTypes.NAVIGATION_CANCELLED */
      ) ? B : rt(
        B,
        2
        /* ErrorTypes.NAVIGATION_GUARD_REDIRECT */
      ) ? (re(
        B.to,
        k
        // avoid an uncaught rejection, let push call triggerError
      ).then((u) => {
        rt(
          u,
          20
          /* ErrorTypes.NAVIGATION_DUPLICATED */
        ) && !P.delta && P.type === Pn.pop && r.go(-1, !1);
      }).catch(wn), Promise.reject()) : (P.delta && r.go(-P.delta, !1), G(B, k, se))).then((B) => {
        B = B || Te(
          // after navigation, all matched components are resolved
          k,
          se,
          !1
        ), B && (P.delta && // a new navigation has been triggered, so we do not want to revert, that will change the current history
        // entry while a different route is displayed
        !rt(
          B,
          8
          /* ErrorTypes.NAVIGATION_CANCELLED */
        ) ? r.go(-P.delta, !1) : P.type === Pn.pop && rt(
          B,
          20
          /* ErrorTypes.NAVIGATION_DUPLICATED */
        ) && r.go(-1, !1)), Fe(k, se, B);
      }).catch(wn);
    }));
  }
  let ke = cn(), ge = cn(), W;
  function G(v, $, P) {
    Pt(v);
    const k = ge.list();
    return k.length ? k.forEach((q) => q(v, $, P)) : (K("uncaught error during route navigation:"), console.error(v)), Promise.reject(v);
  }
  function je() {
    return W && c.value !== _t ? Promise.resolve() : new Promise((v, $) => {
      ke.add([v, $]);
    });
  }
  function Pt(v) {
    return W || (W = !v, Nn(), ke.list().forEach(([$, P]) => v ? P(v) : $()), ke.reset()), v;
  }
  function vt(v, $, P, k) {
    const { scrollBehavior: q } = e;
    if (!ct || !q)
      return Promise.resolve();
    const se = !P && yf(Es(v.fullPath, 0)) || (k || !P) && history.state && history.state.scroll || null;
    return Sr().then(() => q(v, $, se)).then((B) => B && gf(B)).catch((B) => G(B, v, $));
  }
  const We = (v) => r.go(v);
  let De;
  const yt = /* @__PURE__ */ new Set(), Fn = {
    currentRoute: c,
    listening: !0,
    addRoute: m,
    removeRoute: y,
    clearRoutes: t.clearRoutes,
    hasRoute: M,
    getRoutes: b,
    resolve: F,
    options: e,
    push: te,
    replace: I,
    go: We,
    back: () => We(-1),
    forward: () => We(1),
    beforeEach: s.add,
    beforeResolve: i.add,
    afterEach: l.add,
    onError: ge.add,
    isReady: je,
    install(v) {
      const $ = this;
      v.component("RouterLink", Sn), v.component("RouterView", vl), v.config.globalProperties.$router = $, Object.defineProperty(v.config.globalProperties, "$route", {
        enumerable: !0,
        get: () => xe(c)
      }), ct && // used for the initial navigation client side to avoid pushing
      // multiple times when the router is used in multiple apps
      !De && c.value === _t && (De = !0, te(r.location).catch((q) => {
        K("Unexpected error when starting the router:", q);
      }));
      const P = {};
      for (const q in _t)
        Object.defineProperty(P, q, {
          get: () => c.value[q],
          enumerable: !0
        });
      v.provide(Dr, $), v.provide(Nr, li(P)), v.provide(fr, c);
      const k = v.unmount;
      yt.add(v), v.unmount = function() {
        yt.delete(v), yt.size < 1 && (d = _t, Be && Be(), Be = null, c.value = _t, De = !1, W = !1), k();
      }, ct && Zf(v, $, t);
    }
  };
  function bt(v) {
    return v.reduce(($, P) => $.then(() => de(P)), Promise.resolve());
  }
  return Fn;
}
function ud(e, t) {
  const n = [], o = [], r = [], s = Math.max(t.matched.length, e.matched.length);
  for (let i = 0; i < s; i++) {
    const l = t.matched[i];
    l && (e.matched.find((d) => Ot(d, l)) ? o.push(l) : n.push(l));
    const c = e.matched[i];
    c && (t.matched.find((d) => Ot(d, c)) || r.push(c));
  }
  return [n, o, r];
}
function Cl(e) {
  return Ze(Nr);
}
const fd = { class: "todo-app" }, dd = {
  __name: "App",
  setup(e) {
    return (t, n) => (Tt(), Qt("div", fd, [
      ue(xe(vl))
    ]));
  }
}, pd = { class: "footer" }, hd = { class: "todo-count" }, md = { class: "filters" }, gd = {
  __name: "TodoFooter",
  props: ["todos"],
  setup(e) {
    const t = e, n = Cl(), o = me(() => t.todos.filter((r) => !r.completed).length);
    return (r, s) => Yt((Tt(), Qt("footer", pd, [
      ie("span", hd, [
        ie("strong", null, Xn(o.value), 1),
        dn(" " + Xn(o.value === 1 ? "item" : "items") + " left ", 1)
      ]),
      ie("ul", md, [
        ie("li", null, [
          ue(xe(Sn), {
            to: "/",
            class: Dt({ selected: xe(n).name == "all" })
          }, {
            default: vn(() => s[1] || (s[1] = [
              dn("All")
            ])),
            _: 1
          }, 8, ["class"])
        ]),
        ie("li", null, [
          ue(xe(Sn), {
            to: "/active",
            class: Dt({ selected: xe(n).name == "active" })
          }, {
            default: vn(() => s[2] || (s[2] = [
              dn("Active")
            ])),
            _: 1
          }, 8, ["class"])
        ]),
        ie("li", null, [
          ue(xe(Sn), {
            to: "/completed",
            class: Dt({ selected: xe(n).name == "completed" })
          }, {
            default: vn(() => s[3] || (s[3] = [
              dn("Completed")
            ])),
            _: 1
          }, 8, ["class"])
        ])
      ]),
      Yt(ie("button", {
        class: "clear-completed",
        onClick: s[0] || (s[0] = (i) => r.$emit("delete-completed"))
      }, "Clear Completed", 512), [
        [ao, e.todos.some((i) => i.completed)]
      ])
    ], 512)), [
      [ao, e.todos.length > 0]
    ]);
  }
}, vd = { class: "header" }, yd = {
  __name: "TodoHeader",
  setup(e) {
    return (t, n) => (Tt(), Qt("header", vd, [
      ue(xe(Sn), { to: "/" }, {
        default: vn(() => n[1] || (n[1] = [
          ie("h1", null, "todos", -1)
        ])),
        _: 1
      }),
      ie("input", {
        type: "text",
        class: "new-todo",
        autofocus: "",
        autocomplete: "off",
        placeholder: "What needs to be done?",
        onKeyup: n[0] || (n[0] = ol((o) => {
          t.$emit("add-todo", o.target.value), o.target.value = "";
        }, ["enter"]))
      }, null, 32)
    ]));
  }
}, bd = { class: "view" }, _d = { class: "input-container" }, wd = {
  __name: "TodoItem",
  props: ["todo", "index"],
  emits: ["delete-todo", "edit-todo", "toggle-todo"],
  setup(e, { emit: t }) {
    const n = e, o = t, r = gn(!1), s = gn(null), i = gn(""), l = me({
      get() {
        return n.todo.title;
      },
      set(y) {
        i.value = y;
      }
    }), c = me({
      get() {
        return n.todo.completed;
      },
      set(y) {
        o("toggle-todo", n.todo, y);
      }
    });
    function d() {
      r.value = !0, Sr(() => {
        s.value.focus();
      });
    }
    function f() {
      r.value = !1, i.value.trim().length === 0 ? p() : m();
    }
    function a() {
      r.value = !1;
    }
    function p() {
      o("delete-todo", n.todo);
    }
    function m() {
      o("edit-todo", n.todo, i.value), i.value = "";
    }
    return (y, b) => (Tt(), Qt("li", {
      class: Dt({
        completed: e.todo.completed,
        editing: r.value
      })
    }, [
      ie("div", bd, [
        Yt(ie("input", {
          type: "checkbox",
          class: "toggle",
          "onUpdate:modelValue": b[0] || (b[0] = (M) => c.value = M)
        }, null, 512), [
          [tl, c.value]
        ]),
        ie("label", { onDblclick: d }, Xn(e.todo.title), 33),
        ie("button", {
          class: "destroy",
          onClick: Ou(p, ["prevent"])
        })
      ]),
      ie("div", _d, [
        Yt(ie("input", {
          id: "edit-todo-input",
          ref_key: "editInput",
          ref: s,
          type: "text",
          class: "edit",
          "onUpdate:modelValue": b[1] || (b[1] = (M) => l.value = M),
          onKeyup: ol(f, ["enter"]),
          onBlur: a
        }, null, 544), [
          [Eu, l.value]
        ]),
        b[2] || (b[2] = ie("label", {
          class: "visually-hidden",
          for: "edit-todo-input"
        }, "Edit Todo Input", -1))
      ])
    ], 2));
  }
}, xd = { class: "main" }, Sd = { class: "toggle-all-container" }, Ed = ["disabled"], Cd = { class: "todo-list" }, Td = {
  __name: "TodosComponent",
  setup(e) {
    const t = gn([]), n = Cl(), o = {
      all: (y) => y,
      active: (y) => y.value.filter((b) => !b.completed),
      completed: (y) => y.value.filter((b) => b.completed)
    }, r = me(() => o.active(t)), s = me(() => o.completed(t)), i = me(() => {
      switch (n.name) {
        case "active":
          return r;
        case "completed":
          return s;
        default:
          return t;
      }
    }), l = me({
      get() {
        return r.value.length === 0;
      },
      set(y) {
        t.value.forEach((b) => {
          b.completed = y;
        });
      }
    });
    function c() {
      let y = "";
      for (let b = 0; b < 32; b++) {
        let M = Math.random() * 16 | 0;
        (b === 8 || b === 12 || b === 16 || b === 20) && (y += "-"), y += (b === 12 ? 4 : b === 16 ? M & 3 | 8 : M).toString(16);
      }
      return y;
    }
    function d(y) {
      t.value.push({
        completed: !1,
        title: y,
        id: c()
      });
    }
    function f(y) {
      t.value = t.value.filter((b) => b !== y);
    }
    function a(y, b) {
      y.completed = b;
    }
    function p(y, b) {
      y.title = b;
    }
    function m() {
      t.value = t.value.filter((y) => !y.completed);
    }
    return (y, b) => (Tt(), Qt(Ne, null, [
      ue(yd, { onAddTodo: d }),
      Yt(ie("main", xd, [
        ie("div", Sd, [
          Yt(ie("input", {
            type: "checkbox",
            id: "toggle-all-input",
            class: "toggle-all",
            "onUpdate:modelValue": b[0] || (b[0] = (M) => l.value = M),
            disabled: i.value.value.length === 0
          }, null, 8, Ed), [
            [tl, l.value]
          ]),
          b[1] || (b[1] = ie("label", {
            class: "toggle-all-label",
            htmlFor: "toggle-all-input"
          }, " Toggle All Input ", -1))
        ]),
        ie("ul", Cd, [
          (Tt(!0), Qt(Ne, null, Zc(i.value.value, (M, F) => (Tt(), Wi(wd, {
            key: M.id,
            todo: M,
            index: F,
            onDeleteTodo: f,
            onEditTodo: p,
            onToggleTodo: a
          }, null, 8, ["todo", "index"]))), 128))
        ])
      ], 512), [
        [ao, t.value.length > 0]
      ]),
      ue(gd, {
        todos: t.value,
        onDeleteCompleted: m
      }, null, 8, ["todos"])
    ], 64));
  }
}, Vo = {
  __name: "TodoView",
  setup(e) {
    return (t, n) => (Tt(), Wi(Td));
  }
}, Rd = ad({
  history: Sf("/"),
  routes: [
    {
      path: "/",
      name: "all",
      component: Vo
    },
    {
      path: "/active",
      name: "active",
      component: Vo
    },
    {
      path: "/completed",
      name: "completed",
      component: Vo
    }
  ]
});
async function Od(e) {
  const t = [
    "/o/vue/style.css"
  ];
  for (const n of t) {
    const r = await (await fetch(n)).text(), s = document.createElement("style");
    s.textContent = r, e.appendChild(s);
  }
}
class Pd extends HTMLElement {
  constructor() {
    super(), this.attachShadow({ mode: "open" }), this.app = null;
  }
  async connectedCallback() {
    await Od(this.shadowRoot), this.app || (this.app = Iu(dd), this.app.use(Rd), this.app.mount(this.shadowRoot));
  }
  disconnectedCallback() {
    this.app && (this.app.unmount(), this.app = null);
  }
}
customElements.define("vue-todo-mvc", Pd);
